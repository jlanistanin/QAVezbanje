// Zbir3.java - Zbir dva broja u grafickom okruzenju.

import java.awt.*;
import java.awt.event.*;

public class Zbir3 extends Frame {

  private TextField prvi, drugi; // Prvi i drugi sabirak
  private Label rez;             // Rezultat.
  private Button radi;           // Pokretac racunanja.

  private Zbir3 () {             // Sastavljanje prozora.
    super ("Zbir 3");
    setBounds (100, 100, 200, 120);
    addWindowListener (new ProzorDogadjaji ());
    setLayout (null);
    add (new Label ("Prvi sabirak:" ))  .setBounds ( 20, 36, 80, 15);
    add (new Label ("Drugi sabirak:"))  .setBounds ( 20, 56, 80, 15);
    add (new Label ("Zbir:"         ))  .setBounds ( 20, 76, 80, 15);
    add (prvi  = new TextField  ("0"))  .setBounds (110, 36, 70, 18);
    add (drugi = new TextField  ("0"))  .setBounds (110, 56, 70, 18);
    add (rez   = new Label      ("0"))  .setBounds (110, 76, 67, 10);
    add (radi  = new Button ("Racunaj")).setBounds ( 60, 90, 80, 20);
    radi.addMouseListener (new RadiDogadjajiMisem ());
    setVisible (true);
  }

  private class RadiDogadjajiMisem extends MouseAdapter { // Rukovanje
    public void mouseClicked (MouseEvent d) {             //   dogadjajima
      try {                                               //   dugmeta.
        rez.setText ( Integer.toString (
          Integer.parseInt (prvi .getText()) +
          Integer.parseInt (drugi.getText())
        ));
      } catch (NumberFormatException g) { rez.setText ("GRESKA"); }
    } 
  }

  private class ProzorDogadjaji extends WindowAdapter {   // Rukovanje
    public void windowClosing (WindowEvent d)             //   dogadjajima
      { dispose (); }                                     //   prozora.
  }

  public static void main (String[] varg)                 // Glavna funkcija.
    { new Zbir3 (); }
}