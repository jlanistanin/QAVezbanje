// CasovnikT.java - Ispitivanje klase casovnika.

import java.awt.*;
import java.awt.event.*;
import usluge.*;

public class CasovnikT extends Frame {

  private Casovnik casovnik;                         // Korisceni casovnik.

  private void popuniProzor () {                     // Popunjavanje prozora:
    Label datum = new Label("", Label.CENTER),       // - oznake za datum
          vreme = new Label("", Label.CENTER);       //   i vreme,
    vreme.setFont (new Font (null, Font.BOLD, 24));
    add (datum, "North"); add (vreme, "Center");
    try { casovnik = new Casovnik (new Polje (datum),    // - stvaranje
                                   new Polje (vreme)); } //   casovnika,
      catch (GKompNeOdgovara g) {}

    Panel ploca = new Panel(); add (ploca, "South"); // - ploca za dugmad,

    Button dugme = new Button ("Kreni");             // - dugme za pokreta-
    ploca.add (dugme);                               //   nje casovnika,
    dugme.addActionListener (new ActionListener () {
      public void actionPerformed (ActionEvent d)
        { casovnik.kreni (); }
    });

    ploca.add (dugme = new Button ("Stani"));        // - dugme za zausta-
    dugme.addActionListener (new ActionListener () { //   vljanje casovnika,
      public void actionPerformed (ActionEvent d)
        { casovnik.stani (); }
    });

    ploca.add (dugme = new Button ("Zavrsi"));       // - dugme za unistava-
    dugme.addActionListener (new ActionListener () { //   nje casovnika i
      public void actionPerformed (ActionEvent d)    //   zatvaranje prozo-
        { casovnik.zavrsi (); dispose (); }          //   ra.
    });
  }

  private CasovnikT () {                        // Inicijalizacija:
    super ("Casovnik");
    setBounds (100, 100, 200, 150);
    popuniProzor ();                            // - popunjavanje prozora,
    addWindowListener (new WindowAdapter () {   // - obrada zatvaranja
      public void windowClosing (WindowEvent d) //   prozora,
        { casovnik.zavrsi (); dispose (); }
    });

  }

  public static void main (String[] varg)            // GLAVNA FUNKCIJA.
    { new CasovnikT ().setVisible (true); }
}