// Uporediv.java - Interfejs uporedivih pojmova.

package uredjivanje;

public interface Uporediv {

  boolean manji (Uporediv u);  // Da li je manji?

  boolean isti  (Uporediv u);  // Da li je isti?
}
