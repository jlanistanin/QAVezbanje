// Uredjivac.java - Klasa apstraktnih uredjivaca.

package uredjivanje;

public abstract class Uredjivac {
  private Casovnik cas;              // Sadrzani casovnik.

  public Uredjivac (Casovnik cas)    // Inicijalizacija.
    { this.cas = cas; }

  public void uredi (Uporediv[] u) { // Organizovanje uredjivanja.
    cas.kreni ();
    radi (u);
    cas.stani ();
  }

  protected abstract void radi (Uporediv[] u); // Uredjivanje.
}
