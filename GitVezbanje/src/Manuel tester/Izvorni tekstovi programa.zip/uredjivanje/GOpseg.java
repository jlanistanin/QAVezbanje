// GOpseg.java - Klasa gresaka: Neispravan opseg vrednosti.

package uredjivanje;

public class GOpseg extends Exception {

  public String toString () { return "*** Neispravan opseg vrednosti!"; }
}