// Casovnik.java - Klasa aktivnih casovnika.

package uredjivanje;

public class Casovnik extends Thread {
  private int dt;                    // Interval ispisivanja.
  private char zn;                   // Ispisivani znak.
  private boolean radi = false;      // Da li treba da radi?

  public Casovnik (int dt, char zn)  // Inicijalizacija.
    { this.dt = dt; this.zn = zn; start (); }

  public void run () {               // Telo niti.
    try {
      while (! interrupted ()) {
        if (! radi) synchronized (this) { wait (); }
        sleep (dt);
        System.out.print (zn);
      }
    } catch (InterruptedException g) {}
  }

  public synchronized void stani ()  // Privremeno zaustavljanje.
    { radi = false; }

  public synchronized void kreni ()  // Nastavak rada.
    { radi = true; notify (); }

  public void zavrsi ()              // Zavrsetak niti.
    { interrupt (); }
}