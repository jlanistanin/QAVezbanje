// NizZnakova.java - Klasa nizova uporedivih znakova.

package uredjivanje;

public class NizZnakova {
  private Znak[] niz;                               // Sadrzani niz.

  public NizZnakova (int n) {                       // Inicijalizacija.
    niz = new Znak [n]; puni ();
  }
                                                    // Popunjavanje niza.
  public void puni (Znak p, Znak q) throws GOpseg { // - zadatim opsegom,

    if (q.manji (p)) throw new GOpseg ();
    for (int i=0; i<niz.length; i++)
      niz[i] = new Znak (
        (char)(p.znak() + Math.random()*(q.znak()-p.znak()+1))
      );
  }

  public void puni () {                             // - podrazumevanim
    try { puni (new Znak('a'), new Znak ('z')); }   //   opsegom.
      catch (GOpseg g) {}
  }

  public void uredi (Uredjivac u)                   // Uredjivanje niza.
    { u.uredi (niz); }

  public String toString () {                       // Tekstualni oblik.
    StringBuffer s = new StringBuffer ();
    for (int i=0; i<niz.length; i++) {
      s.append (niz[i].znak());
      if (i%50==49 || i==niz.length-1)
        s.append ('\n');
    }
    return s.toString ();
  }
}