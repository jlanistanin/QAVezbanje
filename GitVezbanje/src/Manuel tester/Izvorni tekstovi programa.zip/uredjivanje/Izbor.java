// Izbor.java - Klasa uredjivaca metodom izbora.

package uredjivanje;

public class Izbor extends Uredjivac {

  public Izbor (Casovnik cas) { super (cas); } // Inicijalizacija.

  protected void radi (Uporediv[] niz) {       // Uredjivanje.
    for (int i=0; i<niz.length-1; i++)
      for (int j=i+1; j<niz.length; j++) {
        if (niz[j].manji(niz[i]))
          { Uporediv u = niz[i]; niz[i] = niz[j]; niz[j] = u; }
        try { Thread.sleep (1); } catch (InterruptedException g) {}
      }
  }
}