// Znak.java - Klasa uporedivih znakova.

package uredjivanje;

public class Znak implements Uporediv {
  private char zn;                        // Vrednost znaka.

  public Znak (char zn) { this.zn = zn; } // Inicijalizacija.

  public char znak () { return zn; }      // Dohvatanje znaka.

  public boolean manji (Uporediv u)       // Da li je manji?
    { return zn <  ((Znak)u).zn; }

  public boolean isti  (Uporediv u)       // Da li je isti?
    { return zn == ((Znak)u).zn; }

  public String toStrng ()                // Tekstualni oblik.
    { return Character.toString (zn); }
}
