//OsobeT.java - Ispitivanje klasa osoba, djaka i zaposlenih.

public class OsobeT {
  public static void main (String[] vpar) {
    Osoba[] ljudi = new Osoba [20]; int n = 0;

    System.out.println ("Citanje podataka o ljudima");
    radi: while (true) {
      System.out.print ("\nIzbor (O=osoba, D=djak, Z=zaposlen, K=kraj)? ");
      switch (Citaj.Char ()) {
        case 'O': case 'o': ljudi[n] = new Osoba ();    break;
        case 'D': case 'd': ljudi[n] = new Djak ();     break;
        case 'Z': case 'z': ljudi[n] = new Zaposlen (); break;
        case 'K': case 'k': break radi;
      }
      if (ljudi[n] != null) ljudi[n++].citaj ();
    }

    System.out.println ("\nPrikaz procitanih podataka");
    for (int i=0; i<n; i++) System.out.print ("\n" + ljudi[i]);
  }
}
