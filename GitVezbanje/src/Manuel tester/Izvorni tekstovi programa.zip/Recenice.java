// Recenice.java - Sredjivanje recenica.

import java.io.*;
import usluge.Citaj;

public class Recenice {
  private static void recenice (Citaj ul, PrintStream izl) {
    boolean prvi = true;
    while (true) {
      char zn = ul.getChS ();
    if (ul.endS ()) break;
      if (Character.isUpperCase (zn))
        { if (!prvi) zn = Character.toLowerCase (zn); else prvi = false; }
      else if (Character.isLowerCase (zn))
        { if (prvi) { zn = Character.toUpperCase (zn); prvi = false; } }
      else if (zn=='.' || zn=='!' || zn=='?')
        prvi = true;
      izl.print (zn);
    }
  }

  public static void main (String[] varg) {
    while (true) {
      System.out.print ("Ime ulazne datoteke?  ");
      String ulaz = Citaj.String ();
    if (ulaz.equals ("***")) break;
      System.out.print ("Ime izlazne datoteke? ");
      String izlaz = Citaj.String ();
    if (izlaz.equals ("***")) break;
      try {
        recenice (new Citaj (ulaz), new PrintStream (izlaz));
      } catch (FileNotFoundException g) {
        System.out.println ("*** Datoteka ne postoji!");
      }
    }
  }
}