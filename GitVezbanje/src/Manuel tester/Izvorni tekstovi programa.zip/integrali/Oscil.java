// Oscil.h - Klasa za prigusene oscilacije.

package integrali;

public class Oscil extends  Fun {

  public double f (double x)                               // Funkcija.
    { return Math.exp (-0.1 * x) * Math.sin (x); }
}