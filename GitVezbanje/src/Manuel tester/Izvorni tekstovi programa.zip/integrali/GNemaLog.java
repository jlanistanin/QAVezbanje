// GNemaLog.java - Klasa za greske: Nedozvoljeni argument za logaritam.

package integrali;

public class GNemaLog extends usluge.Greska {

  private double x;                           // Nedozvoljena vrednost.
                                              // Inicijalizacija:
  public GNemaLog ()                          // - bez navodjenja
    { super ("Logaritam negativnog broja"); } //   nedozvoljene vrednosti,

  public GNemaLog (double x) { this.x = x; }  // - navodjenjem
                                              //   nedozvoljene vrednosti.
  public double x ()                          // Uzimanje nedozvoljene
    { return imaPoruke() ? 1 : x; }           //   vrednosti.

  public String toString () {                 // Tekstualni oblik.
    return imaPoruke() ? super.toString()
                       : "*** Ne postoji logaritam od " + x + "!";
  }
}