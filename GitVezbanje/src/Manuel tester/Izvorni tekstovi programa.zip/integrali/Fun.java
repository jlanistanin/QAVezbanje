// Fun.java - Apstraktna klasa funkcija jednog realnog argumenta.

package integrali;
import usluge.Greska;

public abstract class Fun {
                                               // Vrednost funkcije.
  public abstract double f (double x) throws Greska;

  public double I (double x) throws GNemaInt   // Neodredjeni integral.
    { throw new GNemaInt(); }
                                               // Odredjeni integral:
  public final double I (double a, double b) throws Greska {
    final int N = 30;
    try {                                      // - tacno racunanje,
      return I (b) - I (a);
    } catch (GNemaInt g) {                     // - priblizno racunanje.
        double dx = (b - a) / N, s = 0;
       for (int i=0; i<N; i++) s += f(a+i*dx);
       return s * dx;
    }
  }
}