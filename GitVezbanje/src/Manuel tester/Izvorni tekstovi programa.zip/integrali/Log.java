// Log.java - Klasa za funkciju logaritam.

package integrali;

public class Log extends Fun {

  public double f (double x) throws GNemaLog {             // Funkcija.
      if (x <= 0) throw new GNemaLog (x);
      return Math.log (x);
  }
}