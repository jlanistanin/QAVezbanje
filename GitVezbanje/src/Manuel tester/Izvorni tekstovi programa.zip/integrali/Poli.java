// Poli.java - Klasa polinoma.

package integrali;
import vektor.*;

public class Poli extends Fun {

  private Vekt a;                            // Vektor koeficijenata.
  
  public Poli (int n) throws GVekt           // Inicijalizacija.
    { a = new Vekt (0, n); }
  
  public Poli postavi (int i, double b) throws GVekt // Postavljanje
    { a.postavi (i, b);  return this; }              //   koeficijenta.
  
  public double dohvati (int i) throws GVekt // Dohvatanje koeficijenta.
    { return a.dohvati (i); }
    
  public int red () { return a.maxInd (); }  // Red polinoma.
    
  public double f (double x) {               // Vrednost polinoma.
    double s = 0;
    try {
      for (int i=a.maxInd(); i>=0; s = s*x + a.dohvati(i--));
    } catch (GVekt g) {}
    return s;
  }

  public double I (double x) {               // Vrednost integrala.
    double s = 0;
    try {
      for (int i=a.maxInd(); i>=0; s = s*x + a.dohvati(i) / (i-- +1));
    } catch (GVekt g) {}
    return s * x;
  }
}