// GNemaInt.java - Klasa za greske: Funkcija nema integral.

package integrali;

public class GNemaInt extends usluge.Greska {
  
  public GNemaInt () { super ("Funkcija nema integral!"); }
}