// Sin.java - Klasa za funkciju sinus.

package integrali;

public class Sin extends Fun {

  public double f (double x) { return Math.sin (x); }      // Funkcija.
  
  public double I (double x) { return - Math.cos (x); }    // Integral.
}