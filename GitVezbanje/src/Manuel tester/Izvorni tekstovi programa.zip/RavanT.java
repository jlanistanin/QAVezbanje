// RavanT.java - Ispitivanje klasa Krug i Tacka u paketu Ravan.

import ravan.Krug;

public class RavanT {
  public static void main (String[] vpar) {
    Krug[] krugovi = new Krug [100];
    while (true) {
      int n = 0; System.out.println ();
      while (true) {
        System.out.print ("K[" + n + "] (r,x,y)? ");
        double r = Citaj.Double(), x = Citaj.Double(), y = Citaj.Double();
      if (r < 0) break;
        if (Krug.moze (r, x, y)) krugovi[n++] = new Krug (r, x, y);
          else System.out.println ("*** Ne moze da se smesti! ***");
      }
    if (n == 0) break;
      for (int i=0; i<n; System.out.println (krugovi[i++]));
      for (int i=0; i<n; krugovi[i++].brisi());
    }
  }
}
