// IzvodiT.java - Ispitivanje stvaranja izvoda.

import izvodi.*;
import usluge.Greska;

public class IzvodiT {
  public static void main (String[] varg) {
    ZbirFun zbir = new ZbirFun (Integer.parseInt (varg[0]));
    try {
      radi: while (true) {
        double a, b; char vrs;
        System.out.print ("Vrsta (M, E, *)? ");
        switch (Citaj.Char ()) {
          case 'm': case 'M':
            System.out.print ("a,b? ");
            zbir.dodaj (new Monom  (Citaj.Double(), Citaj.Double()));
            break;
          case 'e': case 'E':
            System.out.print ("a,b? ");
            zbir.dodaj (new Ekspon (Citaj.Double(), Citaj.Double()));
            break;
          case '*': break radi;
          default:
            throw new Greska ("Nedozvoljeni izbor!");
        }
      }
      Fun izvod = zbir.izv ();
      System.out.println ("Fun= " + zbir );
      System.out.println ("Izv= " + izvod);
      double xmin = Double.parseDouble (varg[1]),
             xmax = Double.parseDouble (varg[2]),
             dx   = Double.parseDouble (varg[3]);
      for (double x=xmin; x<=xmax; x+=dx)
        System.out.println (x + "\t" + zbir.f(x) + "\t" + izvod.f(x));
    } catch (Exception g) { System.out.println (g); }
  }
}