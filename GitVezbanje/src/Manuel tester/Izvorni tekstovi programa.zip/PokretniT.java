// PokretniT.java - Ispitivanje klase pokretnih tacaka.

import pokretni.*;
//import pokretni.Vektor;

public class PokretniT {
  public static void main (String[] vpar) {
    System.out.print ("Broj tacaka? "); int n = Citaj.Int ();
    Tacka[] tacke = new Tacka [n];
    for (int i=0; i<n; i++) {
      System.out.print("Koordinate tmena " + i + "? ");
      double x = Citaj.Double(), y = Citaj.Double(), z = Citaj.Double();
      System.out.print ("Komponente brzine?  ");
      double vx = Citaj.Double(), vy = Citaj.Double(), vz = Citaj.Double();
      tacke[i] = new Tacka (new Vektor(x,y,z), new Brzina(vx,vy,vz));
    }

    System.out.print ("\nBroj koraka? "); int k = Citaj.Int ();
    System.out.print ("Trajanje koraka? "); double dt = Citaj.Double();
    final Tacka org = new Tacka ();
    System.out.print ("ORG   " + org + "\n\n");

    for (int i=0; i<k; i++) {
      for (int j=0; j<n; tacke[j++].proteklo(dt));
      double min = org.rastojanje (tacke[0]); int m = 0;
      for (int j=1; j<n; j++) {
        double d = org.rastojanje (tacke[j]);
        if (d < min) { min = d; m = j; }
      }
      System.out.println (i + " " + tacke[m] + " " + min);
    }
  }
}