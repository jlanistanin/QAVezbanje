// NaredbeT.java - Ispitivanje klasa naredbi.

import izrazi.*;
import naredbe.*;

public class NaredbeT {
  public static void main (String[] vpar) {
    Prom n = new Prom ("n"), i = new Prom ("i"), f = new Prom ("f");
    Sekvenca telo = new Sekvenca ();
    telo.dodaj (new Prosta (new Dodela (i, new Zbir(i, new Konst (1)))));
    telo.dodaj (new Prosta (new Dodela (f, new Proizv (f, i))));
    Ciklus cikl = new Ciklus (new Razl (n, i), telo);
    Sekvenca prog = new Sekvenca ();
    prog.dodaj (new Prosta (new Dodela (i, new Konst (0))));
    prog.dodaj (new Prosta (new Dodela (f, new Konst (1))));
    prog.dodaj (cikl);
    System.out.println ("Program:\n" + prog);
    while (true) {
      System.out.print ("n? "); n.postavi (Citaj.Int ());
    if (n.vr () < 0) break;
      prog.radi ();
      System.out.println ("f= " + f.vr ());
    }
  }
}