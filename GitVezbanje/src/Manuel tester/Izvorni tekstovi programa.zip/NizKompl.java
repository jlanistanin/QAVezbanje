// NizKompl.java - Klasa nizova kompleksnih brojeva.

public class NizKompl {

  private Kompl1[] niz;                       // Elementi niza.
                                              // Stvaranje niza:
  public NizKompl (int n) {                   // - zadate duzine,
    niz = new Kompl1 [n];
    for (int i=0; i<n; niz[i++] = new Kompl1());
  }

  public NizKompl () { this (10); }           // - duzine 10.

  public int duzina () { return niz.length; } // Dohvatanje duzine.

  public NizKompl postavi (Kompl1 z, int i) { // Postavljanje elementa.
    if (i<0 || i>=niz.length) System.exit (1);
    niz[i] = new Kompl1 (z.re(), z.im());
    return this;
  }

  public Kompl1 dohvati (int i) {             // Dohvatanje elementa.
  	if (i<0 || i>=niz.length) System.exit (1);
  	return niz[i];
  }

  public String toString () {                 // Tekstualni oblik niza.
    String s = "";
    for (int i=0; i<niz.length; s+=niz[i++]+" ");
    return s;
  }

  public Kompl1 poli (Kompl1 z) {             // Vrednost polinoma.
    Kompl1 p = new Kompl1 ();
    for (int i=niz.length-1; i>=0; i--)
      p = p.proizvod(z).zbir(niz[i]);
    return p;
  }

  public String poli () {                     // Tekstualni oblik polinoma.
    String s = "poli[";
    for (int i=niz.length-1; i>=0; i--) {
      s += niz[i];
      if (i > 0) s += ',';
    }
    return s + ']';
  }
}