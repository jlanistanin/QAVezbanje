// GPolIndeks.java - Klasa za greske: Nedozvoljen indeks.

package polica;

public class GPolIndeks extends GPolica {

  private int ind;                            // Nedozvoljeni indeks.

  public GPolIndeks (int i) { ind = i; }      // Inicijalizacija.

  public int ind () { return ind; }           // Dohvatanje indeksa.

  public String toString ()                   // Tekstualni oblik.
    { return super.toString() + "Nedozvoljen indeks " + ind + "!"; }
}