// GPolPuna.java - Klasa za greske: Polica je puna.

package polica;

public class GPolPuna extends GPolica {

  public String toString ()                   // Tekstualni oblik.
    { return super.toString() + "Nema mesta na polici!"; }
}