// GPolica.java - Apstraktna klasa za greske pri radu s policama.

package polica;

public abstract class GPolica extends Exception {

  public String toString ()                   // Tekstualni oblik.
    { return "*** GRESKA s policom: "; }
}