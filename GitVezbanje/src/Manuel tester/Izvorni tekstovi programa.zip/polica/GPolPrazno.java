// GPolPrazno.java - Klasa za greske: Mesto je prazno.

package polica;

public class GPolPrazno extends GPolica {

  private int ind;                            // Indeks praznog mesta.

  public GPolPrazno (int i) { ind = i; }      // Inicijalizacija.

  public int ind () { return ind; }           // Dohvatanje indeksa.

  public String toString ()                   // Tekstualni oblik.
    { return super.toString() + "Prazno mesto " + ind + "!"; }
}