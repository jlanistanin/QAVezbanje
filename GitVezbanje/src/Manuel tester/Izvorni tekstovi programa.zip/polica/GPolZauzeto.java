// GPolZauzeto.java - Klasa za greske: Mesto je zauzeto.

package polica;

public class GPolZauzeto extends GPolica {

  private int ind;                            // Indeks popunjenog mesta.

  public GPolZauzeto (int i) { ind = i; }     // Inicijalizacija.

  public int ind () { return ind; }           // Dohvatanje indeksa.

  public String toString ()                   // Tekstualni oblik.
    { return super.toString() + "Zauzeto mesto " + ind + "!"; }
}