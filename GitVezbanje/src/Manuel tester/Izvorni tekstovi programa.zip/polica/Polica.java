// Polica.java - Klasa polica za predmete.

package polica;
import  predmeti1.Predmet;

public class Polica {

  private Predmet[] niz;                // Niz za smestanje predmeta.
  private double maxQ;                  // Nosivost police.
  private double q = 0;                 // Trenutna opterecenost police.

  public Polica (int kap, double Qmax) { // Inicijalizacija.
    niz = new Predmet [kap];
    maxQ = Qmax;
  }

  public Polica stavi (Predmet p, int i)      // Stavljanje na dato mesto.
    throws GPolIndeks, GPolZauzeto, GPolTezina {
    if (i<0 || i>=niz.length) throw new GPolIndeks (i);
    if (niz[i] != null)       throw new GPolZauzeto (i);
    if (q + p.Q() > maxQ)     throw new GPolTezina (p);
    niz[i] = p; q += p.Q ();
    return this;
  }

  public Polica stavi (Predmet p)     // Stavljanje na prvo slobodno mesto.
    throws GPolTezina, GPolPuna {
    if (q + p.Q() > maxQ)     throw new GPolTezina (p);
    int i = 0; while (i<niz.length && niz[i]!=null) i++;
    if (i == niz.length)      throw new GPolPuna ();
    niz[i] = p; q += p.Q ();
    return this;
  }

  public Predmet uzmi (int i)         // Uzimanje sa datog mesta.
    throws GPolIndeks, GPolPrazno {
    if (i<0 || i>=niz.length) throw new GPolIndeks (i);
    if (niz[i] == null)       throw new GPolPrazno (i);
    Predmet p = niz[i]; niz[i] = null; q -= p.Q ();
    return p;
  }

  public Predmet dohvati (int i)      // Dohvatanje na datom mestu.
    throws GPolIndeks, GPolPrazno {
    if (i<0 || i>=niz.length) throw new GPolIndeks (i);
    if (niz[i] == null)       throw new GPolPrazno (i);
    return niz[i];
  }

  public boolean prazno (int i) throws GPolIndeks {     // Da li je mesto
    if (i<0 || i>=niz.length) throw new GPolIndeks (i); //    prazno?
    return niz[i] == null;
  }

  public int kapacitet (){ return niz.length; } // Kapacitet police.

  public int slobodno () {                      // Broj slobodnih mesta.
    int k = 0;
    for (int i=0; i<niz.length; i++) if (niz[i] == null) k++;
    return k;
  }

  public int zauzeto ()                         // Broj zauzetih mesta.
    { return kapacitet () - slobodno (); }

  public double nosivost () { return maxQ; }    // Nosivost police.

  public double teret () { return q; }          // Ukupan teret na polici.

  public double jos() { return maxQ - q; }      // Dozvoljeni dodatni teret.

  public String toString () {                   // Tekstualni oblik.
    StringBuffer s = new StringBuffer ();
    for (int i=0; i<niz.length; i++)
      if (niz[i] != null)
        s.append (i).append (". ").append (niz[i]).append ('\n');
    return s.toString ();
  }

  public Polica prazni () {                     // Praznjenje police.
    for (int i=0; i<niz.length; niz[i++]=null);
    q = 0;
    return this;
  }
}