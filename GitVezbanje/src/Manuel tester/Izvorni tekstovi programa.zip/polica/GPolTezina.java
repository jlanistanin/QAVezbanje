// GPolTezina.java - Klasa za greske: Prekoracena je nosivost police.

package polica;
import  predmeti1.Predmet;

public class GPolTezina extends GPolica {

  private Predmet p;                          // Pretezak predmet.

  public GPolTezina (Predmet pp) { p = pp; }  // Inicijalizacija.

  public Predmet predmet () { return p; }     // Dohvatanje predmeta.

  public String toString ()                   // Tekstualni oblik.
    { return super.toString() + "Prevelika tezina " + p.Q() + "!"; }
}