// Trougao1.java - Povrsina trougla u ravni.

public class Trougao1 {
  public static void main (String[] vpar) {

    // Temena trougla:
    System.out.println ("Koordinate temena trougla");
    System.out.print ("- prvo  teme? ");
    double xA = Citaj.Double (), yA = Citaj.Double ();
    System.out.print ("- drugo teme? ");
    double xB = Citaj.Double (), yB = Citaj.Double ();
    System.out.print ("- trece teme? ");
    double xC = Citaj.Double (), yC = Citaj.Double ();

    // Stranice trougla:
    double a = Math.sqrt (Math.pow (xB-xC, 2) + Math.pow (yB-yC, 2));
    double b = Math.sqrt (Math.pow (xC-xA, 2) + Math.pow (yC-yA, 2));
    double c = Math.sqrt (Math.pow (xA-xB, 2) + Math.pow (yA-yB, 2));

    // Povrsina trougla:
    double s = (a + b + c) / 2;
    double P = Math.sqrt (s * (s-a) * (s-b) * (s-c));
    System.out.println ("Povrsina trougla: " + P);
  }
}
