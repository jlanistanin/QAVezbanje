// RedT.java - Ispitivanje klase redova neogranicenih kapaciteta.

public class RedT {
  public static void main (String[] vpar) {
    Red r = new Red ();
    radi: while (true) {
      System.out.print (
        "\n1. Stavljanje podatka\n"   +
          "2. Uzimanje podatka\n"     +
          "3. Ispisivanje sadrzaja\n" +
          "4. Praznjenje reda\n"     +
          "0. Zavrsetak rada\n\n"     +
          "Vas izbor? "
      );
      switch (Citaj.Int ()) {
        case 1: System.out.print     ("Broj?      ");
                r.stavi (Citaj.Int ());
                break;
        case 2: if (! r.prazan ())
                  System.out.println ("Broj=      " + r.uzmi());
                else System.out.println ("*** Red je prazan!");
                break;
        case 3: System.out.println   ("Red=       " + r); break;
        case 4: r.prazni (); break;
        case 0: break radi;
        default: System.out.println  ("*** Nedozvoljeni izbor!");
      }
    }
  }
}
