// Obrni.java - Obrtanje redosleda elemenata niza.

public class Obrni {
  public static void main (String[] vpar) {
    while (true) {
      System.out.print ("n? "); int n = Citaj.Int ();
    if (n<=0) break;
      double[] a = new double [n];
      System.out.print ("A? ");
      for (int i=0; i<n; a[i++]=Citaj.Double());
      for (int i=0, j=n-1; i<j; i++, j--) {
        double b = a[i]; a[i] = a[j]; a[j] = b;
      }
      System.out.print ("A=");
      for (int i=0; i<n; System.out.print (" "+a[i++]));
      System.out.print ("\n\n");
    }
  }
}
