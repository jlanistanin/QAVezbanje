// Uredi3.java - Uredjivanje niza brojeva metodom umetanja.

public class Uredi3 {
  public static void main (String[] vpar) {
    while (true) {

      // Citanje duzine niza:
      System.out.print ("\nDuzina niza? "); int n = Citaj.Int ();
    if (n <= 0) break;

      // Stvaranje i ispisivanje niza:
      int[] a = new int [n];
      System.out.print ("\nPocetni niz:\n\n");
      for (int i=0; i<n; i++) {
        System.out.print ((a[i] = (int)(Math.random() * 10)) + " ");
        if (i%30==29 || i==n-1) System.out.println ();
      }

      // Uredjivanje niza:
      for (int i=1; i<n; i++)
        for (int j=i-1; j>=0 && a[j]>a[j+1]; j--)
          { int b = a[j]; a[j] = a[j+1]; a[j+1] = b; }

      // Ispisivanje uredjenog niza:
      System.out.print ("\nUredjeni niz:\n\n");
      for (int i=0; i<n; i++) {
        System.out.print (a[i] + " ");
        if (i%30==29 || i==n-1) System.out.println ();
      }
    }
  }
}
