// Rastojanje.java - Rastojanje dve tacke u grafickom okruzenju.

import java.awt.*;
import java.awt.event.*;

public class Rastojanje extends Frame {

  private TextField[] koord = new TextField[6]; // Niz koordinata.
  private Label rez = new Label ("0");          // Rezultat.

  private Rastojanje () {                     // Inicijalizacija:
    super ("Rastojanje");
    setBounds (100, 100, 250, 150);
    popuniProzor ();                          // - popunjavanje prozora,
    setVisible (true);
    addWindowListener (new WindowAdapter () { // - obrada dogadjaja prozora,
      public void windowClosing (WindowEvent d) { dispose (); }
    });
  }

  private void popuniProzor () {                   // Popunjavanje prozora:
    Panel plo = new Panel (); add (plo, "Center"); // - ploca za koordinate,
    plo.setLayout (new GridLayout(4, 2, 4, 2));
    plo.add (new Label ("Prva tacka:"));
    plo.add (new Label ("Druga tacka:"));
    KoordPromena osmatrac = new KoordPromena ();
    for (int i=0; i<6; i++) {
      (koord[i] = new TextField ("0")).addTextListener (osmatrac);
      plo.add (koord[i]);
    }

    add (plo = new Panel (new GridLayout (4,1)), "West"); // - ploca za
    String[] ozn = {"", "  X ", "  Y ", "  Z "};          //   oznacavanje
    for (int i=0; i<4; plo.add (new Label (ozn[i++])));   //   vrsta,

    add (plo = new Panel (), "North");             // - ploca za rezultat.
    plo.add (new Label ("Rastojanje:"));
    plo.add (rez);
  }

  private class KoordPromena implements TextListener { // Racunanje
    public void textValueChanged (TextEvent d) {       //   rastojanja,
      try {                                            //   kad god se
        rez.setText (                                  //   promeni neka
          Double.toString (                            //   koordinata.
            Math.sqrt(
              Math.pow (Double.parseDouble(koord[0].getText())-
                        Double.parseDouble(koord[1].getText())  ,2) +
              Math.pow (Double.parseDouble(koord[2].getText())-
                        Double.parseDouble(koord[3].getText())  ,2) +
              Math.pow (Double.parseDouble(koord[4].getText())-
                        Double.parseDouble(koord[5].getText())  ,2)
            )
          )
        );
      } catch (NumberFormatException g) {
        rez.setText ("GRESKA!");
      }
      validate (); // (da bi se komponente prozora prerasporedile
    }              //  zbog promene broja cifara u rezultatu)
  }

  public static void main (String[] varg)              // Glavna funkcija.
    { new Rastojanje (); }
}