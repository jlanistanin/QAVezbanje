// GCrtez.java - Apstraktna klasa za greske crteza.

package crtez;

public abstract class GCrtez extends usluge.Greska {
  public GCrtez (String s) { super (s); }  
}