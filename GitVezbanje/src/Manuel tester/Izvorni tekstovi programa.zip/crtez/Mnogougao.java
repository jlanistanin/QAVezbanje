// Mnogougao.java - Klasa mnogouglova.

package crtez;
import  java.awt.*;

public class Mnogougao extends Figura {
  
  private Point[] niz;                             // Temena mnogougla.
  private int n;                                   // Broj temena.
                                                   // Inicijalizacija.
  public Mnogougao (Color b, int kap) { super (b); niz = new Point [kap]; }
  public Mnogougao (Color b) { this (b, 5); }
  public Mnogougao () { this (Color.black, 5); }
  
  public Mnogougao dodaj (Point T) {               // Dodavanje temena.
    if (n == niz.length) {
      int k = n + (n<50 ? 5 : n/10);
      Point[] pom = new Point [k];
      for (int i=0; i<n; pom[i]=niz[i++]);
      niz = pom;
    }
    niz[n++] = T;
    return this;
  }
  
  public boolean pripada (Point T) {               // Da li tacka pripada?
    Polygon p = new Polygon ();
    for (int i=0; i<n; i++)
      p.addPoint ((int)niz[i].getX(), (int)niz[i].getY());
    return p.contains (T.getX(), T.getY());
  }
 
  public void crtaj (Graphics g, int x0, int y0) { // Crtanje mnogougla.
    Polygon p = new Polygon ();
    for (int i=0; i<n; i++)
      p.addPoint (x0+(int)niz[i].getX(), y0-(int)niz[i].getY());
    g.setColor (boja ());
    g.fillPolygon (p);
  }
}