// GNePripada.java - Klasa za greske: Tacka ne pripada figuri.

package crtez;

public class GNePripada extends GCrtez {
  public GNePripada () {
    super ("Tacka ne pripada figuri!");
  }
}