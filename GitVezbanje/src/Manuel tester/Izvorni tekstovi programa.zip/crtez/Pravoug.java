// Pravoug.java - Klasa pravougaonika.

package crtez;
import  java.awt.*;

public class Pravoug extends Figura {
  
  private Point A, C;                              // Naspramna temena.
                                                   // Inicijalizacija.
  public Pravoug (Color b, Point A, Point C) throws GNeisprPravoug { 
    super (b);
    if (A.getX() >= C.getX() || A.getY() >= C.getY())
      throw new GNeisprPravoug ();
    this.A = A; this.C = C;
  }
  public Pravoug () { A = new Point (); C = new Point (1, 1); }
  
  public boolean pripada (Point T) {               // Da li tacka pripada?
    return A.getX() <= T.getX() && T.getX() <= C.getX() &&
           A.getY() <= T.getY() && T.getY() <= C.getY();
  }
  
  public void crtaj (Graphics g, int x0, int y0) { // Crtanje pravougaonika.
    g.setColor (boja ());
    g.fillRect (x0+(int)A.getX(), y0-(int)C.getY(), 
                (int)(C.getX()-A.getX()), (int)(C.getY()-A.getY()));
  }
}