// Platno.java - Klasa platna za crtanje.

package crtez;
import  java.awt.*;
import  java.awt.event.*;

public class Platno extends Canvas {
  private Crtez crt =                                   // Crtez na platnu.
    new Crtez (Color.yellow, new Point(0,getHeight()), 0, 0);

  public Platno () {                                    // Inicijalizacija.
    addComponentListener (new ComponentAdapter () {     // (obrada promene
      public void componentResized (ComponentEvent d) { //    veli?ine
        crt.promeniDim (getWidth(), getHeight());       //    platna)
      }
    });
  }

  public Platno dodaj (Figura fig)                      // Dodavanje figure.
    { crt.dodaj (fig); return this; }
    
  public Color boja (Point T) {                         // Boja tacke.
    Point TT = new Point ((int)T.getX(), getHeight()-(int)T.getY());
    try { return crt.boja (TT); }
      catch (GNePripada g) { return null;}
  }
    
  public void paint (Graphics g) {            // Ponovno iscrtavanje platna.
    crt.crtaj (g, 0, getHeight());
  }
}