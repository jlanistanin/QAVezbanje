// Crtez.java - Klasa crteza.

package crtez;
import  java.awt.*;

public class Crtez extends Figura {

  private Elem prvi, posl;      // Prvi i poslednji element liste figura.

  private class Elem {          // Element liste figura:
    Figura fig;                 // - sadrzana figura,
    Elem pret, sled;            // - prethodni i sledeci element,
    Elem (Figura f) {           // - inicijalizacija.
      fig = f;
      sled = null; pret = posl;
      if (prvi == null) prvi = this; else posl.sled = this;
      posl = this;
    }
  }

  private int x, y;                      // Donje levo teme crteza.
  private int sir, vis;                  // Sirina i visina crteza.

  public Crtez (Color b, Point T, int s, int v)  // Inicijalizacija.
    { super (b); x = (int)T.getX(); y = (int)T.getY(); sir = s; vis = v; }


  public Crtez promeniDim (int s, int v) // Promena dimenzija crteza.
    { sir = s; vis = v; return this; }

  public Crtez dodaj (Figura f)          // Dodavanje figure.
    { new Elem (f); return this; }

  public boolean pripada (Point T) {     // Da li tacka pripada?
    int dx = (int)T.getX () - x, dy = (int)T.getY () - y;
    return dx >= 0 && dx <= sir && dy >=0 && dy <= vis;
  }

  public Color boja (Point T) throws GNePripada {  // Boja tacke.
    if (! pripada (T)) throw new GNePripada ();
    Point T2 = new Point (T); T2.translate (-x, -y);
    for (Elem tek=posl; tek!=null; tek=tek.pret)
      try { return tek.fig.boja (T2); }
        catch (GNePripada g) {}
    return boja ();
  }

  public void crtaj (Graphics g, int x0, int y0) { // Crtanje crteza.
    Rectangle staro = g.getClipBounds ();
    g.clipRect (x0+x, y0-y-vis, sir, vis);
    g.setColor (boja ());
    g.fillRect (x0+x, y0-y-vis, sir, vis);
    for (Elem tek=prvi; tek!=null; tek=tek.sled)
      tek.fig.crtaj (g, x0+x, y0-y);
    g.setClip (staro);
  }
}