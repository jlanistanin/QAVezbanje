// Figura.java - Apstraktna klasa figura.

package crtez;
import  java.awt.*;

public abstract class Figura {
  
  private Color boja;                              // Boja figure.
  
  public Figura (int c, int z, int p)              // Inicijalizacija.
    { boja = new Color (c, z, p); }
  public Figura (Color b) { boja = b; }
  public Figura () { boja = Color.black; }
  
  public abstract boolean pripada (Point T);       // Da li tacka pripada?
  
  public final Color boja () { return boja; }      // Boja figure.
  
  public Color boja (Point T) throws GNePripada {  // Boja tacke u figuri.
    if (! pripada (T)) throw new GNePripada ();
    return boja; 
  }
  
  public abstract void crtaj (Graphics g, int x0, int y0); // Crtanje
  public void crtaj (Graphics g) { crtaj (g, 0, 0); }      //    figure.
}