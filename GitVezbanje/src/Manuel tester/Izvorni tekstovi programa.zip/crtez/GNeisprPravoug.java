// GNeisprPravoug.java - Klasa za greske: Neispravan pravougaonik.

package crtez;

public class GNeisprPravoug extends GCrtez {
  public GNeisprPravoug () {
    super ("Neispravna temena pravougaonika!");
  }
}