// Krug.java - Klasa krugova.

package crtez;
import  java.awt.*;

public class Krug extends Figura {
  
  private int r;                                   // Poluprecnik kruga.
  private Point C;                                 // Centar kruga.
  
  public Krug (Color b, Point C, int r)            // Inicijalizacija.
    { super (b); this.C = C; this.r = r; }
  public Krug () { C = new Point (); r = 1; }
  
  public boolean pripada (Point T) {               // Da li tacka pripada?
    return Math.sqrt (
             Math.pow (T.getX()-C.getX(), 2) +
             Math.pow (T.getY()-C.getY(), 2)
           ) <= r;
  }
  
  public void crtaj (Graphics g, int x0, int y0) { // Crtanje kruga.
    g.setColor (boja ());
    g.fillOval (x0+(int)C.getX()-r, y0-(int)C.getY()-r, 2*r, 2*r);
  }
}