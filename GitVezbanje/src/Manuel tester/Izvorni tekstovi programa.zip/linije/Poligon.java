// Poligon.java - Klasa poligona u ravni.

package linije;

public class Poligon extends Izlomljena {

  public Poligon (Tacka[] niz)           // Inicijalizacija nizom tacaka.
    { super (niz); }

  public double duz ()                   // Duzina poligona.
    { return super.duz () + new Duz(tem[0], tem[tem.length-1]).duz (); }

  public String toString ()              // Tekstualni oblik.
    { return id() + "[poligon: " + Tacka.toString (tem) + "]"; }
}