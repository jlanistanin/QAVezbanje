// Linija.java - Apstraktna klasa linija u ravni.

package linije;

public abstract class Linija {

  private static int ukId = 0;      // Poslednje korisceni identifikator.
  private int id = ++ukId;          // Identifikator linije.

  public int id() { return id; }    // Dohvatanje identifikatora linije.

  public abstract double duz ();    // Duzina linije.

  public String toString ()         // Tekstualni oblik.
    { return Integer.toString (id); }
}