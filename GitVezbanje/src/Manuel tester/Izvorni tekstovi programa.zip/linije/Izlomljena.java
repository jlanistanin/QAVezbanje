// Izlomljena.java - Klasa izlomljenih linija u ravni.

package linije;

public class Izlomljena extends Linija {

  protected Tacka[] tem;                 // Niz temena.

  public Izlomljena (Tacka[] niz)        // Inicijalizacija nizom tacaka.
    { tem = niz; }

  public double duz () {                 // Duzina izlomljene linije.
    double d = 0;
    for (int i=0; i<tem.length-1; i++)
      d += new Duz(tem[i], tem[i+1]).duz();
    return d;
  }

  public String toString () {            // Tekstualni oblik.
    return super.toString()  + "[izlomljena: " +
           Tacka.toString (tem) + "]";
  }
}