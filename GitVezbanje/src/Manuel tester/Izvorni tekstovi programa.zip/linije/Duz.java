// Duz.java - Klasa duzi u ravni.

package linije;

public class Duz extends Linija {
  private Tacka A, B;                             // Krajnje tacke.

  public Duz (Tacka P, Tacka Q) { A = P; B = Q; } // Inicijalizacija.
  public Duz () { A = new Tacka (-1,-1); B = new Tacka (1,1); }

  public double duz () {                          // Duzina duzi.
    return Math.sqrt (Math.pow(A.x()-B.x(),2) + Math.pow(A.y()-B.y(),2));
  }

  public String toString ()                       // Tekstualni oblik.
    { return super.toString() + "[duz: A" + A + ", B" + B + "]"; }
}