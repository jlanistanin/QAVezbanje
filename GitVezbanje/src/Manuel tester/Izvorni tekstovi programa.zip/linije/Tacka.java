// Tacka.java - Klasa tacaka u ravni.

package linije;

public class Tacka {

  private double x, y;                                    // Koordinate.

  public Tacka (double xx, double yy) { x = xx; y = yy; } // Inicijalizac.
  public Tacka (double xx) { x = xx; }
  public Tacka () {}

  public double x () { return x; }              // Koordinate.
  public double y () { return y; }

  public String toString ()                     // Tekstualni oblik.
    { return "(" + x + "," + y + ")"; }

  public static String toString (Tacka[] niz) { // Tekstualni oblik
    StringBuffer s = new StringBuffer ();       //   niza tacaka.
    for (int i=0; i<niz.length; i++) {
      if (i > 0) s.append (',');
      s.append (niz[i]);
    }
    return s.toString ();
  }
}