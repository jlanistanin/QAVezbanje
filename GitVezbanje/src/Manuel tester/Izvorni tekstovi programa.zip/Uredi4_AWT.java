// Uredi4.java - Uredjivanje nizova celih brojeva u grafickom okruzenju.

import java.awt.*;
import java.awt.event.*;
import uredjeni.*;
import usluge.Uporedljiv;

public class Uredi4 extends Frame {
  
  private static int[] duzine =                   // Moguce duzine niza.
    {100, 200, 500, 1000, 2000, 5000, 10000};
  private static Uredjivac[] uredjivaci = {       // Algoritmi uredjivanja.
    new MetodaIzbora (),       new MetodaIzbora2 (),
    new MetodaUmetanja (),     new MetodaUmetanja2 (),
    new MetodaZameneSuseda (), new BrzaMetoda ()
  };
  private Uporedljiv[] niz = new Celi [100];      // Niz za uredjivanje.
  private Uredjivac uredjivac = uredjivaci[0];    // Trenutni uredjivac.
  private TextArea prikaz = new TextArea ();      // Polje za prikaz niza.
  
  private void puni () {              // Punjenje niza slucajnim brojevima.
    for (int i=0; i<niz.length; i++)
      niz[i] = new Celi ((int)(Math.random ()*10));
    prikazi ();
  }
  
  private void prikazi () {           // Prikazivanje sadrzaja niza.
    int k = prikaz.getWidth () / 10; String s = "";
    for (int i=0; i<niz.length; i++)
      s += niz[i] + ((k==0 || i%k==k-1||i==niz.length-1)?"\n":" ");
    prikaz.setText (s);
  }
  
  private Uredi4 () {                // SASTAVLJANJE PROZORA (konstruktor).
    super ("Uredjivanje nizova");
    setBounds (100, 100, 370, 200);
    addWindowListener (new WindowAdapter () {
      public void windowClosing (WindowEvent d) {dispose (); }
    });
    setLayout (new BorderLayout());
    Panel ploca = new Panel (); add (ploca, "East");
    ploca.setLayout (new GridLayout (0, 1));
    
    puni ();              // Viseredno polje za tekst za prikazivanje niza.
    prikaz.addComponentListener (new ComponentAdapter () {
      public void componentResized (ComponentEvent d) { prikazi (); }
    });
    add (prikaz, "Center");
    
    Choice duzina = new Choice ();                   // Padajuca lista za
    for (int i=0; i<duzine.length; i++)              //    izbor duzine.
      duzina.addItem (Integer.toString (duzine[i]));
    duzina.addItemListener (new ItemListener () {
      public void itemStateChanged (ItemEvent d) {
        int duz = Integer.parseInt 
                    (((Choice)d.getSource ()).getSelectedItem ());
        niz = new Celi [duz]; puni ();
      }
    });
    ploca.add (duzina);
    
    CheckboxGroup grupa = new CheckboxGroup ();      // Radio-dugmad za
    RadioPromena osmatrac = new RadioPromena ();     //   izbor algoritma.
    for (int i=0; i<uredjivaci.length; i++) {
      Checkbox radio = new Checkbox (uredjivaci[i].toString());
      radio.addItemListener (osmatrac);
      radio.setCheckboxGroup (grupa); 
      if (i == 0) radio.setState (true);
      ploca.add (radio);
    }
   
    MenuBar traka = new MenuBar (); setMenuBar (traka);  // Sastavljanje
    Menu meni = new Menu ("Akcija"); traka.add (meni);   //   menija.
    MenuItem stavka = new MenuItem ("Pravi", new MenuShortcut ('P'));
    stavka.addActionListener (new ActionListener () {
      public void actionPerformed (ActionEvent d) { puni (); }
    });
    meni.add (stavka);
    stavka = new MenuItem ("Radi", new MenuShortcut ('R'));
    stavka.addActionListener (new ActionListener () {
      public void actionPerformed (ActionEvent d) 
        { uredjivac.uredi (niz); prikazi (); }
    });
    meni.add (stavka);
    meni.addSeparator();
    stavka = new MenuItem ("Zavrsi", new MenuShortcut ('Z'));
    stavka.addActionListener (new ActionListener () {
      public void actionPerformed (ActionEvent d) { System.exit (0); }
    });
    meni.add (stavka);
    setVisible (true);
  } // Konstruktor
  
  private class RadioPromena implements ItemListener { // Obrada promene
    public void itemStateChanged (ItemEvent d) {       //   stanja radio-
      String naziv = ((Checkbox)d.getSource ()).getLabel (); // -dugmeta.
      int i; for (i=0; i<uredjivaci.length; i++)
        if (naziv.equals (uredjivaci[i].toString ())) break;
      (uredjivac = uredjivaci[i]).uredi (niz); prikazi ();
    }
  }
  
  public static void main (String[] vpar)              // Glavna funkcija.
    { new Uredi4 (); }
}