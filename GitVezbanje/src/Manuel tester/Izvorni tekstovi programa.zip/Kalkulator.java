// Kalkulator.java - Jednostavan kalkulator u grafickom okruzenju.

import java.awt.*;
import java.awt.event.*;

public class Kalkulator extends Frame {

  private long x, y;                        // Registri kalkulatora.
  private Label[] reg = new Label [2];      // Prikaz registara.
  private static final int X = 0, Y = 1;    // Indeksi registara.
  private boolean noviBroj = true;          // Unosi se novi broj.
  private int osnova = 10;                  // Osnova brojevnog sistema.
  private Button[] cifre = new Button [16]; // Dugmad s ciframa.
  private boolean unisti = false;           // Da li unistiti prozor pri
                                            //   zatvaranju?
  private Panel ploRegistri () {            // Polja teksta za registre.
    Panel ploca = new Panel (new GridLayout (2, 1));
    Color[] podloge = {Color.ORANGE, Color.GRAY};
    Color[] slova   = {Color.BLUE, Color.WHITE};
    for (int i=0; i<2; i++) {
      reg[i] = new Label ("0", Label.RIGHT);
      reg[i].setFont (new Font (null, Font.BOLD, 20));
      reg[i].setForeground (slova[i]);
      reg[i].setBackground (podloge[i]);
      ploca.add (reg[i]);
    }
    return ploca;
  }

  private void prikazi () {                 // Prikaz sadrzaja registara.
    reg[X].setText (Long.toString (x, osnova));
    reg[Y].setText (Long.toString (y, osnova));
  }

  private Panel ploCifre () {               // Dugmad s ciframa.
    Panel ploca = new Panel (new GridLayout (4, 4));
    CifraAkcija osmatrac = new CifraAkcija ();
    for (int i=0; i<16; i++) {
      ploca.add (cifre[i] = new Button (Integer.toString (i,16)));
      cifre[i].addActionListener (osmatrac);
      cifre[i].setEnabled (i < osnova);
    }
    return ploca;
  }

  private class CifraAkcija implements ActionListener {    // Obrada
    public void actionPerformed (ActionEvent d) {          //   pritisaka
      String cif = ((Button)d.getSource ()).getLabel ();   //   na cifre.
      String staro = reg[Y].getText();
      reg[Y].setText ((noviBroj || staro.equals("0") ? "" : staro) + cif);
      noviBroj = false;
      try {
        y = Long.parseLong (reg[Y].getText(), osnova);
      } catch (NumberFormatException g) {
        reg[Y].setText ("G R E S K A");
        noviBroj = true;
      }
    }
  }

  private Panel ploOsnove () {              // Radio dugmad s osnovama
    String[] ozn = {"2", "8", "10", "16"};  //   brojevnih sistema.
    Panel ploca = new Panel (new GridLayout (ozn.length, 1));
    ploca.setBackground (Color.YELLOW);
    CheckboxGroup grupa = new CheckboxGroup ();
    OsnovaPromena osmatrac = new OsnovaPromena ();
    for (String s: ozn) {
       Checkbox radio = new Checkbox (s, grupa,
                              Integer.parseInt(s)==osnova);
       ploca.add (radio);
       radio.addItemListener (osmatrac);
    }
    return ploca;
  }

  private class OsnovaPromena implements ItemListener {    // Obrada
    public void itemStateChanged (ItemEvent d) {           //   promene
      String ozn = ((Checkbox)(d.getSource())).getLabel(); //   osnove
      osnova = Integer.parseInt (ozn);                     //   brojevnog
      for (int i=0; i<16; i++)                             //   sistema.
        cifre[i].setEnabled (i < osnova);
      prikazi ();
    }
  }

  private Panel ploOperatori () {           // Dugmad s operatorima.
    String[] ozn = {"=", "0", "+=", "|=", "-=", "^=",
                    "*=", "&=", "/=", "<<=", "%=", ">>="};
    Panel ploca = new Panel();
    ploca.setLayout (new GridLayout ((ozn.length+1)/2, 2));
    OperatorAkcija osmatrac = new OperatorAkcija ();
    for (String s: ozn) {
      Button dugme = new Button (s);
      dugme.setForeground (Color.BLUE);
      dugme.setBackground (Color.YELLOW);
      dugme.addActionListener (osmatrac);
      ploca.add (dugme);
    }
    return ploca;
  }

  private class OperatorAkcija implements ActionListener { // Obrada
    public void actionPerformed (ActionEvent d) {          //   pritisaka na
      try {                                                //   operatore.
        switch (((Button)d.getSource()).getLabel().charAt(0)) {
          case '=': x   = y; break;    case '0': y   = 0; break;
          case '+': x  += y; break;    case '|': x  |= y; break;
          case '-': x  -= y; break;    case '&': x  &= y; break;
          case '*': x  *= y; break;    case '^': x  ^= y; break;
          case '/': x  /= y; break;    case '<': x <<= y; break;
          case '%': x  %= y; break;    case '>': x >>= y; break;
        }
        prikazi ();
      } catch (ArithmeticException g) {
        reg[Y].setText ("G R E S K A");
      }
      noviBroj = true;
    }
  }

  public Kalkulator (int x, int y) {            // Inicijalizacija:
    super ("Kalkulator");
    setBounds (x, y, 305, 242);
    setResizable (false);
    add (ploRegistri(),  BorderLayout.NORTH);   // - popunjavanje prozora,
    add (ploCifre(),     BorderLayout.CENTER);
    add (ploOsnove(),    BorderLayout.WEST);
    add (ploOperatori(), BorderLayout.EAST);
    addWindowListener (new WindowAdapter () {
      public void windowClosing (WindowEvent d) // - unistavanje prozora.
        { if (unisti) dispose (); else setVisible (false); }
    });
  }

  public Kalkulator () { this (250, 50); }  // Podrazumevani konstruktor.

  public long rezultat () { return x; }     // Dohvatanje rezultata.

  public static void main (String[] varg) { // Glavna funkcija.
    Kalkulator kalk = new Kalkulator ();
    kalk.setVisible (true);
    kalk.unisti = true;
  }
}