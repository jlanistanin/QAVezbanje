// RadnjaT.java - Ispitivanje klase radnji.

import radnja.*;
import polica.Polica;
import radionica.*;

public class RadnjaT {
  public static void main (String[] varg) {
    Radnja rad  = new Radnja (50, 5, 2, 2);
    rad.dodajMas (new MasSfera (1,1));
    rad.dodajMas (new MasKvad (0.5, 1, 2, 3));
    rad.zaposli  (new PokRadnik ("Marko", 4));
    rad.zaposli  (new PokRadnik ("Stevo", 5));
    rad.zaposli  (new PokRadnik ("Ljubo", 6));
    rad.radi (1.25, 20);
  }
}