// Izraz1.java - Izracunavanje zbira uzastopnih prirodnih brojeva.

public class Izraz1 {
  public static void main (String[] vpar) {
    System.out.print ("n? "); int n = Citaj.Int ();
    double s = 0;
    for (int i=1; i<=n; s+=i++);
    System.out.println ("s= " + s);
  }
}
