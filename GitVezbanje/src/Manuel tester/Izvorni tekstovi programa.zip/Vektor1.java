// Vektor1.java - Klasa vektora s konkurentnom obradom.

import usluge.Greska;

public class Vektor1 {

  private static class Sabirac extends Thread { // KLASA NITI ZA SABIRANJE:
    private double a, b, c;                     // Opreandi i rezultat.
    public Sabirac (double p, double q) { a = p; b = q; } // Konstruktor.
    public void run () { c = a + b; }           // Sadrzaj niti.
    public double rezultat () { return c; }     // Dohvatanje rezultata.
  }

  private static class Mnozac extends Thread {  // KLASA NITI ZA MNOZENJE:
    private double a, b, c;                     // Operandi i rezultat.
    public Mnozac (double p, double q) { a = p; b = q; } // Konstruktor.
    public void run () { c = a * b; }           // Sadrzaj niti.
    public double rezultat () { return c; }     // Dohvatanje rezultata.
  }

  private double[] niz;                         // Komponente vektora.

  public Vektor1 (int duz) { niz = new double [duz]; } // Konstruktor.
                                                // Postavljanje komponente.
  public Vektor1 postavi (int ind, double broj) throws Greska {
    if (ind < 0 || ind >= niz.length)
      throw new Greska ("Nedozvoljen indeks!");
    niz[ind] = broj;
    return this;
  }

  public double uzmi (int ind) throws Greska {  // Dohvatanje komponente.
    if (ind < 0 || ind >= niz.length)
      throw new Greska ("Nedozvoljen indeks!");
    return niz[ind];
  }

  public String toString () {                   // Tekstualni oblik.
    String s = "(";
    for (int i=0; i<niz.length; i++)
      { if (i > 0) s += ","; s += niz[i]; }
    return s + ")";
  }
                                                // Zbir dva vektora.
                                                // Zbir dva vektora:
  public static Vektor1 zbir (Vektor1 v1, Vektor1 v2) throws Greska {
    int n = v1.niz.length, n2 = v2.niz.length;
    if (n != n2) throw new Greska ("Neusaglasene duzine vektora!");
    Sabirac[] sab = new Sabirac [n];
    for (int i=0; i<n; i++)                     // - pokretanje niti,
      (sab[i] = new Sabirac (v1.niz[i], v2.niz[i])).start ();
    Vektor1 v = new Vektor1 (n);
    for (int i=0; i<n; i++)                     // - sakupljanje rezultata.
      try { sab[i].join(); v.niz[i] = sab[i].rezultat (); }
        catch (InterruptedException g) {}
    return v;
  }
                                                // Skalarni proizvod:
  public static double skalPro (Vektor1 v1, Vektor1 v2) throws Greska {
    int n = v1.niz.length, n2 = v2.niz.length;
    if (n != n2) throw new Greska ("Neusaglasene duzine vektora!");
    Mnozac[] mno = new Mnozac [n];
    for (int i=0; i<n; i++)                     // - pokretanje niti,
      (mno[i] = new Mnozac (v1.niz[i], v2.niz[i])).start ();
    double s = 0;
    for (int i=0; i<n; i++)                     // - sakupljanje rezultata.
      try { mno[i].join(); s += mno[i].rezultat (); }
        catch (InterruptedException g) {}
    return s;
  }

  public static void main (String[] vpar) {     // GLAVNA FUNKCIJA.
    while (true) {
      try {
        System.out.print ("n1? "); int n1 = Citaj.Int ();
    if (n1 <= 0) break;
        System.out.print ("v1? "); Vektor1 v1 = new Vektor1 (n1);
        for (int i=0; i<n1; v1.postavi (i++, Citaj.Double ()));
        System.out.print ("n2? "); int n2 = Citaj.Int ();
    if (n2 <= 0) break;
        System.out.print ("v2? "); Vektor1 v2 = new Vektor1 (n2);
        for (int i=0; i<n2; v2.postavi (i++, Citaj.Double ()));
        System.out.println ("Zbir: " + Vektor1.zbir(v1,v2));
        System.out.println ("Skalpro: " + Vektor1.skalPro(v1,v2) + "\n");
      } catch (Greska g) {
        System.out.println (g + "\n");
      }
    }
  }
}