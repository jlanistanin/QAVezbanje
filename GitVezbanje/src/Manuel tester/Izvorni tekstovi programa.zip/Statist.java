// Statist.java - Srednja vrednost i standardna devijacija
//                niza realnih brojeva.

public class Statist {
  public static void main (String[] vpar) {
    System.out.print ("\nBroj elemenata niza? "); int n = Citaj.Int ();
    while (n > 0) {
      System.out.print ("Elementi niza? ");
      double s = 0, d = 0;
      for (int i=1; i<=n; i++)
        { double a = Citaj.Double (); s += a; d += a * a; }
      s /= n; d = Math.sqrt (d / n - s * s);
      System.out.println ("Srednja vrednost:      " + s);
      System.out.println ("Standardna devijacija: " + d);
      System.out.print   ("\nBroj elemenata niza? "); n = Citaj.Int ();
    }
  }
}
