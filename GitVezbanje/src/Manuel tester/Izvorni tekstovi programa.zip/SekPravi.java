// SekPravi.java - Formiranje sekvencijalne binarne datoteke.

import usluge.Citaj;
import java.io.*;

public class SekPravi {
  public static void main (String[] varg) {
    try {
      Citaj ulaz = new Citaj (varg[0]);
      DataOutputStream izlaz = new DataOutputStream (
                                 new FileOutputStream (varg[1]));
      while (true) {
        int n = ulaz.IntS ();
      if (ulaz.endS ()) break;
        izlaz.writeInt (n);
        for (int i=0; i<n; i++) {
          double x = ulaz.DoubleS ();
          izlaz.writeDouble (x);
        }
      }
    } catch (FileNotFoundException g) {
      System.out.println ("*** Greska pri otvaranju datoteke!");
    } catch (IOException g) {
      System.out.println ("*** Ulazno/izlazna greska!");
    }
  }
}
