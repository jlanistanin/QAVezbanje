// SrVred2.java - Srednja vrednost brojeva u zapisima tekstualne datoteke.

import usluge.Citaj;
import java.io.*;

public class SrVred2 {
  public static void main (String[] varg) {
    try {
      Citaj ul = new Citaj ("SrVred2.pod");
      PrintStream izl = new PrintStream ("SrVred2.rez");
      double z = 0;
      while (true) {
        int n = ul.IntS ();
      if (ul.endS ()) break;
        double [] a = new double [n];
        double s = 0;
        for (int i=0; i<n; i++) s += (a[i] = ul.DoubleS ());
        z += (s /= n);
        if (s > 0) {
          izl.print (n);
          for (int i=0; i<n; izl.print(" " + a[i++]));
          izl.println ();
        }
      }
      System.out.println ("Zbir srednjih vrednosti= " + z);
    } catch (FileNotFoundException g) {
      System.out.println (g);
    }
  }
}