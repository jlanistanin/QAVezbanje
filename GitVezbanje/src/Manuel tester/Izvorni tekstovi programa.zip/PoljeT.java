// PoljeT.java - Ispitivanje klase polja graficke korisnicke povrsi.

import usluge.*;
import java.awt.*;
import java.awt.event.*;

public class PoljeT extends Frame {

  private Label rez;                          // Oznaka vrste rezultata.
  private Kompl2 prvi, drugi, rezult;         // Operandi i rezultat.
  private final String[] oper =               // Natpisi dugmadi.
    {"Zbir", "Razlika", "Proizvod", "Kolicnik"};

  private void popuniProzor () {                  // Popunjavanje prozora:
    Panel plo = new Panel(new GridLayout (3, 1)); // - ploca za oznake
    add (plo, "West");                            //   podataka,
    plo.add (new Label ("Prvi"));
    plo.add (new Label ("Drugi"));
    plo.add (rez = new Label ());

    add (plo = new Panel (new GridLayout (3, 2)), "Center"); // - ploca za
    try {                                                    //   podatke,
      TextField re = new TextField (), im = new TextField ();
      plo.add (re); plo.add (im);
      prvi = new Kompl2 (new Polje(re), new Polje (im));
      re = new TextField (); im = new TextField ();
      plo.add (re); plo.add (im);
      drugi = new Kompl2 (new Polje(re), new Polje (im));
      Label r = new Label (), i = new Label ();
      plo.add (r); plo.add (i);
      rezult = new Kompl2 (new Polje(r), new Polje (i));
    } catch (GKompNeOdgovara g) {}

    add (plo = new Panel (), "South");        // - ploca za dugmad.
    DugmeAkcija osmatrac = new DugmeAkcija ();
    for (String s: oper) {
      Button dugme = new Button (s);
      plo.add (dugme);
      dugme.addActionListener (osmatrac);
    }
  } // popuniProzor()

  private class DugmeAkcija implements ActionListener { // Obrada dogadjaja
    public void actionPerformed (ActionEvent d) {       //   dugmadi.
      String op = ((Button)(d.getSource ())).getLabel ();
      try {
        if      (op.equals(oper[0]))
          rezult.postavi (prvi.uzmi ().zbir     (drugi.uzmi ()));
        else if (op.equals(oper[1]))
          rezult.postavi (prvi.uzmi ().razlika  (drugi.uzmi ()));
        else if (op.equals(oper[2]))
          rezult.postavi (prvi.uzmi ().proizvod (drugi.uzmi ()));
        else if (op.equals(oper[3]))
          rezult.postavi (prvi.uzmi ().kolicnik (drugi.uzmi ()));
        rez.setText (op); rez.setForeground (Color.BLACK);
      } catch (NumberFormatException g) {
        rez.setText ("GRESKA"); rez.setForeground (Color.RED);
        validate();
      }
    }
  } // class DugmeAkcija

   private PoljeT () {                        // Inicijalizacija:
    super ("Kompleksna aritmetika");
    setBounds (100, 100, 300, 150); setResizable (false);
    popuniProzor ();                          // - popunjavanje prozora,
    addWindowListener (new WindowAdapter () { // - obrada dogadjaja prozora.
      public void windowClosing (WindowEvent d) { dispose (); }
    });
  } // PoljeT()

 public static void main (String[] varg)      // Glavna funkcija.
    { new PoljeT ().setVisible (true); }

} // class PoljeT