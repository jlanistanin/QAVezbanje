// PingPong.java - Crtanje ping-pong loptice u apletu.

import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class PingPong extends Applet implements Runnable {

  private Thread nit = new Thread (this);  // Nit apleta.
  private boolean radi = false;            // Da li nit treba da radi?
  private int sir, vis,                    // Sirina i visina apleta.
              r,                           // Poluprecnik loptice.
              x, y,                        // Koordinate centra loptice.
              dx, dy,                      // Korak duz x i y-ose.
              dt;                          // Vreme izmedju dva koraka.
  private Color boja;                      // Boja loptice.

  public void init () {                    // Inicijalizacija apleta:
    sir   = Integer.parseInt (getParameter ("width"));  // - dohvatanje
    vis   = Integer.parseInt (getParameter ("height")); //   parametara,
    dx    = Integer.parseInt (getParameter ("dx"));
    dy    = Integer.parseInt (getParameter ("dy"));
    r     = Integer.parseInt (getParameter ("r"));
    int b = Integer.parseInt (getParameter("boja"), 16);
    boja  = new Color (b>>>16, (b>>>8)&255, b&255);
    dt    = Integer.parseInt (getParameter ("dt"));
    nit.start ();                                       // - pokretanje niti.
  }

  public synchronized void start ()            // Aktiviranje apleta.
    { radi = true; notify (); }

  public void stop () { radi = false; }        // Deaktiviranje apleta.

  public void destroy () { nit.interrupt (); } // Unistavanje apleta.

  public void run () {                      // Telo niti:
    try {
      while (!nit.interrupted ()) {
        if (!radi)
          synchronized (this) { if (!radi) wait (); } // - pauziranje,
        if (dx>0 && x+dx+2*r>=sir ||        // - promena smera duz x-ose,
            dx<0 && x+dx<0          ) dx = -dx;
        if (dy>0 && y+dy+2*r>=vis ||        // - promena smera duz y-ose,
            dy<0 && y+dy<0          ) dy = -dy;
        x += dx;                            // - nove koordinate,
        y += dy;
        repaint ();                         // - ponovno iscrtavanje,
        nit.sleep (dt);                     // - cekanje do narednog koraka.
      }
    } catch (InterruptedException g) {}
  }

  public void paint (Graphics g) {          // Iscrtavanje apleta.
    g.setColor (Color.RED);
    g.drawRect (0, 0, sir-1, vis-1);
    g.setColor (boja);
    g.fillOval (x, y, 2*r, 2*r);
  }
}