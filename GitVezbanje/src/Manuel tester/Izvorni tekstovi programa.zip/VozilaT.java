// VozilaT.java - Ispitivanje klasa vozila.

import vozila.*;

public class VozilaT {
  public static void main (String[] vpar) {
    Vozilo[] vozila = new Vozilo [100]; int n = 0;
    radi: while (true) {
      System.out.print ("\nVrsta vozila (T,P,*)? ");
      switch (Citaj.Char ()) {
        case 't': case 'T':
          System.out.print ("Sopstvena tezina?     ");
          double sTez = Citaj.Double ();
          System.out.print ("Tezina tereta?        ");
          double ter  = Citaj.Int ();;
          vozila[n++] = new TVozilo (sTez, ter);
          break;
        case 'p': case 'P':
          System.out.print ("Sopstvena tezina?     ");
                 sTez  = Citaj.Double ();
          System.out.print ("Sr. tezina putnika?   ");
          double srTez = Citaj.Double ();
          System.out.print ("Broj putnika?         ");
          int    brPut = Citaj.Int ();
          vozila[n++] = new PVozilo (sTez, srTez, brPut);
          break;
        case '*': break radi;
        default:
          System.out.println ("*** Nepoznata vrsta vozila!");
      }
    }
    System.out.print ("\nNosivost mosta?       ");
    double nosivost = Citaj.Double ();
    System.out.print ("\nMogu da predju most:\n");
    for (int i=0; i<n; i++)
      if (vozila[i].tezina() <= nosivost)
        System.out.println (vozila[i] + " - " + vozila[i].tezina());
  }
}
