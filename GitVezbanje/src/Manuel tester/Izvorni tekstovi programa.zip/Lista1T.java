// Lista1T.java - Ispitivanje klase listi celih brojeva.

public class Lista1T {
  public static void main (String[] vpar) {
    Lista1 lst = new Lista1 ();
    radi: while (true) {
      System.out.print (
        "\n1. Dodavanje broja na pocetak liste\n"      +
          "2. Dodavanje broja na kraj liste\n"         +
          "3. Umetanje broja u uredjenu listu\n"       +
          "4. Izostavljanje broja iz liste\n"          +
          "5. Brisanje svih elemenata liste\n"         +
          "6. Citanje uz obrtanje redosleda brojeva\n" +
          "7. Citanje uz cuvanje redosleda brojeva\n"  +
          "8. Odredjivanje duzine liste\n"             +
          "9. Ispisivanje liste\n"                     +
          "0. Zavrsetak rada\n\n"                      +
          "Vas izbor? "
      );
      int izbor = Citaj.Int ();
      switch (izbor) {
        case 1: case 2: case 3: case 4:
          System.out.print ("Broj?      "); int broj = Citaj.Int ();
          switch (izbor) {
            case 1: // Dodavanje broja na pocetak liste:
              lst.naPocetak (broj); break;
            case 2: // Dodavanje broja na kraj liste:
              lst.naKraj (broj);    break;
            case 3: // Umetanje broja u uredjenu listu:
              lst.umetni (broj);    break;
            case 4: // Izostavljanje broja iz liste:
              lst.izostavi (broj);  break;
          } break;
        case 5: // Praznjenje liste:
          lst.prazni (); break;
        case 6: case 7: // Citanje liste ...
          System.out.print ("Duzina?    "); int n = Citaj.Int ();
          System.out.print ("Elementi?  ");
          switch (izbor) {
            case 6: // ... uz obrtanje redosleda brojeva:
              lst.citaj1 (n); break;
            case 7: // ... uz cuvanje redosleda brojeva:
              lst.citaj2 (n); break;
          } break;
        case 8: // Odredjivanje du�ine liste:
          System.out.println ("Duzina=    " + lst.duz()); break;
        case 9: // Ispisivanje liste:
          System.out.println ("Lista=     " + lst); break;
        case 0: // Zavrsetak rada:
          break radi;
        default:// Pogresan izbor:
          System.out.println ("*** Nedozvoljen izbor!"); break;
      }
    }
  }
}
