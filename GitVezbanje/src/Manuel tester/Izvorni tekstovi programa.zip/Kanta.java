// Kanta.java - Klasa kanti.

public class Kanta extends Valjak {

  private double puno;                           // Napunjeni deo.

  public Kanta (double rr, double hh, double pp) // Inicijalizacija
    { super (rr,hh); puno = pp<=V() ? pp : V(); }

  public Kanta (double rr, double hh)            //   (prazna kanta).
    { this (rr, hh, 0); }

  public double ima  () { return puno; }         // Koliko ima tecnosti?

  public double fali () { return V() - puno; }   // Koliko tecnosti fali?

  public boolean puna () { return puno == V(); } // Da li je puna?

  public boolean prazna () { return puno == 0; } // Da li je prazna?

  public Kanta dolij (double dopuna) {           // Dolivanje.
    puno = (puno+dopuna <= V()) ? puno+dopuna : V();
    return this;
  }

  public Kanta odlij (double odliv) {            // Odlivanje.
    if (puno-odliv > 0) puno -= odliv; else puno = 0;
    return this;
  }

  public Kanta presipaj (Kanta k) {              // Presipanje.
    if (this != k) {
      double prazno = V() - puno;
      if (prazno >= k.puno) { puno += k.puno; k.puno = 0; }
        else { puno = V(); k.puno -= prazno; }
    }
    return this;
  }

  public String  toString ()                     // Tekstualni oblik.
    { return '{' + super.toString() + ',' + puno + '}'; }
}