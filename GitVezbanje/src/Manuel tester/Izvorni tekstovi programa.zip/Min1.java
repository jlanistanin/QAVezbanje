// min1.java - Najmanji od tri broja.

public class Min1 {
  public static void main (String[] vpar) {
    System.out.print ("Tri broja? ");
    int a = Citaj.Int (), b = Citaj.Int (), c = Citaj.Int ();
    int min = a;
    if (b < min) min = b;
    if (c < min) min = c;
    System.out.println ("Najmanji=  " + min);
  }
}
