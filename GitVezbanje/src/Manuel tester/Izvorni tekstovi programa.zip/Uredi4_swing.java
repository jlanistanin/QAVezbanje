// Uredi4.java - Uredjivanje niza celih brojeva u grafickom okruzenju.

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import uredjeni.*;
import usluge.Uporedljiv;

public class Uredi4 extends JFrame {
  
  private static String[] duzine =                // Moguce duzine niza.
    { "100", "200", "500", "1000", "2000", "5000" };
  private static Uredjivac[] uredjivaci = {       // Algoritmi uredjivanja.
    new MetodaIzbora (), new MetodaIzbora2 (),
    new MetodaUmetanja (), new MetodaUmetanja2 (),
    new MetodaZameneSuseda (), new BrzaMetoda ()
  };
  private Uporedljiv[] niz = new Celi [100];      // Niz za uredjivanje.
  private Uredjivac uredjivac = uredjivaci[0];    // Trenutni uredjivac.
  private JTextArea prikaz = new JTextArea ();    // Polje za prikaz niza.
  private ButtonGroup grupa = new ButtonGroup (); // Grupa radio dugmadi.
  
  private void puni () {              // Punjenje niza slucajnim brojevima.
    for (int i=0; i<niz.length; i++)
      niz[i] = new Celi ((int)(Math.random ()*10));
    prikazi ();
  }
  
  private void prikazi () {           // Prikazivanje sadrzaja niza.
    int k = prikaz.getWidth () / 10; String s = "";
    for (int i=0; i<niz.length; i++)
      s += niz[i] + ((k==0 || i%k==k-1||i==niz.length-1)?"\n":" ");
    prikaz.setText (s);
  }
  
  private Uredi4 () {                // SASTAVLJANJE PROZORA (konstruktor).
    super ("Uredjivanje nizova");
    setBounds (100, 100, 400, 200);
    addWindowListener (new WindowAdapter () {
      public void windowClosing (WindowEvent d) { System.exit(0); }
    } );
    setLayout (new BorderLayout());
    JPanel ploca = new JPanel (); add (ploca, "East");
    ploca.setLayout (new GridLayout(0,1));
    
    puni ();              // Viseredno polje za tekst za prikazivanje niza.
    prikaz.addComponentListener (new ComponentAdapter() {
      public void componentResized (ComponentEvent d) { prikazi (); }
    } );
    add (new JScrollPane (prikaz), "Center");
    
    JComboBox duzina = new JComboBox ();             // Padajuca lista za
    for (int i=0; i<duzine.length; i++)              //    izbor duzine.
      duzina.addItem(duzine[i]);
    duzina.addItemListener (new ItemListener () {
      public void itemStateChanged (ItemEvent d) {
        int duz = Integer.parseInt 
          ((String)((JComboBox)d.getSource ()).getSelectedItem ());
        niz = new Celi [duz]; puni ();
      }
    } );
    ploca.add (duzina);
    
    RadioPromena osmatrac = new RadioPromena ();     // Radio dugmad za
    for (int i=0; i<uredjivaci.length; i++) {        //   izbor algoritma.
      JRadioButton radio = new JRadioButton (uredjivaci[i].toString());
      radio.addItemListener (osmatrac);
      if (i == 0) radio.setSelected (true);
      grupa.add (radio); ploca.add (radio);
    }
    puni ();
   
    JMenuBar traka = new JMenuBar(); setJMenuBar(traka);  // Sastavljanje
    int ctrl = java.awt.Event.CTRL_MASK;                  //   menija.
    JMenu meni = new JMenu ("Akcija"); traka.add (meni);
    JMenuItem stavka = new JMenuItem ("Pravi");
    stavka.setAccelerator (KeyStroke.getKeyStroke ('P', ctrl));
    stavka.addActionListener (new ActionListener () {
      public void actionPerformed (ActionEvent d) { puni (); }
    } );
    meni.add (stavka);
    stavka = new JMenuItem ("Radi");
    stavka.setAccelerator (KeyStroke.getKeyStroke ('R', ctrl));
    stavka.addActionListener (new ActionListener () {
      public void actionPerformed (ActionEvent d) 
        { uredjivac.uredi (niz); prikazi (); }
    } );
    meni.add (stavka);
    meni.addSeparator();
    stavka = new JMenuItem ("Zavrsi");
    stavka.setAccelerator (KeyStroke.getKeyStroke ('Z', ctrl));
    stavka.addActionListener (new ActionListener () {
      public void actionPerformed (ActionEvent d) { System.exit (0); }
    } );
    meni.add (stavka);
    setVisible (true);
  } // Konstruktor
  
  private class RadioPromena implements ItemListener { // Promena stanja
    public void itemStateChanged (ItemEvent d) {       //   radio dugmeta.
      String naziv = ((JRadioButton)d.getSource()).getText();
      int i; for (i=0; i<uredjivaci.length; i++)
        if (naziv.equals(uredjivaci[i].toString())) break;
      (uredjivac = uredjivaci[i]).uredi (niz); prikazi ();
    }
  }
  
  public static void main (String[] vpar)              // Glavna funkcija.
    { new Uredi4 (); }
}