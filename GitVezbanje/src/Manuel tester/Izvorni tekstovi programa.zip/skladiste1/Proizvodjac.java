// Proizvodjac.java - Klasa proizvodjaca.

package skladiste1;

public class Proizvodjac extends Thread {

  private static int ukId = 0;    // Poslednje korisceni identifikator.
  private int id = ++ukId;        // Identifikator proizvodjaca.
  private Skladiste skladiste;    // Pridruzeno skladiste.
  private int minVreme, maxVreme; // Najkrace i najduze vreme proizvodnje.
  private int broj;               // Poslednje proizvedeni podatak.

  public Proizvodjac                            // Inicijalizacija.
    (Skladiste sklad, int minVr, int maxVr) { 
    minVreme = minVr; maxVreme = maxVr; 
    skladiste = sklad;
  }
  
  public Proizvodjac (Skladiste sklad) 
    { this (sklad, 1000, 2000); }
  
  public void run () {                          // Telo niti.
    System.out.println ("Proizv " + id + " krenuo");
    try {
      while (! interrupted ()) {
        sleep ((long)(minVreme + Math.random() * (maxVreme-minVreme)));
        int vredn = id*1000 + ++broj; 
        System.out.println ("Proizv " + id + " stavlja " + vredn);
        skladiste.stavi (vredn);
      }
    } catch (InterruptedException g) {}
    System.out.println ("Proizv " + id + " zavrsio");
  }
}