// Izvestac.java - Klasa izvestaca.

package skladiste1;

public class Izvestac extends Thread {
  private static int ukId = 0;    // Poslednje korisceni identifikator.
  private int id = ++ukId;        // Identifikator izvestaca.
  private Skladiste skladiste;    // Pridruzeno skladiste.
  private int perioda;            // Perioda izvestavanja.

  public Izvestac (Skladiste sklad, int per) { // Inicijalizacija.
    perioda = per; skladiste = sklad;
  }
  
  public Izvestac (Skladiste sklad) 
    { this (sklad, 5000); }
  
  public void run () {                         // Telo niti.
    System.out.println ("Izvest " + id + " krenuo");
    try {
      while (! interrupted ()) {
        sleep (perioda);
        System.out.println ("Izvest " + id + " [" + skladiste + "]");
      }
    } catch (InterruptedException g) {}
    System.out.println ("Izvest " + id + " zavrsio");
  }
}