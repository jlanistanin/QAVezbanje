// Potrosac.java - Klasa potrosaca.

package skladiste1;

public class Potrosac extends Thread {
  
  private static int ukId = 0;    // Poslednje korisceni identifikator.
  private int id = ++ukId;        // Identifikator potrosaca.
  private Skladiste skladiste;    // Pridruzeno skladiste.
  private int minVreme, maxVreme; // Najkrace i najduze vreme potrosnje.

  public Potrosac                               // Inicijalizacija.
    (Skladiste sklad, int minVr, int maxVr) { 
    minVreme = minVr; maxVreme = maxVr; 
    skladiste = sklad;
  }
  
  public Potrosac (Skladiste sklad) 
    { this (sklad, 1000, 2000); }
  
  public void run () {                          // Telo niti.
    System.out.println ("Potros " + id + " krenuo");
    try {
      while (! interrupted ()) {
      int vredn = skladiste.uzmi ();
      System.out.println ("Potros " + id + " uzeo    " + vredn);
      sleep ((long)(minVreme + Math.random() * (maxVreme-minVreme)));
      }
    } catch (InterruptedException g) {}
    System.out.println ("Potros " + id + " zavrsio");
  }
}