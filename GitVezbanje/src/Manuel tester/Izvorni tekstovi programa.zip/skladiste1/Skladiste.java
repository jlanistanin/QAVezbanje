// Skladiste.java - Klasa za uskladistavanje podataka.

package skladiste1;

public class Skladiste {

  private static int ukId = 0; // Poslednje korisceni identifikator.
  private int id = ++ukId;     // Identifikator skladista.
  private int[] niz;           // Niz za uskladistavanje podataka.
  private int ulaz, izlaz;     // Mesto stavljanja i uzimanja podatka.
  private int pun;             // Broj popunjenih mesta.

  public Skladiste (int kap)                     // Inicijalizacija.
    { niz = new int [kap]; }
  
  public synchronized void stavi (int vredn)   // Stavljanje podatka.
    throws InterruptedException {
    while (pun == niz.length) wait ();
    niz[ulaz++] = vredn;
    if (ulaz == niz.length) ulaz = 0;
    pun++;
    notifyAll ();
  }

  public synchronized int uzmi ()             // Uzimanje podatka.
    throws InterruptedException {
    while (pun == 0) wait ();
    int vredn = niz[izlaz++];
    if (izlaz == niz.length) izlaz = 0;
    pun--;
    notifyAll ();
    return vredn;
  }
    
  public synchronized String toString () {      // Tekstualni prikaz.
    StringBuffer s = new StringBuffer ("Sklad " + id + ": ");
    for (int i=0; i<pun; i++)
      s.append (niz[(izlaz+i) % niz.length]).append (' ');
    return s.toString ();
  }
}