// Kompl1.java - Klasa kompleksnih brojeva.

public class Kompl1 {

  private double re, im;                     // Realni i imaginarni deo.

  public Kompl1 () {}                        // Stvaranje kompleksnog broja.
  public Kompl1 (double r) { re = r; }
  public Kompl1 (double r, double i) { re = r; im = i; }

  public double re () { return re; }         // Realni deo.

  public double im () { return im; }         // Imaginarni deo.

  public double abs  ()                      // Apsolutna vrednost.
    { return Math.sqrt (re*re + im*im); }

  public double arg  ()                      // Argument.
    { return (re!=0 || im!=0) ? Math.atan2(im,re) : 0; }

  public Kompl1 postavi (double r, double i) // Postavljanje delova.
    { re = r; im = i; return this; }

  public Kompl1 postaviRe (double r)
    { re = r; return this; }

  public Kompl1 postaviIm (double i)
    { im = i; return this; }

  public Kompl1 postavi (Kompl1 z)
    { re = z.re; im = z.im; return this; }

  public Kompl1 konjg ()                     // Konjugovan broj.
    { return new Kompl1 (re, -im); }

  public Kompl1 zbir (Kompl1 b)              // a += b
    { return new Kompl1 (re+b.re, im+b.im); }

  public Kompl1 razlika (Kompl1 b)           // a -= b
    { return new Kompl1 (re-b.re, im-b.im); }

  public Kompl1 proizvod (Kompl1 b)          // a *= b
    { return new Kompl1 (re*b.re-im*b.im, im*b.re+re*b.im); }

  public Kompl1 kolicnik (Kompl1 b) {        // a /= b
    double c = b.re*b.re + b.im*b.im;
    return new Kompl1 ((re*b.re+im*b.im)/c, (im*b.re-re*b.im)/c);
  }

  public static Kompl1 exp (Kompl1 a) {       // exp (a)
    double abs = Math.exp (a.re), arg = a.im;
    return new Kompl1 (abs*Math.cos(arg), abs*Math.sin(arg));
  }

  public static Kompl1 log (Kompl1 a)         // log (a)
    { return new Kompl1 (Math.log(a.abs()), a.arg()); }

  public static Kompl1 pow (Kompl1 a, Kompl1 b) // pow (a, b)
    { return Kompl1.exp (b.proizvod(Kompl1.log(a))); }

  public static Kompl1 citaj ()              // Citanje.
    { return new Kompl1 (Citaj.Double(), Citaj.Double()); }

  public String toString ()                  // Tekstualni oblik.
    { return String.format ("(%.3f,%.3f)", re, im); }

  // Glavna funkcija za ispitivanje klase Kompl1. =========================
  public static void main (String[] vpar) {
    System.out.print ("Prvi  broj (re,im)? ");
    Kompl1 x = new Kompl1 (Citaj.Double(), Citaj.Double());
    System.out.print ("Drugi broj (re,im)? "); Kompl1 y = Kompl1.citaj ();
    System.out.println ("x      = (" + x.re() + ',' + x.im() + ')');
    System.out.println ("y      = " + y);
    System.out.println ("x+y    = " + x.zbir     (y)   );
    System.out.println ("x-y    = " + x.razlika  (y)   );
    System.out.println ("x*y    = " + x.proizvod (y)   );
    System.out.println ("x/y    = " + x.kolicnik (y)   );
    System.out.println ("exp(x) = " + Kompl1.exp (x)   );
    System.out.println ("log(x) = " + Kompl1.log (x)   );
    System.out.println ("x^y    = " + Kompl1.pow (x, y));
  }
}
