// Sutra.java - Odredjivanje datuma sutrasnjeg dana.

public class Sutra {
  public static void main (String[] vpar) {
    while (true) {
      System.out.print ("Danas? ");
      int dan = Citaj.Int (), mes = Citaj.Int (), god = Citaj.Int ();
    if (dan==0 || mes==0 || god==0) break;

      // Broj dana u tekucem mesecu:
      int d = 0;
      switch (mes) {
        case 1: case 3: case 5: case 7: case 8: case 10: case 12:
          d = 31; break;
        case 4: case 6: case 9: case 11:
          d = 30; break;
        case 2:
          if (god%4==0 && god%100!=0 || god%400==0) d = 29; else d = 28;
          break;
      }

      // Obrazovanje datuma za sledeci dan:
      if (dan < d) dan++;
      else {
        dan = 1;
        if (mes < 12) mes++;
        else { mes = 1; god++; }
      }
      System.out.println ("Sutra= " + dan + "." + mes + "." + god + "\n");
    }
  }
}
