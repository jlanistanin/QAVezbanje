// SekPrik.Java - Prikazivanje sadrzaja sekvencijalne binarne datoteke.

import java.io.*;

public class SekPrik {
  public static void main (String[] varg) {
    try {
      DataInputStream ulaz = new DataInputStream (
                               new FileInputStream (varg[0]));
      while (true) {
        int n = ulaz.readInt ();
        System.out.print (n);
        for (int i=0; i<n; i++) {
          double x = ulaz.readDouble ();
          System.out.print (" " + x);
        }
        System.out.println ();
      }
    } catch (FileNotFoundException g) {
      System.out.println ("*** Greska pri otvaranju datoteke!");
    } catch (EOFException g) {
    } catch (IOException g) {
      System.out.println ("*** Ulazno/izlazna greska!");
    }
  }
}