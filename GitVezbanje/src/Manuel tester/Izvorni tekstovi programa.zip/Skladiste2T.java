// Skladiste2T.java - Ispitivanje sistema proizvodjac/potrosac.

import java.awt.*; import java.awt.event.*;
import usluge.*;   import skladiste2.*;

class Skladiste2T extends Frame {

  private Thread[] niti;

  public Skladiste2T (String[] vpar) {       // SASTAVLJANJE PROZORA I
    super ("Proizvodjaci/potrosaci");        //   INICIJALIZACIJA SISTEMA:
    setBounds (100, 100, 300, 200);

    Panel ploca = new Panel (new GridLayout (1, 3));  // Ploca za natpise.
    add (ploca, "North");
    ploca.add (new Label ("Proizvodjaci:"));
    ploca.add (new Label ("Skladiste:"));
    ploca.add (new Label ("Potrosaci:"));
                                                      // Ploca za podatke.
    add (ploca = new Panel (new GridLayout (1, 3)), "Center");

    ploca.setLayout (new GridLayout (1, 3));
    List lstProizvodjaci = new List ();
    TextArea tksSkladiste = new TextArea ();
    List lstPotrosaci = new List ();
    lstProizvodjaci.setMultipleMode (true);
    lstPotrosaci.setMultipleMode (true);
    ploca.add (lstProizvodjaci);
    ploca.add (tksSkladiste);
    ploca.add (lstPotrosaci);
                                             // Parametri rada:
    int kap    = Integer.parseInt (vpar[0]), // - kapacitet skladista,
        brPro  = Integer.parseInt (vpar[1]), // - broj proizvodjaca,
        minPro = Integer.parseInt (vpar[2]), // - najkrace i najduze vreme
        maxPro = Integer.parseInt (vpar[3]), //   proizvodnje,
        brPot  = Integer.parseInt (vpar[4]), // - broj potrosaca,
        minPot = Integer.parseInt (vpar[5]), // - najkrace i najduze vreme
        maxPot = Integer.parseInt (vpar[6]); //   potrosnje.
    try {
      Skladiste skladiste = new Skladiste (kap, new Polje (tksSkladiste));
      niti = new Thread [brPro + brPot]; int k = 0;
      for (int i=0; i<brPro; i++) {
        lstProizvodjaci.add ("***");
        (niti[k++] = new Proizvodjac (skladiste, minPro, maxPro,
                          new Polje (lstProizvodjaci,i))).start ();
      }
      for (int i=0; i<brPot; i++) {
        lstPotrosaci.add ("***");
        (niti[k++] = new Potrosac (skladiste, minPot, maxPot,
                          new Polje (lstPotrosaci, i))).start ();
      }
    } catch (GKompNeOdgovara g) {}

    addWindowListener (new WindowAdapter () {
      public void windowClosing (WindowEvent d) {
        for (Thread nit: niti) nit.interrupt ();
        dispose ();
      }
    });
  }

  public static void main (String[] vpar) {  // GLAVNA FUNKCIJA.
    new Skladiste2T (vpar).setVisible (true);
  }
}