// VerizanT.java - Ispitivanje klase veriznih razlomaka.

import verizan.*;

public class VerizanT {
  public static void main (String[] varg) {
    while (true) {
      System.out.print ("\nn? "); int n = Citaj.Int ();
    if (n <= 0) break;
      Verizan v = new Verizan (n);
      while (true) {
        System.out.print ("i, a[i]? ");
        try {
          v.postavi (Citaj.Int(), Citaj.Double());
        } catch (GVerInd g) {
          if (g.ind () == -1) break;
          System.out.println (g);
        }
      }
      System.out.println ("\n" + v);
      System.out.print ("\nxmin, xmax, dx? ");
      double xmin = Citaj.Double(), xmax = Citaj.Double(),
             dx = Citaj.Double();
      System.out.println ("\nx\tv(x)\n================================");
      for (double x=xmin; x<=xmax; x+=dx) {
        System.out.print (x + "\t");
        try {
          System.out.println (v.vr (x));
        } catch (GVerNula g) {
          System.out.println ("Ne moze!");
        }
      }
    }
  }
}