// Recnik.java - Klasa recnika.

import java.io.*;

public class Recnik implements Serializable {

  private static final long serialVersionUID = 1L; // Broj verzije klasa.
  private String imeDat;       // Ime datoteke za trajno uskladistavanje.
  private Rec prva;            // Prva rec u recniku.
  private boolean menjano;     // Da li je recnik u memoriji menjan?

  private Recnik (String ime) { imeDat = ime; } // Nov prazan recnik.

  public static Recnik otvori (String imeDat) { // Otvaranje recnika.
    try {
      ObjectInputStream dat = new ObjectInputStream (
                                new FileInputStream (imeDat));
      Recnik recnik = (Recnik)dat.readObject ();
      dat.close ();
      return recnik;
    } catch (FileNotFoundException g) { // - datoteka ne postoji,
      return new Recnik (imeDat);       //   stvara se prazan recnik.
    } catch (IOException g) {
      System.out.println (g); System.exit (1); return null;
    } catch (ClassNotFoundException g) {
      System.out.println (g); System.exit (1); return null;
    }
  }

  public Recnik snimi () {              // Snimanje recnika u datoteku.
    try {
      if (menjano) {
        ObjectOutputStream dat = new ObjectOutputStream (
                                   new FileOutputStream (imeDat));
        dat.writeObject (this);
        dat.close ();
        menjano = false;
      }
    } catch (IOException g) {
      System.out.println (g); System.exit (1);
    }
    return this;
  }

  public Recnik dodaj (String rec, String prevod) { // Dodavanje prevoda.
    Rec tek = prva, pret = null;
    while (tek!=null && rec.compareToIgnoreCase(tek.rec)>0)
      { pret = tek; tek = tek.sled; }
    if (tek!=null && rec.equalsIgnoreCase(tek.rec)) tek.dodaj (prevod);
      else new Rec (rec, prevod, pret);
    return this;
  }

  public Recnik brisi (String rec) {    // Brisanje reci sa svim prevodima.
    Rec tek = prva, pret = null;
    while (tek!=null && !rec.equalsIgnoreCase(tek.rec))
      { pret = tek; tek = tek.sled; }
    if (tek != null) {
      if (pret == null) prva = tek.sled; else pret.sled = tek.sled;
      menjano = true;
    }
    return this;
  }

  public Recnik brisi (String rec, String prevod) { // Brisanje jednog
    Rec tek = prva, pret = null;                    //   prevoda.
    while (tek!=null && !rec.equalsIgnoreCase(tek.rec))
      { pret = tek; tek = tek.sled; }
    if (tek != null) tek.brisi (prevod);
    return this;
  }

  public String[] prevodi (String rec) { // Dohvatanje svih prevoda reci.
    Rec tek = prva;
    while (tek!=null && !rec.equalsIgnoreCase(tek.rec)) tek = tek.sled;
    if (tek != null) return tek.prevodi (); else return null;
  }

  public String toString () {            // Tekstualni oblik recnika.
    StringBuffer s = new StringBuffer ();
    for (Rec tek=prva; tek!=null; tek=tek.sled)
      s.append (tek).append ('\n');
    return s.toString ();
  }

  private class Rec implements Serializable {     // KLASA ZA JEDNU REC.

    String rec;           // Tekst reci.
    int brPrev;           // Broj prevoda.
    Prevod prvi;          // Prvi prevod.
    Rec sled;             // Sledeca rec u recniku.

    Rec (String rec, String prevod, Rec iza) { // Stvaranje nove reci.
      this.rec = rec; new Prevod (prevod, prvi);
      if (iza == null) { sled = prva; prva = this; }
        else { sled = iza.sled; iza.sled = this; }
    }

    Rec dodaj (String prevod) {                // Dodavanje novog prevoda.
      Prevod tek = prvi, pret = null;
      while (tek!= null && prevod.compareToIgnoreCase(tek.prevod)>0)
        { pret = tek; tek = tek.sled; }
      if (tek==null || !prevod.equalsIgnoreCase(tek.prevod))
        new Prevod (prevod, pret);
      return this;
    }

    Rec brisi (String prevod) {                // Brisanje datog prevoda.
      Prevod tek = prvi, pret = null;
      while (tek!= null && prevod.compareToIgnoreCase(tek.prevod)>0)
        { pret = tek; tek = tek.sled; }
      if (tek!=null && prevod.equalsIgnoreCase(tek.prevod)) {
        if (pret == null) prvi = tek.sled; else pret.sled = tek.sled;
        brPrev--; menjano = true;
      }
      return this;
    }

    String[] prevodi () {                      // Dohvatanje svih prevoda.
      String[] rez = new String [brPrev];
      int i = 0;
      for (Prevod tek=prvi; tek!=null; tek=tek.sled) rez[i++] = tek.prevod;
      return rez;
    }

    public String toString () {    // Tekstualni oblik reci s prevodima.
      StringBuffer s = new StringBuffer ();
      s.append (rec).append (':');
      for (Prevod tek=prvi; tek!=null; tek=tek.sled) {
        s.append (' ').append (tek.prevod)
         .append (tek.sled!=null ? ',' : '.');
      }
      return s.toString ();
    }

    private class Prevod implements Serializable { // KLASA ZA JEDAN PREVOD.

      String prevod;                  // Tekst prevoda.
      Prevod sled;                    // Sledeci prevod.

      Prevod (String p, Prevod iza) { // Stvaranje novog prevoda.
        prevod = p;
        if (iza == null) { sled = prvi; prvi = this; }
          else { sled = iza.sled; iza.sled = this; }
        brPrev++; menjano = true;
      }
    } // class Prevod
  } // class Rec
} // class Recnik