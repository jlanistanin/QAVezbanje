// OtporniciT.java - Ispitivanje klasa otpornika.

import otpornici.*;

public class OtporniciT {

  private static ApstraktanOtpornik citaj () {         // Citanje otpornika.
    String vrs = Citaj.String ();
    if (vrs.equalsIgnoreCase ("prost"))
      return new ProstOtpornik (Citaj.Double ());
    else if (vrs.equalsIgnoreCase ("redna"))
      return citaj (new RednaVezaOtpornika ());
    else if (vrs.equalsIgnoreCase ("paralelna"))
      return citaj (new ParalelnaVezaOtpornika ());
    else
      return null;
  }

  private static SlozenOtpornik citaj (SlozenOtpornik R) { // Citanje
    while (true) {                                         //   slo�enog
      ApstraktanOtpornik r = citaj ();                     //   otpornika.
    if (r == null) return R;
      R.dodaj (r);
    }
  }

  public static void main (String[] vpar) {               // Glavna funkcija.
    ApstraktanOtpornik R;
    while ((R = citaj()) != null)
      System.out.println (R + " = " + R.otpornost());
  }
}