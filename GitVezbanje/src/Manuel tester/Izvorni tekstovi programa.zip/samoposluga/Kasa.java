// Kasa.java - Klasa kasa samoposluge.

package samoposluga;
import  usluge.Polje;
import  java.awt.Color;

class Kasa extends Thread {

  private static int ukId = 0;  // Poslednje korisceni identifikator.
  private int id = ++ukId;      // Identifikator kase.
  private int maxNaplata;       // Najduze vreme naplacivanja.
  private Samoposluga samoposl; // Vlasnicka samoposluga.
  private Polje polje;          // Polje za prikaz stanja kase.
  private Red red;              // Red ispred kase.
  private boolean radi = true;  // Da li radi?

  Kasa (Samoposluga samop, int maxNapl, Polje p, Polje pRed) { // Inicijali-
    samoposl = samop; maxNaplata  = maxNapl;                   //   zacija.
    red = new Red (pRed);
    if ((polje = p) != null) {
      polje.komponenta ().setForeground (Color.black);
      polje.pisi ("Kasa" + id);
    }
    start ();
  }

  public void run () {                          // Telo niti.
    try {
      while (! interrupted ()) {
        if (!radi) synchronized (this) { wait (); }
        Kupac kupac = red.uzmi ();
        if (polje != null) polje.pisi ("Kasa" + id + ": " + kupac.id());
        sleep ((long)(Math.random() * maxNaplata));
        kupac.naplaceno ();
        if (polje != null) polje.pisi ("Kasa" + id);
      }
    } catch (InterruptedException g) {}
  }

  synchronized void zatvori () {                // Zatvaranje kase.
    radi = false;
    if (polje != null) polje.komponenta ().setForeground (Color.red);
  }

  synchronized void otvori () {                 // Otvaranje kase.
    radi = true; notify ();
    if (polje != null) polje.komponenta ().setForeground (Color.black);
  }

  synchronized void unisti ()                   // Zavrsetak niti.
    { interrupt (); }

  void staviURed (Kupac kupac)                  // Stavljanje kupca u red.
    { red.stavi (kupac); }

  int id () { return id; }              // Dohvatanje identifikatora kase.
}