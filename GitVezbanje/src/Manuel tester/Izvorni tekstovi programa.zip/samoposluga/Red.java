// Red.java - Klasa reda kupaca.

package samoposluga;
import  usluge.Polje;

class Red {

  private class Elem {           // ELEMENT REDA:
    Kupac kupac;                 // - kupac u redu,
    Elem  sled;                  // - sledeci element reda,
    Elem (Kupac k) {             // - stavljanje elementa u listu.
      kupac = k;
      if (prvi == null) prvi = this; else posl.sled = this;
      posl = this;
    }
  }

  private Elem prvi, posl;       // Pocetak i kraj reda.
  private Polje polje;           // Polje za prikaz stanja reda.

  Red (Polje p) { polje = p; }   // Dohvatanje pridruzenog polja.

  synchronized void stavi (Kupac kupac) { // Stavljanje kupca u red.
    new Elem (kupac); notifyAll ();
    if (polje != null) polje.pisi (toString ());
  }

  synchronized Kupac uzmi () throws InterruptedException { // Vadjenje
    while (prvi == null) wait ();                          //   prvog
    Kupac kupac = prvi.kupac;                              //   kupca iz
    prvi = prvi.sled; if (prvi == null) posl = null;       //   reda.
    if (polje != null) polje.pisi (toString ());
    return kupac;
  }

  public synchronized String toString () {           // Tekstualni oblik
    StringBuffer s = new StringBuffer ();            //   sadrzaja reda.
    for (Elem tek=prvi; tek!=null; tek=tek.sled)
      s.append (tek.kupac.id()).append ('\n');
    return s.toString ();
  }
}