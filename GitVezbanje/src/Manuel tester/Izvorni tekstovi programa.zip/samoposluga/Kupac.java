// Kupac.java - Klasa kupaca samoposluge.

package samoposluga;

class Kupac extends Thread {

  private static int ukId = 0;    // Poslednje korisceni identifikator.
  private int id = ++ukId;        // Identifikator kupca.
  private int maxKupovina;        // Najduze vreme biranja robe.
  private Samoposluga samoposl;   // Samoposluga u kojoj se nalazi.

  Kupac (Samoposluga samop, int maxKup)                 // Inicijalizacija.
    { samoposl = samop; maxKupovina = maxKup; start (); }

  public void run () {                                  // Telo niti:
    try {                                               // - izbor robe,
      sleep ((long)(Math.random () * maxKupovina));
      Kasa[] kase = samoposl.dohvatiKase ();            // - izbor kase,
      Kasa kasa = kase[(int)(Math.random () * kase.length)];
      kasa.staviURed (this);
      synchronized (this) { wait (); }                  // - cekanje u redu,
      samoposl.izasaoKupac ();                          // - izlazak iz
    } catch (InterruptedException g) {}                 //   samoposluge.
  }
  
  synchronized void naplaceno (){ notify(); }// Dojava da je roba naplacena.

  int id () { return id; }                   // Dohvatanje identifikatora.
}