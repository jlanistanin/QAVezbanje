// Samoposluga.java - Klasa samoposluga.

package samoposluga;
import  usluge.Polje;
import  java.awt.Color;

public class Samoposluga {

  private static int ukId = 0;  // Poslednje korisceni identifikator.
  private int id = ++ukId;      // Identifikator samoposluge.
  private Ulaz[] ulazi;         // Niz ulaza samoposluge.
  private Kasa[] kase;          // Niz kasa samoposluge.
  private Polje polje;          // Polje za prikaz stanja samoposluge.
  private int brojKupaca = 0;   // Broj kupaca u samoposluzi.
  private boolean radi = false; // Da li je samoposluga otvorena?

  public Samoposluga (                          // Inicijalizacija:
    int brUlaza, int brKasa, int maxUlaz, int maxKupovina, int maxNaplata,
    Polje p, Polje[] pUlazi, Polje[] pKase, Polje[] pRedovi) {
    if ((polje = p) != null) {
      polje.komponenta ().setForeground (Color.red);
      polje.pisi ("Kupaca: 0");
    }
    ulazi = new Ulaz [brUlaza];                 // - stvaranje ulaza,
    for (int i=0; i<brUlaza; i++) {
      ulazi[i] = new Ulaz (this, maxUlaz, maxKupovina,
                           (pUlazi!=null ? pUlazi[i] : null));
    }
    kase  = new Kasa [brKasa];                  // - stvaranje kasa.
    for (int i=0; i<brKasa; i++)
      kase[i] = new Kasa (this, maxNaplata,
                          (pKase!=null ? pKase[i] : null),
                          (pRedovi!=null ? pRedovi[i] : null));
  }

  public void otvori () {                       // Otvaranje samoposluge.
    if (polje != null) polje.komponenta ().setForeground (Color.black);
    radi = true;
    for (int i=0; i<ulazi.length; ulazi[i++].otvori());
  }

  public void zatvori () {                      // Zatvaranje samoposluge.
    if (polje != null) polje.komponenta ().setForeground (Color.red);
    radi = false;
    for (int i=0; i<ulazi.length; ulazi[i++].zatvori());
    synchronized (this) {
      while (brojKupaca > 0)
        try { wait (); } catch (InterruptedException g) {}
    }
  }

  synchronized void usaoKupac   () {    // Registrovanje ulaska kupca.
    brojKupaca++;
    if (polje != null) polje.pisi ("Kupaca: " + brojKupaca);
  }

  synchronized void izasaoKupac () {    // Registrovanje izlaska kupca.
    if (--brojKupaca == 0 && !radi) notify ();
    if (polje != null) polje.pisi ("Kupaca: " + brojKupaca);
  }

  public int id () { return id; } // Dohvatanje identifikatora samoposluge.

  Kasa[] dohvatiKase () { return kase; } // Dohvatanje kasa samoposluge.

  public void unisti () {                // Unistavanje samoposluge.
    if (radi) zatvori ();
    for (Ulaz u: ulazi) u.unisti();
    for (Kasa k: kase ) k.unisti();
  }
}