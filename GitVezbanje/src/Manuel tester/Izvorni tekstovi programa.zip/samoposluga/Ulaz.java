// Ulaz.java - Klasa ulaza u samoposlugu.

package samoposluga;

import usluge.Polje;
import java.awt.Color;

class Ulaz extends Thread {

  private static int ukId = 0;     // Poslednje korisceni identifikator.
  private int id = ++ukId;         // Identifikator ulaza.
  private int maxUlaz;             // Najduze vreme izmedju ulazaka kupaca.
  private int maxKupovina;         // Najduze vreme biranja robe.
  private Samoposluga samoposl;    // Vlasnicka samoposluga.
  private Polje polje;             // Polje za prikaz stanja ulaza.
  private boolean radi = false;    // Da li radi?

  Ulaz (Samoposluga samop, int maxUl, int maxKup, Polje p) { // Inicijali-
    samoposl = samop; maxUlaz = maxUl; maxKupovina = maxKup; //   zacija.
    if ((polje = p) != null) {
      polje.komponenta ().setForeground (Color.red);
      polje.pisi ("Ulaz" + id);
    }
    start ();
  }

  public void run () {                          // Telo niti.
    try {
      while (! interrupted ()) {
        if (!radi) synchronized (this) { wait (); }
        sleep ((long)(Math.random() * maxUlaz));
        samoposl.usaoKupac ();
        Kupac kupac = new Kupac (samoposl, maxKupovina);
        if (polje != null) polje.pisi ("Ulaz" + id +": " + kupac.id());
      }
    } catch (InterruptedException g) {}
  }

  synchronized void zatvori () {                // Zatvaranje ulaza.
    radi = false;
    if (polje != null) {
      polje.pisi ("Ulaz" + id);
      polje.komponenta ().setForeground (Color.red);
    }
  }

  synchronized void otvori () {                 // Otvaranje ulaza.
    radi = true; notify ();
    if (polje != null) polje.komponenta ().setForeground (Color.black);
  }

  synchronized void unisti ()                   // Zavrsetak niti.
    { interrupt (); }

  int id () { return id; }       // Dohvatanje identifikatora ulaza.
}