// Tacka.java - Klasa pokretnih tacaka.

package pokretni;

public class Tacka implements Pokretan {

  private static int ukId = 0;   // Poslednje korisceni identifikator.
  private final int id = ++ukId; // Identifikator tacke.
  private Vektor r;              // Vektor polozaja.
  private Brzina v;              // Vektor brzine.

  public Tacka (Vektor rr, Brzina vv) { r = rr; v = vv; }   // Inicijali-
  public Tacka () { r = new Vektor (); v = new Brzina (); } //   zacija.

  public Pokretan proteklo (double dt)            // Promena polozaja zbog
    { r = r.zbir(v.proizvod (dt)); return this; } //   proteklog vremena.

  public Vektor r () { return r; }                // Trenutni polozaj.

  public double rastojanje (Tacka T)              // Rastojanje od druge
    { return r.zbir (T.r.proizvod(-1)).intenzitet(); } // tacke.

  public String toString() { return "T" + id + r; }    // Tekstualni oblik.
}