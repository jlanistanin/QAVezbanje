// Brzina.java - Klasa brzina.

package pokretni;

public class Brzina extends Vektor {

  public Brzina () { super (1, 0, 0); }           // Inicijalizacija.

  public Brzina (double x, double y, double z) { super (x, y, z); }

  public String toString ()                       // Tekstualni oblik.
    { return "v" + super.toString (); }
}