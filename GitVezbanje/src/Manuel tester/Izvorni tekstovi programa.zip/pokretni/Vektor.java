// Vektor.java - Klasa vektora u prostoru.

package pokretni;

public class Vektor {

  private double x, y, z;                         // Komponente vektora.

  public Vektor () {}                             // Inicijalizacija.

  public Vektor (double xx, double yy, double zz)
    { x = xx; y = yy; z = zz; }

  double intenzitet () { return Math.sqrt(x*x+y*y+z*z); } // Intenzitet.

  public Vektor zbir (Vektor v)                   // this + v
    { return new Vektor (x+v.x, y+v.y, z+v.z); }

  public Vektor proizvod (double s)               // this * s
    { return new Vektor (x*s, y*s, z*s); }

  public String toString ()                       // Tekstualni oblik.
    { return "(" + x + "," + y + "," + z + ")"; }
}