// Pokretan.java - Interfejs pokretnih objekata.

package pokretni;

public interface Pokretan {

  Pokretan proteklo (double dt); // Proteklo je vreme dt.
}