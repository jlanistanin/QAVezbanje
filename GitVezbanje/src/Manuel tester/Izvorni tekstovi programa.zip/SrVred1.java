// SrVred1.java - Srednja vrednost brojeva deljivih sa tri.

public class SrVred1 {
  public static void main (String[] vpar) {
    while (true) {
      System.out.print ("n? "); int n = Citaj.Int ();
    if (n < 0) break;
      int[] a = new int [n];
      System.out.print ("A? ");
      for (int i=0; i<n; i++) a[i] = Citaj.Int ();
      double s = 0; int k = 0;
      for (int i=0; i<n; i++)
        if (a[i] % 3 == 0 ) { s += a[i]; k++; }
      if (k != 0) s /= k;
      System.out.println ("s= " + s);
    }
  }
}
