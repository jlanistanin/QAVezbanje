// RadionicaT.java - Ispitivanje klasa masina i radnika.

import radionica.*;

public class RadionicaT {
  public static void main (String[] varg) {
    try {
      MasKvad  m1 = new MasKvad  (0.5, 1, 2, 3);
      MasSfera m2 = new MasSfera (0.7, 2);
      Radnik marko = new Radnik ("Marko");
      System.out.println (marko);
      marko.rasporedi (m1);
      for (int i=0; i<10; i++) marko.napravi ();
      System.out.println (marko);
      marko.rasporedi (m2);
      for (int i=0; i<5; i++)  marko.napravi ();
      System.out.println (marko);
      marko.rasporedi (null);
      for (int i=0; i<12; i++) marko.napravi ();
      System.out.println (marko);
    } catch (GNemaMas g) {
      System.out.println (g);
    }
  }
}