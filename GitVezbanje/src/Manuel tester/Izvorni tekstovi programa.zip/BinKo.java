// BinKo.java - Ispisivanje binomnih koeficijenata.

public class BinKo {
  public static void main (String[] vpar) {
    System.out.print ("nmax? "); int nmax = Citaj.Int ();
    int[] b = new int [nmax+1];
    System.out.println ();
    for (int n=0; n<=nmax; n++) {
      b[n] = 1;
      for (int k=n-1; k>0; k--) b[k] += b[k-1];
      for (int k=0; k<=n; System.out.print (b[k++]+" "));
      System.out.println ();
    }
  }
}
