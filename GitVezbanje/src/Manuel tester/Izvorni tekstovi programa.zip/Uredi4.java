// Uredi4.java - Uredjivanje nizova celih brojeva u grafickom okruzenju.

import java.awt.*;
import java.awt.event.*;
import uredjivaci1.*;
import usluge.Uporediv;

public class Uredi4 extends Frame {

  private static int[] duzine =                   // Moguce duzine niza.
    {100, 200, 500, 1000, 2000, 5000, 10000};
  private static Uredjivac[] uredjivaci = {       // Algoritmi uredjivanja.
    new MetodaIzbora (),       new MetodaIzbora2 (),
    new MetodaUmetanja (),     new MetodaUmetanja2 (),
    new MetodaZameneSuseda (), new MetodaPodele ()
  };
  private Uporediv[] niz = new Ceo [100];         // Niz za uredjivanje.
  private Uredjivac uredjivac = uredjivaci[0];    // Trenutni uredjivac.
  private TextArea prikaz = new TextArea ();      // Polje za prikaz niza.

  private void puni () {              // Punjenje niza slucajnim brojevima.
    for (int i=0; i<niz.length; i++)
      niz[i] = new Ceo ((int)(Math.random ()*10));
    prikazi ();
  }

  private void prikazi () {           // Prikazivanje sadrzaja niza.
    int k = (prikaz.getWidth () - 20) / 10; String s = "";
    for (int i=0; i<niz.length; i++)
      s += niz[i] + ((k==0 || i%k==k-1 || i==niz.length-1) ? "\n" : " ");
    prikaz.setText (s);
  }

  private void popuniProzor () {  // Popunjabanje prozora.
                        // - viseredno polje za tekst za prikazivanje niza,
    prikaz.addComponentListener (new ComponentAdapter () {
      public void componentResized (ComponentEvent d) { prikazi (); }
    });
    puni ();
    add (prikaz, "Center");

    Panel ploca = new Panel (new GridLayout (0, 1)); add (ploca, "East");

    Choice duzina = new Choice ();                   // - padajuca lista za
    for (int d: duzine)                              //   izbor duzine,
      duzina.addItem (Integer.toString (d));
    duzina.addItemListener (new ItemListener () {
      public void itemStateChanged (ItemEvent d) {
        int duz = Integer.parseInt
                    (((Choice)d.getSource ()).getSelectedItem ());
        niz = new Ceo [duz]; puni ();
      }
    });
    ploca.add (duzina);

    CheckboxGroup grupa = new CheckboxGroup ();        // - radio-dugmad za
    RadioPromena osmatrac = new RadioPromena ();       //   izbor algoritma.
    for (int i=0; i<uredjivaci.length; i++) {
      Checkbox radio = new Checkbox (uredjivaci[i].toString(),
                                     grupa, i==0);
      radio.addItemListener (osmatrac);
      ploca.add (radio);
    }
  }

  private class RadioPromena implements ItemListener { // Obrada promene
    public void itemStateChanged (ItemEvent d) {       //   stanja radio-
      String naziv = ((Checkbox)d.getSource ()).getLabel (); // -dugmeta.
      int i; for (i=0; i<uredjivaci.length; i++)
        if (naziv.equals (uredjivaci[i].toString ())) break;
      (uredjivac = uredjivaci[i]).uredi (niz); prikazi ();
    }
  }

  private void dodajMeni() {                           // Sastavljanje menija.
    MenuBar traka = new MenuBar (); setMenuBar (traka);
    Menu meni = new Menu ("Akcija"); traka.add (meni);
    MenuItem stavka = new MenuItem ("Pravi", new MenuShortcut ('P'));
    stavka.addActionListener (new ActionListener () {
      public void actionPerformed (ActionEvent d) { puni (); }
    });
    meni.add (stavka);
    stavka = new MenuItem ("Radi", new MenuShortcut ('R'));
    stavka.addActionListener (new ActionListener () {
      public void actionPerformed (ActionEvent d)
        { uredjivac.uredi (niz); prikazi (); }
    });
    meni.add (stavka);
    meni.addSeparator();
    stavka = new MenuItem ("Zavrsi", new MenuShortcut ('Z'));
    stavka.addActionListener (new ActionListener () {
      public void actionPerformed (ActionEvent d) { dispose (); }
    });
    meni.add (stavka);
  }

   private Uredi4 () {                              // Inicijalizacija.
    super ("Uredjivanje nizova");
    setBounds (100, 100, 370, 200);
    popuniProzor ();
    dodajMeni ();
    setVisible (true);
    addWindowListener (new WindowAdapter () {
      public void windowClosing (WindowEvent d) {dispose (); }
    });
  }

 public static void main (String[] vpar)            // Glavna funkcija.
    { new Uredi4 (); }
}