// Lisazu.java - Crtanje Lisazuovih figura.

import java.awt.*;
import java.awt.event.*;

public class Lisazu extends Frame {

  private static final int N = 300;           // Broj tacaka za crtanje.
  private static final String[] boje =       // Moguce boje.
    { "Crna", "Siva", "Plava", "Zelena", "Zuta", "Crvena"};
  private static final Color[] cboje = { Color.BLACK, Color.GRAY,
    Color.BLUE, Color.GREEN, Color.YELLOW, Color.RED };
  private Color boja = Color.RED;             // Boja u upotrebi.
  private int m = 3, n = 4;                   // Ucestanost po x i y osi.
  private TextField tksM = new TextField (""+m, 5), // Izbor ucestanosti.
                    tksN = new TextField (""+n, 5);
  private Platno platno = new Platno ();      // Platno za crtanje.

  private class Platno extends Canvas {       // KLASA PLATNA ZA CRTANJE.
    public void paint (Graphics g) {
      int a = (getWidth() - 1) / 2, b = (getHeight() - 1) / 2;
      g.translate (a, b);
      g.setColor (boja);
      int x1 = a, y1 = 0;
      for (int i=0; i<=N; i++) {
        double fi = 2 * Math.PI / N * i;
        int x2 = (int)(a * Math.cos (m * fi)),
            y2 = (int)(b * Math.sin (n * fi));
        g.drawLine (x1, y1, x2, y2);
        x1 = x2; y1 = y2;
      }
    }
  } // class Platno

  private class Traka extends MenuBar {       // KLASA TRAKE MENIJA.
    public Traka () {
      Menu meni = new Menu ("Sistem"); add (meni);
      MenuItem stavka = new MenuItem ("Zavrsi"); meni.add (stavka);
      stavka.setShortcut (new MenuShortcut ('Z'));
      stavka.addActionListener (new ActionListener () {
        public void actionPerformed (ActionEvent d) { dispose (); }
      });
      add (meni = new Menu ("Boje"));
      BojaAkcija osmatrac = new BojaAkcija ();
      for (String b: boje) {
        meni.add (stavka = new MenuItem (b));
        stavka.addActionListener (osmatrac);
      }
    } // Traka()
                                        // Klasa osmatraca za izbor boje.
    private class BojaAkcija implements ActionListener {
      public void actionPerformed (ActionEvent d) {
        MenuItem m = (MenuItem)d.getSource();
        for (int i=0; i<boje.length; i++)
          if (m.getLabel().equals(boje[i])) { boja = cboje[i]; break; }
        platno.repaint ();
      }
    } // class BojaAkcija
  } // class Traka

  private class Parametri extends Panel {     // KLASA PLOCE ZA PARAMETRE.
    public Parametri () {
      setBackground (new Color(192, 192, 255));
      add (new Label ("m:", Label.RIGHT)); add (tksM);
      add (new Label ("n:", Label.RIGHT)); add (tksN);
      TextListener osluskivac = new TextListener () {
        public void textValueChanged (TextEvent d) {
          try {
            m = Integer.parseInt (tksM.getText ());
            n = Integer.parseInt (tksN.getText ());
          } catch (NumberFormatException g) {
          } finally { platno.repaint ();
          }
        }
      };
      tksM.addTextListener (osluskivac);
      tksN.addTextListener (osluskivac);
    } // Parametri ()
  } // class Parametri

  private Lisazu () {                        // Konstruktor klase Lisazu.
    super ("Lisazuove figure");
    setSize (300, 200);
    setLocationRelativeTo (null);
    add (platno, "Center");
    add (new Parametri(), "South");
    setMenuBar (new Traka());
    setVisible (true);
    addWindowListener (new WindowAdapter () {
      public void windowClosing (WindowEvent d) { dispose (); }
    });
  } // Lisazu()

  public static void main (String[] varg)              // GLAVNA FUNKCIJA.
    { new Lisazu (); }
} // class Lisazu.