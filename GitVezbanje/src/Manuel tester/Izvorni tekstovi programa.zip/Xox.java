// Xox.java - Organizovanje igre XoX.

import xox.*;
import java.awt.*;
import java.awt.event.*;

public class Xox extends Frame {

  private Font font = new Font (null, Font.BOLD, 24); // Font za natpise.

  private class PloIgrac extends Panel { // PLOCA ZA IZBOR IGRACA:
                                      // Radio dugmad za izbor vrste igraca.
    private CheckboxGroup grupa = new CheckboxGroup ();
    private Checkbox rdgCovek   = new Checkbox ("Covek"  , true , grupa),
                     rdgRacunar = new Checkbox ("Racunar", false, grupa);
    private String oznaka;               // Oznaka igraca.
    private Igrac igrac;                 // Pridruzeni igrac.

    PloIgrac (String ozn) {                         // Inicijalizacija:
      oznaka = ozn;                                 // - oznaka igraca,
      Label lbl = new Label (ozn, Label.CENTER);
      lbl.setFont(font);
      ItemListener osmatrac = new ItemListener () { // - osmatrac za izbor
        public void itemStateChanged (ItemEvent d){ //   vrste igraca,
          if ((Checkbox)d.getSource() == rdgCovek)
            igrac = new Covek   (oznaka, tabla);
          else
            igrac = new Racunar (oznaka, tabla);
        }
      };
      rdgCovek  .addItemListener (osmatrac);
      rdgRacunar.addItemListener (osmatrac);
      setLayout (new GridLayout (3,1));             // - popunjavanje ploce,
      add (lbl); add (rdgCovek); add (rdgRacunar);
      igrac = new Covek (oznaka, tabla);            // - pocetni igrac.
    }
  } // class ploIgrac

  private Panel ploTabla = new Panel ();              // Ploca za polja.
  private Tabla tabla = new Tabla (ploTabla);         // Tabla za igru.
  private PloIgrac ploPrvi  = new PloIgrac ("X");     // Ploce za izbor
  private PloIgrac ploDrugi = new PloIgrac ("O");     //   vrste igraca.
  private Igra igra;                                  // Igra koja se igra.
  private Label stanje = new Label ("", Label.CENTER);// Natpis stanja igre.

  private void popuniProzor () {                    // Popunjavanje prozora:
    add (ploTabla, "Center");                       // - ploca za tablu,
    add (ploPrvi , "West"  );                       // - ploce za izbor
    add (ploDrugi, "East"  );                       //   vrste igraca,

    Button dugme = new Button ("Nova igra");        // - dugme za pocetak
    dugme.addActionListener (new ActionListener (){ //   nove igre,
      public void actionPerformed (ActionEvent d) {
        if (igra != null) igra.prekini ();
        igra = new Igra (tabla, ploPrvi.igrac, ploDrugi.igrac, stanje);
      }
    });
    add (dugme, "South");
    stanje.setFont (font);                          // - natpis stanja igre.
    add (stanje, "North");
  }

  public Xox () {                                   // Inicijalizacija:
    super ("XoX");
    setBounds (100, 100, 300, 200);
    popuniProzor ();                                // - popunjavanje prozora,
    setVisible (true);

    addWindowListener (new WindowAdapter () {       // - obrada zatvaranja
      public void windowClosing (WindowEvent d)     //   prozora,
        { if (igra != null) igra.prekini (); dispose (); }
    });
  } // konstruktor

  public static void main (String[] varg)           // GLAVNA FUNKCIJA.
    { new Xox (); }
}