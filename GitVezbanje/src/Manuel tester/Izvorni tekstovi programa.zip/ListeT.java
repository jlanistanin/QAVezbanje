// ListeT.java - Ispitivanje klase listi.

import usluge.Greska;
import liste.*;
import predmeti1.*;

public class ListeT {
  public static void main (String[] varg) {
    Lista lst = new Lista ();
    lst.dodaj (new Double (2.5));
    lst.dodaj (new Sfera (1, 2));
    lst.dodaj (new Short ((short)12));
    lst.dodaj (new Kvadar (2, 3, 4, 5));
    lst.dodaj (new Sfera (5, 1));
    System.out.println ("Pocetna lista: " + lst);
    double V = 0;
    for (lst.naPrvi(); lst.imaTek();)
      try {
        if (lst.dohvatiTek() instanceof Predmet) {
          V += ((Predmet)lst.izvadiTek()).V ();
        } else lst.naSledeci ();
      } catch (Greska g) {
        System.out.println ("NEOCEKIVANO: " + g);
      }
    System.out.println ("Ukupna zapremina predmeta: " + V);
    System.out.println ("Skracena lista: " + lst);
    try {
      lst.naPrvi ();
      System.out.print ("Pisanje pojedinacno: ");
      while (true) System.out.print (lst.izvadiTek() + " ");
    } catch (Greska g) {
      System.out.println ("\n" + g);
    }
  }
}