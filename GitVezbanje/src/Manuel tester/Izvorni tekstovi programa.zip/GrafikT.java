// GrafikT.java - Ispitivanje klase za crtanje grafika funicije.

import grafik.Grafik;

public class GrafikT {

  public static void main (String[] varg) { new Grafik (); }
}
