// PolicaT.java - Ispitivanje klase polica za predmete.

import polica.*;
import predmeti1.*;

public class PolicaT {
  
  private static class Greska extends Exception { // Klasa za lokalne
    String por;                                   //   greske.
    Greska (String p) { por = p; }
    public String toString () { return "*** GRESKA: " + por; }
  }

  private static Predmet citaj () throws Greska { // Citanje predmeta.
    System.out.print ("Vrsta (S-sfera, K-kvadar)? ");
    Predmet p = null;
    switch (Citaj.Char ()) {
      case 's': case 'S': p = new Sfera ();  break;
      case 'k': case 'K': p = new Kvadar (); break;
      default: throw new Greska ("Nepoznata vrsta predmeta!");
    }
    System.out.print ("Spec. tez. i dimenzije? ");
    p.citaj (); return p;
  }
  
  public static void main (String[] varg) {       // Glavna funkcija.
    Polica p = new Polica (Integer.parseInt (varg[0]),
                           Double.parseDouble (varg[1]));
    radi: while (true) {
      try {
        System.out.print (
          "\n1. Dodavanje na zadato mesto\n"        +
            "2. Dodavanje na prvo slobodno mesto\n" +
            "3. Uzimanje sa zadatog mesta\n"        +
            "4. Stanje police\n"                    +
            "5. Sadrzaj police\n"                   +
            "6. Praznjenje police\n"                +
            "0. Kraj rada\n\n"                      +
            "Vas izbor? "
        );
        switch (Citaj.Char()) {
          case '1': System.out.print ("Indeks? "); int i = Citaj.Int ();
                    p.stavi (citaj (), i);
                    break;
          case '2': p.stavi (citaj ());
                    break;
          case '3': System.out.print ("Indeks? ");
                    System.out.println (p.uzmi(Citaj.Int()));
                    break;
          case '4': System.out.println (
                      "Kapacitet= " + p.kapacitet() + 
                      " slobodno= " + p.slobodno() +
                      "\nNosivost= " + p.nosivost() +
                      " teret= " + p.teret());
                    break;
          case '5': System.out.print (p);
                    break;
          case '6': p.prazni ();
                    break;
          case '0': break radi;
          default : throw new Greska ("Nedozvoljeni izbor!");
        }
      } catch (GPolica g) { System.out.println (g);
      } catch (Greska g)  { System.out.println (g);
      }
    }
  }
}