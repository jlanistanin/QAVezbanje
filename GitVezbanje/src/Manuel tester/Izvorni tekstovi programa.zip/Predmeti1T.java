// Predmeti1T.java - Ispitivanje klasa predmeta.

import predmeti1.*;
import usluge.Citaj;

public class Predmeti1T {
  public static void main (String[] vpar) {
    Predmet[] p = new Predmet [100];
    double q = 0; int n = 0;
    radi: while (true) {
      switch (Citaj.Char ()) {
        case 's': case 'S': p[n] = new Sfera ();  break;
        case 'k': case 'K': p[n] = new Kvadar (); break;
        case '.': break radi;
      }
      if (p[n] != null) {
        p[n].citaj ();
        System.out.println (p[n] + " (Q=" + p[n].Q() + ")");
        q += p[n++].Q ();
      }
    } 
    if (n != 0) q /= n;
    System.out.print ("\nQsr= " + q + "\n\n");
    for (int i=0; i<n; i++)
      if (p[i].Q() > q)
        System.out.println (p[i] + " (Q=" + p[i].Q() + ")");
  }
}