// Tabela2.java - Tabeliranje vrednosti izraza.

public class Tabela2 {
  public static void main (String[] vpar) {
    System.out.print ("n? "); int n = Citaj.Int ();
    System.out.print ("xmin, xmax, dx? ");
    double xmin = Citaj.Double (), xmax = Citaj.Double (),
           dx = Citaj.Double ();
    System.out.print ("\n    x       s\n================\n");
    for (double x=xmin; x<=xmax; x+=dx) {
      double s = 0, p = 1;
      for (int i=1; i<=n; i++) s += (p *= x);
      System.out.format ("%8.3f%8.3f\n", x, s);
    }
  }
}
