// RacBroj.java - Klasa racionalnih brojeva.

public class RacBroj {

  // Zajednicki niz prvih nekoliko prostih brojeva.
  static private final int maxProst = 10000;
  static private final long[] prosti = new long [maxProst];

  static {                     // Generisanje niza prostih brojeva.
    int n = 1;                 //   (zajednicki inicijalizator).
    prosti[0] = 2;
    for (int p=3; n<maxProst; p+=2) {
      boolean prost = true;
      for (int j=0; prosti[j]*prosti[j]<=p; j++)
        if (p % prosti[j] == 0) { prost = false; break; }
      if (prost) prosti[n++] = p;
    }
  }

  private long a, b;                   // Deljenik i delitelj.

  private void sredi () {              // Sredjivanje broja.
    if (a == 0) b = 1;
    else if (b != 0) {
      if (b < 0) { a = -a; b = -b; }
      long absA = a<0 ? -a : a;
      for (int i=0; i < maxProst &&
                    prosti[i]*prosti[i]<=absA &&
                    prosti[i]*prosti[i]<=b; i++) {
        while (a % prosti[i] == 0 && b % prosti[i] == 0) {
          a /= prosti[i]; b /= prosti[i];
        }
      }
    }
  }
                                       // Inicijalizacija:
  public RacBroj () { b = 1; }         // - nula,

  public RacBroj (long a)              // - ceo broj,
    { this.a = a; b = 1; }

  public RacBroj (long a, long b) {    // - razlomljen broj.
    this.a = a; this.b = b;
    sredi ();
  }

  public RacBroj dodaj (RacBroj x) {   // Dodavanje.
    a = a * x.b + x.a * b; b *= x.b;
    sredi (); return this;
  }

  public RacBroj oduzmi (RacBroj x) {  // Oduzimanje.
    a = a * x.b - x.a * b; b *= x.b;
    sredi (); return this;
  }

  public RacBroj pomnozi (RacBroj x) { // Mnozenje.
    a *= x.a; b *= x.b;
    sredi (); return this;
  }

  public RacBroj podeli (RacBroj x) {  // Deljenje.
    a *= x.b; b *= x.a;
    sredi (); return this;
  }

  public String toString () {          // Tekstualni oblik.
    if (b == 0) return "GRESKA";
    if (a == 0) return "0";
    String rez = a / b != 0 ? Long.toString(a / b) : "";
    if (b != 1) {
      if (rez != "" && a>0) rez += "+";
      rez += a%b + "/" + b;
    }
    return rez;
  }
}