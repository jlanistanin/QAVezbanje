// Stek.java - Klasa stekova ogranicenih kapaciteta.

public class Stek {

  private int[] niz;                  // Sardzaj steka.
  private int vrh;                    // Vrh steka.
                                      // Stvaranje steka:
  public Stek ()                      // - kapaciteta 10,
    { niz = new int [10]; vrh = 0; }

  public Stek (int k)                 // - zadatog kapaciteta.
    { niz = new int [k]; vrh = 0; }

  public void stavi (int k) {         // Stavljanje podatka na vrh.
    if (vrh == niz.length) {
      System.out.print ("\n*** Stek je pun ***\n");
      System.exit (1);
    }
    niz[vrh++] = k;
  }

  public int uzmi () {                // Uzmimanje podatka s vrha.
    if (vrh == 0) {
      System.out.print ("\n*** Stek je prazan ***\n");
      System.exit (2);
    }
    return niz[--vrh];
  }

  public void prazni () { vrh = 0; }                  // Praznjenje steka.

  public boolean prazan () { return vrh == 0; }       // Da li je prazan?

  public boolean pun () { return vrh == niz.length; } // Da li je pun?

  public String toString () {                         // Tekstualni oblik.
    String s = "";
    for (int i=vrh; i>0; s+=niz[--i]+" ");
    return s;
  }

  // Glavna funkcija za ispitivanje klase Stek.============================
  public static void main (String[] vpar) {
    Stek s = new Stek ();
    while (! s.pun    ()) { s.stavi (Citaj.Int()); }
    while (! s.prazan ()) { System.out.print (s.uzmi() + " "); }
    System.out.println ();
  }
}
