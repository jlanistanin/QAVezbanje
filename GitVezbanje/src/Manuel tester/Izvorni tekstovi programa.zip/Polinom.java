// Polinom.java - Tabeliranje polinoma zadatog pomocu koeficijenata.

public class Polinom {
  public static void main (String[] vpar) {
    System.out.print ("Red polinoma? "); int n = Citaj.Int ();
    float[] a = new float [n+1];
    System.out.print ("Koeficijenti? ");
    for (int i=n; i>=0; i--) a[i] = Citaj.Float ();
    System.out.print ("xmin,xmax,dx? ");
    float xmin = Citaj.Float (), xmax = Citaj.Float (), dx = Citaj.Float ();
    System.out.print ("\nx\tp(x)\n================\n");
    for (float x=xmin; x<=xmax; x+=dx) {
      float p = a[n];
      for (int i=n-1; i>=0; p=p*x+a[i--]);
      System.out.println (x + "\t" + p);
    }
  }
}
