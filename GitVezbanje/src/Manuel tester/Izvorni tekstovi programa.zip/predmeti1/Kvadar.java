// Kvadar.java - Klasa kvadara.

package predmeti1;
import  usluge.Citaj;

public class Kvadar extends Predmet {

  public static final char VR = 'K';         // Vrsta.

  private double a, b, c;                    // Ivice.

  public Kvadar (double ss, double aa, double bb, double cc) // Inic.
    { super (ss); a = aa; b = bb; c = cc; }

  public Kvadar () { this (1, 1, 1, 1); }

  public char vr () { return VR; }           // Vrsta.

  public double V () { return a * b * c; }   // Zapremina.

  public void citaj () {                     // Citanje.
    super.citaj ();
    a = Citaj.Double (); b = Citaj.Double (); c = Citaj.Double ();
  }

  public String toString () {                // Tekstualni oblik.
    return super.toString() + a + "," + b + "," + c + "]";
  }
}