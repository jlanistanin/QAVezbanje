// Predmet.java - Apstraktna klasa predmeta.

package predmeti1;
import  usluge.Citaj;

public abstract class Predmet {

  private double sigma;                             // Specificna tezina.

  protected Predmet (double ss) { sigma = ss; }     // Inicijalizacija.

  protected Predmet ()          { sigma = 1;  }

  public abstract char vr ();                       // Vrsta.

  public abstract double V ();                      // Zapremina.

  public final double Q () { return V () * sigma; } // Tezina.

  public void citaj () { sigma = Citaj.Double (); } // Citanje.

  public String toString ()                         // Tekstualni oblik.
    { return vr() + "[" + sigma + "|"; }
}