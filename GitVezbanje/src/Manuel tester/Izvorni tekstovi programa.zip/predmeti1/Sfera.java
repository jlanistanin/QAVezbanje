// Sfera.java - Klasa sfera.

package predmeti1;
import  usluge.Citaj;

public class Sfera extends Predmet {

  public static final char VR = 'S';                   // Vrsta.

  private double r;                                    // Poluprecnik.

  public Sfera (double ss, double rr)                  // Inicijalizacija.
    { super (ss);  r = rr; }

  public Sfera () { this (1, 1); }

  public char vr () { return VR; }                     // Vrsta.

  public double V() { return 4./3 * r*r*r * Math.PI; } // Zapremina.

  public void citaj ()                                 // Citanje.
    { super.citaj (); r = Citaj.Double (); }

  public String toString ()                            // Tekstualni oblik.
    { return super.toString() + r + "]"; }
}