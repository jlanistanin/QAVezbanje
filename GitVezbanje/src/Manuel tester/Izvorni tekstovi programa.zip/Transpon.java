// Transpon.java - Transponovanje matrice.

public class Transpon {
  public static void main (String[] vpar) {
    while (true) {

      // Citanje dimenzija matrice:
      System.out.print ("\nBroj vrsta i kolona? ");
      int m = Citaj.Int (), n = Citaj.Int();
    if (m<=0 || n<=0) break;

      // Citanje elemenata matrice:
      int[][] a = new int [m][n];
      for (int i=0; i<m; i++) {
        System.out.print (i+1 +". vrsta? ");
        for (int j=0; j<n; a[i][j++]=Citaj.Int());
      }

      // Obrazovanje transponovane matrice:
      int[][] b = new int [n][m];
      for (int i=0; i<n; i++)
        for (int j=0; j<m; j++) b[i][j] = a[j][i];

      // Zamena stare matrice novom matricom:
      a = b; b = null; int p = m; m = n; n = p;

      // Ispisivanje rezultata:
      System.out.print ("\nTransponovana matrica:\n");
      for (int i=0; i<m; i++) {
        for (int j=0; j<n; System.out.print(a[i][j++]+" "));
        System.out.println ();
      }
    }
  }
}
