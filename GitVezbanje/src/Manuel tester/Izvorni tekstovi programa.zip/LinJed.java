// LinJed.java - Resavanje sistema od dve linearne jednacine.

public class LinJed {
  public static void main (String[] vpar) {
    System.out.print ("Koeficijenti prve jednacine?  ");
    double a1 = Citaj.Double (), b1 = Citaj.Double (), c1 = Citaj.Double ();
    System.out.print ("Koeficijenti druge jednacine? ");
    double a2 = Citaj.Double (), b2 = Citaj.Double (), c2 = Citaj.Double ();
    double D  = a1 * b2 - a2 * b1,
           Dx = c1 * b2 - c2 * b1,
           Dy = a1 * c2 - a2 * c1;
    if (D != 0) {
      double x = Dx / D, y = Dy / D;
      System.out.println ("x= " + x);
      System.out.println ("y= " + y);
    } else
      if (Dx==0 && Dy==0)
        System.out.println ("Sistem je neodredjen.");
      else
        System.out.println ("Sistem je protivrecan.");
  }
}
