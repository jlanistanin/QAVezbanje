// Kompl2.java - Klasa kompleksnih brojeva s grafickim prikazom.

import usluge.Polje;

public class Kompl2 extends Kompl1 {
    
  private Polje rPolje, iPolje;             // Polja za prikaz delova broja.
    
  public Kompl2 (double r, double i, Polje rP, Polje iP) // Inicijalizacija.
    { super (r, i); rPolje = rP; iPolje = iP; prikazi (); }

  public Kompl2 (Polje rP, Polje iP) { this (0, 0, rP, iP); }

  public Kompl2 (double r, double i) { super (r, i); }

  public Kompl2 () {}

  public Kompl2 postavi (double r, double i)          // Postavljanje
    { super.postavi (r, i); prikazi (); return this;} //    vrednosti.

  public Kompl2 postavi (Kompl1 z) { return postavi (z.re(), z.im ()); }
    
  public Kompl2 uzmi () {                             // Uzimanje vrednosti
    if (rPolje != null) postaviRe (rPolje.Double ()); //   iz grafickih
    if (iPolje != null) postaviIm (iPolje.Double ()); //   komponenti.
    return this; 
  }
    
  public Kompl2 prikazi () {                          // Prikaz vrednosti
    if (rPolje != null) rPolje.pisi (re ());          //   u grafickim
    if (iPolje != null) iPolje.pisi (im ());          //   komponentama.
    return this;
  }    
}
