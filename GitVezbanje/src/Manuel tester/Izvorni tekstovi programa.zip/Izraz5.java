// izraz5.java - Izracunavanje slozenog zbira.

public class Izraz5 {
  public static void main (String[] vpar) {
    System.out.print ("n? "); int n = Citaj.Int ();
    double s = 0;
    for (int f=0, g=0, i=1, z=1; i<=n; i++) {
      f += i;
      g += i * i;
      s += z * (double)f / g;
      z = -z;
    }
    System.out.println ("s= " + s);
  }
}
