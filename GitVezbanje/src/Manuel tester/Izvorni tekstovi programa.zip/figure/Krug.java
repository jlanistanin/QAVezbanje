// Krug.java - Klasa krugova u ravni.

package figure;
import  usluge.Citaj;

public class Krug extends Figura {

  private double r;                                       // Poluprecnik.

  public Krug ()                    { super ();   r=1;  } // Inicijaliz.
  public Krug (double rr)           { super ();   r=rr; }
  public Krug (double rr, Tacka tt) { super (tt); r=rr; }

  public double O () { return 2 * r * Math.PI; }              // Obim.

  public double P () { return r * r * Math.PI; }              // Povrsina.

  public void citaj () { super.citaj(); r = Citaj.Double(); } // Citanje.

  public String toString () {                         // Tekstualni oblik.
    return "krug [" + super.toString() + ", r=" + r +
      ", O=" + O() + ", P=" + P() + "]";
  }
}