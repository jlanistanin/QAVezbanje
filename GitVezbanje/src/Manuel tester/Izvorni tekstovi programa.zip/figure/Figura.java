// Figura.java - Apstraktna klasa figura u ravni.

package figure;

public abstract class Figura {

  protected Tacka T;                               // Teziste figure.

  public Figura ()         { T = new Tacka (); }   // Inicijalizacija.
  public Figura (Tacka TT) { T = new Tacka (TT.x, TT.y); }

  public final void postavi (double xx, double yy) // Postavljanje u
    { T.x = xx; T.y = yy; }                        //   novu tacku.

  public final void pomeri  (double dx, double dy) // Pomeranje za
    { T.x += dx; T.y += dy; }                      // dati pomak.

  public abstract double O ();                     // Obim.

  public abstract double P ();                     // Povrsina.

  public void citaj () { T.citaj (); }             // Citanje.

  public String toString () { return "T=" + T; }   // Tekstualni oblik.
}