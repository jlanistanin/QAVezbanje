// Tacka.java - Klasa tacaka u ravni.

package figure;
import  usluge.Citaj;

public class Tacka {

  double x, y;                                    // Koordinate.

  public Tacka () {}                              // Inicijalizacija.
  public Tacka (double xx) { x = xx; }
  public Tacka (double xx, double yy) { x = xx; y = yy; }

  public double x () { return x; }                // Apscisa.

  public double y () { return y; }                // Ordinata.

  public void citaj ()
    { x = Citaj.Double (); y = Citaj.Double (); } // Citanje.

  public String toString ()                       // Tekstualni oblik.
    { return "(" + x + "," + y + ")"; }

  public static final Tacka ORG = new Tacka ();   // Koordinatni pocetak.
}
