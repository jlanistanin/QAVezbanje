// Trougao.java - Klasa trouglova u ravni.

package figure;
import  usluge.Citaj;

public class Trougao extends Figura {

  private double a, b, c;                            // Stranice.

  public Trougao ()          { super (); a=b=c=1;  } // Inicijalizacija.
  public Trougao (double aa) { super (); a=b=c=aa; }
  public Trougao (double aa, double bb)
    { super ();   a = aa; b = c = bb; }
  public Trougao (double aa, double bb, double cc)
    { super ();   a = aa; b = bb; c = cc; }
  public Trougao (double aa, double bb, double cc, Tacka tt)
    { super (tt); a = aa; b = bb; c = cc; }

  public double O () { return a + b + c; }           // Obim.

  public double P () {                               // Povrsina.
    double s = (a + b + c) / 2;
    return Math.sqrt (s * (s-a) * (s-b) * (s-c));
  }

  public void citaj () { super.citaj ();             // Citanje.
    a = Citaj.Double (); b = Citaj.Double (); c = Citaj.Double ();
  }

  public String toString () {                        // Tekstualni oblik.
    return "troug[" + super.toString() + ", a=" + a + ", b=" + b +
      ", c=" + c + ", O=" + O() + ", P=" + P() + "]";
  }
}