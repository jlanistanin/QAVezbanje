// Kvadrat.java - Klasa kvadrata u ravni.

package figure;
import  usluge.Citaj;

public class Kvadrat extends Figura {

  private double a;                                          // Stranica.

  public Kvadrat ()                    { super ();   a=1;  } // Inicijali-
  public Kvadrat (double aa)           { super ();   a=aa; } //   zacija.
  public Kvadrat (double aa, Tacka tt) { super (tt); a=aa; }

  public double O () { return 4 * a; }                       // Obim.

  public double P () { return a * a; }                       // Povrsina.

  public void citaj () { super.citaj(); a = Citaj.Double (); } // Citanje.

  public String toString () {                        // Tekstualni oblik.
    return "kvadr[" + super.toString() + ", a=" + a +
      ", O=" + O() + ", P=" + P() + "]";
  }
}