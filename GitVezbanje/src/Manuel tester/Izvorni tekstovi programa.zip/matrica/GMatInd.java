// GMatInd.java - Klasa za greske: Nedozvoljeni indeks.

package matrica;

public class GMatInd extends Exception {

  private int i, j;             // Nedozvoljeni indeksi.

  public GMatInd (int ii, int jj) { i = ii; j = jj; } // Inicijalizacija.

  public int i () { return i; } // Dohvatanje nedozvoljenih indeksa.
  public int j () { return j; }

  public String toString ()     // Stvaranje tekstualnog oblika.
    { return "*** Nedozvoljeni indeksi [" + i + "][" + j + "]"; }
}