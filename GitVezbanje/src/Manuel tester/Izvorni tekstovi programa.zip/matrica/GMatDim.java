// GMatDim.java - Klasa za greske: Neusaglasene dimenzije.

package matrica;

public class GMatDim extends Exception {

  private Matr mat1, mat2;             // Problematicne matrice.

  public GMatDim (Matr m1, Matr m2)    // Inicijalizacija.
    { mat1 = m1; mat2 = m2; }

  public Matr mat1 () { return mat1; } // Dohvatanje problematicnih
  public Matr mat2 () { return mat2; } //   matrica.

  public String toString () {          // Stvaranje tekstualnog oblika.
    return "*** Neusaglasene dimenzije matrica [" +
           mat1.mat.length + "][" + mat1.mat[0].length + "] i [" +
           mat2.mat.length + "][" + mat2.mat[0].length + "]";
  }
}