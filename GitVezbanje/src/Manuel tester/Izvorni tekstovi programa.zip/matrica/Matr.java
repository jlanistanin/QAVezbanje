// Matr.java - Klasa matrica realnih brojeva.

package matrica;
import usluge.Citaj;

public class Matr {

  double[][] mat;                                     // Elementi matrice.

  public Matr (int m, int n) { mat = new double[m][n]; }  // Inicijaliza-
                                                          //   cija.
  public Matr () { this (10, 10); };

  public int vrs () { return mat.length; }                // Broj vrsta.

  public int kol () { return mat[0].length; }             // Broj kolona.

  private void proveriInd (int i, int j) throws GMatInd { // Provera
    if (i<0 || i>=mat.length || j<0 || j>mat[0].length)   //   indeksa.
      throw new GMatInd (i, j);
  }
                                                // Postavljanje elementa.
  public Matr postavi (int i, int j, double b) throws GMatInd
    { proveriInd (i, j); mat[i][j] = b; return this; }

  public double dohvati (int i, int j) throws GMatInd    // Dohvatanje
    { proveriInd (i, j); return mat[i][j]; }             //   elementa.

  public Matr kopija () {                       // Stvaranje kopije.
    Matr m = new Matr (mat.length, mat[0].length);
    for (int i=0; i<mat.length; i++)
      for (int j=0; j<mat[0].length; j++)
        m.mat[i][j] = mat[i][j];
    return m;
  }

  private void proveriDim (Matr m2) throws GMatDim {     // Provera
    if (mat   .length != m2.mat   .length ||             //   dimenzija.
        mat[0].length != m2.mat[0].length )
      throw new GMatDim (this, m2);
  }

  public Matr dodaj (Matr m2) throws GMatDim {  // Dodavanje matrice.
    proveriDim (m2);
    for (int i=0; i<mat.length; i++)
      for (int j=0; j<mat[0].length; j++)
        mat[i][j] += m2.mat[i][j];
    return this;
  }
                                                // Zbir matrica.
  public static Matr zbir (Matr m1, Matr m2) throws GMatDim {
    return m1.kopija (). dodaj (m2);
  }

  public Matr oduzmi (Matr m2) throws GMatDim { // Oduzimanje matrice.
    proveriDim (m2);
    for (int i=0; i<mat.length; i++)
      for (int j=0; j<mat[0].length; j++)
        mat[i][j] += m2.mat[i][j];
    return this;
  }
                                                // Razlika matrica.
  public static Matr razlika (Matr m1, Matr m2) throws GMatDim {
    return m1.kopija (). oduzmi (m2);
  }
                                                // Proizvod matrica.
  public static Matr proizvod (Matr m1, Matr m2) throws GMatDim {
    if (m1.mat[0].length != m2.mat.length)
      throw new GMatDim (m1, m2);
    Matr m = new Matr (m1.mat.length, m2.mat[0].length);
    for (int i=0; i<m1.mat.length; i++)
      for (int k=0; k<m2.mat[0].length; k++)
        for (int j=0; j<m2.mat.length; j++)
          m.mat[i][k] += m1.mat[i][j] * m2.mat[j][k];
    return m;
  }

  public Matr pomnozi (Matr m2) throws GMatDim{ // Mnozenje matricom.
    Matr m = proizvod (this, m2); mat = m.mat; return this;
  }

  public Matr citaj () {                        // Citanje matrice.
    System.out.print ("Vrs, kol? ");
    int vrs = Citaj.Int (), kol = Citaj.Int ();
    mat = new double [vrs][kol];
    for (int i=0; i<vrs; i++) {
      System.out.print ("Vrsta " + i + "? ");
      for (int j=0; j<kol; mat[i][j++]=Citaj.Double());
    }
    return this;
  }

  public String toString () {          // Sastavljanje tekstualnog oblika.
    StringBuffer s = new StringBuffer ();
    for (int i=0; i<mat.length; i++){
      for (int j=0; j<mat[0].length; s.append(mat[i][j++]).append(' '));
      s.append('\n');
    }
    return s.toString ();
  }
}