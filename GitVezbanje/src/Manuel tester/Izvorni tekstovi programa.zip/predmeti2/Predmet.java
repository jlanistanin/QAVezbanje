// Predmet.java - Apstraktna klasa predmeta.

package predmeti2;

public abstract class Predmet implements Cloneable {

  private static int ukId;    // Poslednje korisceni identifikator.
  private int id = ++ ukId;   // Identifikator predmeta.

  public final int id () { return id; }  // Dohvatanje identifikatora.

  public abstract double V ();           // Zapremina.

  public abstract double Q ();           // Tezina.

  public Object clone () {               // Stvaranje kopije.
    try {
      Predmet p = (Predmet)super.clone ();
      p.id = ++ukId;
      return p;
    } catch (CloneNotSupportedException g) { return null; }
  }

  public final String vrsta () {         // Dohvatanje vrste predmeta.
    String s = getClass ().getName ();
     return  s.substring (s.lastIndexOf ('.') + 1);
  }

  public String toString ()              // Tekstualni oblik.
    { return id + " " + vrsta (); }
}
