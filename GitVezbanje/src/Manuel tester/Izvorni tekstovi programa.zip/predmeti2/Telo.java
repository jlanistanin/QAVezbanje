// Telo.java - Apstraktna klasa tela.

package predmeti2;

public abstract class Telo extends Predmet {

  protected double sigma;                           // Specificna tezina.

  public Telo (double s) { sigma = s; }             // Inicijalizacija.

  public final double Q () { return sigma * V (); } // Tezina.
                                                    // Tekstualni oblik.
  public String toString () { return super.toString () + " " + sigma; }
}