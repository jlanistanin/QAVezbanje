// Sklop.java - Klasa sklopova predmeta.

package predmeti2;
import  liste.*;

public class Sklop extends Predmet {

  private Lista lst = new Lista ();          // Lista sadrzanih predmeta.

  public Sklop dodaj (Predmet p)             // Dodavanje predmeta.
    { lst.dodaj (p);  return this; }

  public Predmet dohvati (int ind) {         // Dohvatanje predmeta.
    lst.naPrvi ();
    for (int i=1; i<ind; i++) lst.naSledeci ();
    try { return (Predmet)lst.dohvatiTek (); }
      catch (GLstNemaTek g) { return null; }
  }

  public final double V () {                 // Zapremina.
    double V = 0;
    for (lst.naPrvi(); lst.imaTek(); lst.naSledeci())
      try { V += ((Predmet)lst.dohvatiTek ()).V (); }
        catch (GLstNemaTek g) {}
    return V;
  }

  public final double Q () {                 // Tezina.
    double Q = 0;
    for (lst.naPrvi(); lst.imaTek(); lst.naSledeci())
      try { Q += ((Predmet)lst.dohvatiTek ()).Q (); }
        catch (GLstNemaTek g) {}
    return Q;
  }

  public Object clone () {                   // Stvaranje kopije.
    Sklop s = (Sklop)super.clone ();
    s.lst = new Lista ();
    for (lst.naPrvi(); lst.imaTek(); lst.naSledeci())
      try {
        Predmet p = (Predmet)lst.dohvatiTek ();
        s.dodaj ((Predmet)p.clone ());
      } catch (GLstNemaTek g) {}
    return s;
  }

  private static int nivo = 0;                  // Nivo uklapanja predmeta.

  private static void uvuci (StringBuffer s) {  // Uvlacenje uklopljenih
    for (int i=0; i<nivo; i++) s.append ("  "); //   predmeta u tekstu-
  }                                             //   alnom obliku.

  public String toString () {                   // Tekstualni oblik.
    StringBuffer s = new StringBuffer ();
    s.append (super.toString ()).append (" {\n");
    nivo++;
    for (lst.naPrvi(); lst.imaTek(); lst.naSledeci()) {
      try {
        Predmet p = (Predmet)lst.dohvatiTek();
        uvuci (s); s.append (p).append ('\n');
      } catch (GLstNemaTek g) {}
    }
    nivo--;
    uvuci (s); return s.append ('}').toString ();
  }
}