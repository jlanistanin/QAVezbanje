// Kvadar.java - Klasa kvadara.

package predmeti2;

public class Kvadar extends Telo {

  private double a, b, c;                          // Ivice.
                                                   // Inicijalizacija.
  public Kvadar (double sigma, double a, double b, double c)
    { super (sigma); this.a = a; this.b = b; this.c = c; }

  public final double V () { return a * b * c; }   // Zapremina.

  public String toString ()                        // Tekstualni oblik.
    { return super.toString () + " " + a + " " + b + " " + c; }
}