// Sfera.java - Klasa sfera.

package predmeti2;

public class Sfera extends Telo {

  private double r;                                // Poluprecnik.

  public Sfera (double sigma, double r)            // Inicijalizacija.
    { super (sigma); this.r = r; }

  public final double V () { return 4./3 * r*r*r * Math.PI; } // Zapremina.

  public String toString ()                        // Tekstualni oblik.
    { return super.toString () + " " + r; }
}