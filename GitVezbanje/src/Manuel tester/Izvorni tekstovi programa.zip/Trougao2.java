// Trougao2.java - Klasa trouglova.

public class Trougao2 {

  private static int ukId = 0; // Poslednje korisceni identifikator.
  private int id = ++ukId;     // Identifikator trougla.
  private double a, b, c;      // Stranice trougla.

                                         // Da li su stranice prihvatljive.
  public static boolean moze (double a, double b, double c)
    { return a>0 && b>0 && c>0 && a+b>c && b+c>a && c+a>b; }

  public Trougao2 (double aa, double bb, double cc) { // Stvaranje.
    if (! moze (aa, bb, cc)) System.exit (1);
    a = aa; b = bb; c = cc;
  }

  public double a () { return a; }         // Dohvatanje stranica.
  public double b () { return b; }
  public double c () { return c; }

  public double O () { return a + b + c; } // Obim trougla.

  public double P () {                     // Povrsina trougla.
    double s = O () / 2;
    return Math.sqrt (s * (s-a) * (s-b) * (s-c));
  }

  public String toString ()                // Tekstualni oblik.
    {  return "Troug" + id + "(" + a + "," + b + "," + c + ")"; }
}
