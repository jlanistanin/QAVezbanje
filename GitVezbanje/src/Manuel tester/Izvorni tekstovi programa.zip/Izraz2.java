// izraz2.java - Izracunavanje proizvoda uzastopnih prirodnih brojeva.

public class Izraz2 {
  public static void main (String[] vpar) {
    System.out.print ("n? "); int n = Citaj.Int ();
    long s = 1;
    for (int i=1; i<=n; s*=i++);
    System.out.println ("s= " + s);
  }
}
