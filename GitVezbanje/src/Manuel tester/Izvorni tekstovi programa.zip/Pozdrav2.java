// Pozdrav2.java - Jednostavan program s prozorom (koriscenjem AWT-a).

import java.awt.*;
import java.awt.event.*;

public class Pozdrav2 extends Frame {
  
  private Pozdrav2 () {                         // Sastavljanje prozora.
    super ("Pozdrav 2");
    setSize (200, 150);
    add (new Label ("Pozdrav svima!", Label.CENTER));
    addWindowListener (new ProzorDogadjaji ());
    setVisible (true);
  }

  private class ProzorDogadjaji extends WindowAdapter { // Rukovanje
    public void windowClosing (WindowEvent d)           //   dogadjajima
      { dispose (); }                                   //   prozora.
  }
  
  public static void main (String[] varg)       // Glavna funkcija.
    { new Pozdrav2 (); }  
}