// Min2.java - Najmanji element niza.

public class Min2 {
  public static void main (String[] vpar) {
    while (true) {
      System.out.print ("n? "); int n = Citaj.Int ();
    if (n<=0) break;
      double[] a = new double [n];
      System.out.print ("A? "); for (int i=0; i<n; a[i++]=Citaj.Double());
      double min = a[0];
      for (int i=1; i<n; i++) if (a[i] < min) min = a[i];
      System.out.println ("min= " + min + '\n');
    }
  }
}
