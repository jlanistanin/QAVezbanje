// MasSfera.java - Klasa masina za sfere.

package radionica;
import  predmeti1.*;

public class MasSfera extends Masina {
    
  private double r;                      // Poluprecnik pravljenih sfera.
  
  public MasSfera (double ss, double rr) // Inicijalizacija.
    { super (ss); r = rr; }
    
  double dohvatiR () { return r; }          // Dohvatanje poluprecnika.

  public char vrsta () { return Sfera.VR; } // Vrsta pravljenih predmeta.

  public Predmet napravi ()                 // Pravljenje sfere.     
    { br++; return new Sfera (spTez, r); }
}