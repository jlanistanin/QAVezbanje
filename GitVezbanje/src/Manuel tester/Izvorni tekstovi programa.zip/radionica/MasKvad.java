// MasKvad.java - Klasa masina za kvadre.

package radionica;
import  predmeti1.*;

public class MasKvad extends Masina {
    
  private double a, b, c;               // Dimenzije pravljenih kvadara.
  
  public MasKvad (double ss, double aa, double bb, double cc) // Inicijali-
    { super (ss); a = aa; b = bb; c = cc; }                   //    zacija.
    
  double dohvatiA () { return a; }           // Dohvatanje dimenzija
  double dohvatiB () { return b; }           //   pravljenih kvadara.
  double dohvatiC () { return c; }
  
  public char vrsta () { return Kvadar.VR; } // Vrsta pravljenih proizv.

  public Predmet napravi ()                  // Pravljenje kvadra.     
    { br++; return new Kvadar (spTez, a, b, c); }
}