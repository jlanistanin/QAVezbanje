// Masina.java - Apstraktna klasa masina.

package radionica;
import  predmeti1.Predmet;

public abstract class Masina {
  
  protected double spTez;       // Specificna tezina pravljenih predmeta.
  protected int br;             // Broj napravljenih predmeta.
   
  protected Masina (double s) { spTez = s; } // Inicijalizacija.
  
  public abstract char vrsta ();             // Vrsta pravljenih predmeta.
    
  public int broj () { return br; }          // Broj napravljenih predmeta.

  public double uzmiSpTez () { return spTez; } // Dohvanje spec. tezine.
  
  public void postaviSpTez (double s)          // Postavljanje spec. tezine.
    { spTez = s; br = 0; }
  
  public abstract Predmet napravi ();          // Pravljenje predmeta.
}