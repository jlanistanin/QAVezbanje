// GNemaMas.java - Klasa za greske: Radnik nema masinu.

package radionica;
import  usluge.Greska;

public class GNemaMas extends Greska {

  String ime; int id; // Ime i identifikator problematicnog radnika.

  public GNemaMas (String iime, int iid) // Inicijalizacija.
    { ime = iime; id = iid; }

  public String ime () { return ime; }   // Dohvatanje atributa.
  public int id () { return id; }

  public String toString () {            // Tekstualni oblik.
    return "*** Radniku " + ime + ", id " + id +
           ", nije dodeljena masina!";
  }
}