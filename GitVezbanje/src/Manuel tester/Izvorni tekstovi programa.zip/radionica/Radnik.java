// Radnik.java - Klasa radnika.

package radionica;
import  predmeti1.Predmet;

public class Radnik {

  private static int ukId;       // Poslednje korisceni identifikator.
  private int id = ++ukId;       // Identifikator radnika.
  private String ime;            // Ime radnika.
  private Masina mas;            // Masina koju radnik koristi.
  private int br;                // Broj napravljenih proizvoda na masini.

  public Radnik (String iime) { ime = iime; } // Inicijalizacija.

  public int dohvatiId () { return id; }      // Dohvatanje identifikatora
  public String dohvatiIme () { return ime; } //   i imena.

  public Radnik rasporedi (Masina m)          // Rasporedjivanje na masinu.
    { mas = m; br = 0; return this; }

  public Masina dohvatiMas () { return mas; } // Dohvatanje masine.

  public int broj () throws GNemaMas {             // Broj napravljenih
    if (mas == null) throw new GNemaMas (ime, id); //   predmeta.
    return br;
  }

  public Predmet napravi () throws GNemaMas { // Pravljenje predmeta.
    if (mas == null) throw new GNemaMas (ime, id);
    br++;
    return mas.napravi ();
  }

  public String toString () {                 // Tekstualni oblik.
    String s = ime + "/" + id;
    if (mas != null) s += "(" + mas.vrsta() + "," + br + ")";
    return s;
  }
}