// SamoposlugaT.java - Ispitivanje rada samoposluge.

import samoposluga.Samoposluga;
import usluge.*;
import java.awt.*;
import java.awt.event.*;

public class SamoposlugaT extends Frame {

  private Samoposluga samoposl;   // Samoposluga koja se obradjuje.
  private Button dgmOtvori  = new Button ("Otvori"),  // Upravljacka
                 dgmZatvori = new Button ("Zatvori"), //   dugmad.
                 dgmUnisti  = new Button ("Unisti");
  private boolean smeZatv = true; // Da li sme prozor da se zatvara?

  private void omoguci (boolean da) {    // Podesavanje upotrebljivosti
    dgmOtvori .setEnabled (da);          //   upravljacke dugmadi.
    dgmZatvori.setEnabled (da);
    dgmUnisti .setEnabled (da);
    smeZatv = da;
  }

  private void ploUlazi (int brUlaza, Polje[] pUlazi) { // Ploca za ulaze.
    Panel plo = new Panel (new GridLayout(0,1));
    add (plo, "West");
    plo.setBackground (new Color(192, 255, 192));
    try {
      for (int i=0; i<brUlaza; i++) {
        Label oznaka = new Label ();
        plo.add (oznaka);
        pUlazi[i] = new Polje(oznaka);
      }
    } catch (GKompNeOdgovara g) {}
  }
                                         // Ploca za kase i redove.
  private void ploKaseRedovi (int brKasa, Polje[] pKase, Polje[] pRedovi) {
    Panel plo = new Panel (new BorderLayout ());
    add (plo, "Center");
    Panel ploKase   = new Panel (new GridLayout (1, brKasa)),
          ploRedovi = new Panel (new GridLayout (1, brKasa));
    plo.add (ploKase, "North"); plo.add (ploRedovi, "Center");
    ploKase  .setBackground (new Color(192, 192, 255));
    ploRedovi.setBackground (new Color(192, 192, 192));
    try {
      for (int i=0; i<brKasa; i++) {
        Label oznaka = new Label ();
        ploKase.add (oznaka);
        pKase[i] = new Polje (oznaka);
        TextArea tekst = new TextArea ();
        ploRedovi.add (tekst);
        pRedovi[i] = new Polje (tekst);
      }
    } catch (GKompNeOdgovara g) {}
  }

  private void ploKomande (Polje[] pKupci) { // Ploca za upravljacku dugmad.
    Panel plo = new Panel();
    add (plo, "North");
    plo.setBackground (new Color(255, 192, 192));
    plo.add (dgmOtvori );
    plo.add (dgmZatvori);
    plo.add (dgmUnisti );
    DugmeAkcija akcija = new DugmeAkcija ();
    dgmOtvori .addActionListener (akcija);
    dgmZatvori.addActionListener (akcija);
    dgmUnisti .addActionListener (akcija);
    Label oznKupci = new Label ();
    plo.add (oznKupci);
    try { pKupci[0] = new Polje (oznKupci); }
      catch (GKompNeOdgovara g) {}
  }

  class DugmeAkcija implements ActionListener {   // Obrada pritisaka na
    public void actionPerformed (ActionEvent d) { //   upravljacku dugmad.
      Component k = (Component)d.getSource ();
      if (k == dgmOtvori ) samoposl.otvori  ();
      if (k == dgmZatvori) new Zatvori ().start ();
      if (k == dgmUnisti ) new Unisti  ().start ();
    }
  }

  private class Zatvori extends Thread { // Nit za zatvaranje samoposluge.
    public void run ()
      { omoguci (false); samoposl.zatvori (); omoguci (true); }
  }

  private class Unisti extends Thread {  // Nit za unistavanje samoposluge.
    public void run ()
      { omoguci (false); samoposl.unisti (); dispose (); }
  }

  private void popuniProzor (String[] vpar) { // Popunjavanje prozora i
                                              //   stvaranje samoposluge:
    int brUlaza = Integer.parseInt (vpar[1]),
        brKasa  = Integer.parseInt (vpar[2]);

    Polje[] pUlazi = new Polje [brUlaza];     // - ploca za ulaze,
    ploUlazi(brUlaza, pUlazi);

    Polje[] pKase   = new Polje [brKasa];     // - ploca za kase i redove,
    Polje[] pRedovi = new Polje [brKasa];
    ploKaseRedovi(brKasa, pKase, pRedovi);

    Polje[] pKupci = new Polje [1];           // - ploca za komandnu dugmad,
    ploKomande(pKupci);

    samoposl = new Samoposluga (              // - stvaranje samoposluge.
      brUlaza, brKasa,
      Integer.parseInt (vpar[3]),             //   (maxUlaz)
      Integer.parseInt (vpar[4]),             //   (maxKupovina)
      Integer.parseInt (vpar[5]),             //   (maxNaplata)
      pKupci[0], pUlazi, pKase, pRedovi
    );
  }

  private SamoposlugaT (String[] vpar, int x, int y) { // Inicijalizacija:
    setBounds (x, y, 500, 200);
    popuniProzor (vpar);                        // - popunjavanje prozora,
    setTitle ("Samoposluga " + samoposl.id());  // - postavljanje natpisa,

    addWindowListener (new WindowAdapter () {   // - obrada zatvaranja
      public void windowClosing (WindowEvent d) //   prozora.
        { if (smeZatv) new Unisti ().start (); }
     });
  }

  public static void main (String[] vpar) {     // Glavna funkcija.
    for (int i=1; i<=Integer.parseInt (vpar[0]); i++)
      new SamoposlugaT (vpar, 50*i, 120*i).setVisible (true);
  }
}