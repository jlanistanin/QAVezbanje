// Uredjivac.java - Apstraktna klasa za algoritme uredjivanja.

package uredjivaci2;
import prikazivaci.Prikazivac;

public abstract class Uredjivac implements Runnable {
  protected Prikazivac prik = null;     // Korisceni prikazivac.
  protected double[] niz;               // Niz koji se uredjuje.
  private boolean prekini = false;      // Indikator prekidanja.
  private long dt = 10;                 // Trajanje pauze.
  private Thread nit = null;            // Nit koja radi.

  protected class GPrekinut        // Klasa za prijavu prekidanja postupka.
                  extends Exception {}

  public void postaviPrikazivaca (Prikazivac prik)   // Postavljanje
    { this.prik = prik; }                            //   prikazivaca.

  public void postaviDt (long dt)                    // Postavljanje
    { this.dt = dt; }                                //   kasnjenja.

  public synchronized void uredi (double[] niz) {    // Zahtev za
    this.niz = niz;                                  //   uredjivanje niza.
    (nit = new Thread (this)).start ();
  }

  public void run () {                               // Sadrzaj niti.
    prekini = false;
    try { prikazi (); uredi (); } catch (GPrekinut g) {}
    nit = null;
  }

  protected abstract void uredi () throws GPrekinut; // Uredjivanje niza.

  public void prekini () {                           // Zahtev za
    prekini = true;                                  //   prekidanje rada.
    if (nit != null) try { nit.join(); } catch (InterruptedException g) {}
  }

  protected void prikazi () throws GPrekinut {       // Prikazivanje niza.
    if (prik != null) prik.prikazi (niz);
    try { Thread.sleep (dt); }
      catch (InterruptedException g) { prekini (); }
    if (prekini) throw new GPrekinut ();
  }

  public abstract String toString ();                // Naziv algoritma.
}