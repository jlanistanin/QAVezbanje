// MetodaPodele.java - Klasa za uredjivanje metodom podele
//                     (Quick Sort).

package uredjivaci2;

public class MetodaPodele extends Uredjivac {

  public void uredi () throws GPrekinut   // Uredjivanje niza.
    { uredi (0, niz.length-1); }

  private void uredi (int p, int q) throws GPrekinut {
    if (q > p) {
      int i = p-1, j = q;
      while (true) {
        do i++; while (niz[i] < niz [q]);
        do j--; while (j>=0 && niz[j] > niz[q]);
      if (i >= j) break;
        double b = niz[i]; niz[i] = niz[j]; niz[j] = b; prikazi ();
      }
      double b = niz[i]; niz[i] = niz[q]; niz[q] = b; prikazi ();
      uredi (p, i-1); uredi (i+1, q);
    }
  }

  public String toString ()               // Naziv algoritma.
    { return "Metoda podele"; }
}