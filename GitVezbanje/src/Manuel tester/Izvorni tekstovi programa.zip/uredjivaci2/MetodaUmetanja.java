// MetodaUmetanja.java - Klasa za uredjivanje metodom umetanja
//                       (Insertion Sort).

package uredjivaci2;

public class MetodaUmetanja extends Uredjivac {

  public void uredi () throws GPrekinut { // Uredjivanje niza.
    int n = niz.length;
    for (int i=1; i<n; i++) {
      int j = i - 1;
      while (j>=0 && niz[j+1] < niz[j]) {
        double p = niz[j+1]; niz[j+1] = niz[j]; niz[j--] = p;
        prikazi ();
      }
    }
  }

  public String toString ()               // Naziv algoritma.
    { return "Metoda umetanja"; }
}