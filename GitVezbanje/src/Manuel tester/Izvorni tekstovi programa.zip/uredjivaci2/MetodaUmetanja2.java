// MetodaUmetanja2.java - Klasa za uredjivanje poboljsanom metodom umetanja.

package uredjivaci2;

public class MetodaUmetanja2 extends Uredjivac {

  public void uredi () throws GPrekinut { // Uredjivanje niza.
    int n = niz.length;
    for (int i=1; i<n; i++) {
      double p = niz[i];
      int j = i - 1;
      while (j>=0 && p < niz[j])
        {niz[j+1] = niz[j--]; prikazi (); }
      niz[j+1] = p; prikazi ();
    }
  }

  public String toString ()               // Naziv algoritma.
    { return "Poboljsana metoda umetanja"; }
}