// MetodaZameneSuseda.java - Klasa za uredjivanje metodom zamene suseda
//                          (Bubble Sort).

package uredjivaci2;

public class MetodaZameneSuseda extends Uredjivac {

  public void uredi () throws GPrekinut { // Uredjivanje niza.
    int n = niz.length;
    boolean dalje = true;
    for (int i=0; i<n-1 && dalje; i++) {
      dalje = false;
      for (int j=n-2; j>=i; j--)
        if (niz[j+1] < niz[j]) {
          double p = niz[j+1]; niz[j+1] = niz[j]; niz[j] = p;
          prikazi ();
          dalje = true;
        }
    }
  }

  public String toString ()               // Naziv algoritma.
    { return "Metoda zamene suseda"; }
}