// MetodaIzbora2.java - Klasa za uredjivanje poboljsanom metodom izbora.

package uredjivaci2;

public class MetodaIzbora2 extends Uredjivac {

  public void uredi () throws GPrekinut { // Uredjivanje niza.
    int n = niz.length;
    for (int i=0; i<n-1; i++) {
      int m = i;
      for (int j=i+1; j<n; j++)
        if (niz[j] < niz[m]) m = j;
      if (m != i) {
        double p = niz[i]; niz[i] = niz[m]; niz[m] = p;
        prikazi ();
      }
    }
  }

  public String toString ()               // Naziv algoritma.
    { return "Poboljsana metoda izbora"; }
}