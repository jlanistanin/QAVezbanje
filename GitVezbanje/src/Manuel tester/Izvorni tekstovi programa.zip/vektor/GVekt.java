// GVekt.java - Klasa gresaka pri radu s vektorima.

package vektor;

public class GVekt extends Exception {
                                        // Kodovi gresaka:
  public static final int OPSEG  = 0,   // - neispravan opseg indeksa,
                          INDEKS = 1,   // - indeks izvan opsega,
                          DUZINA = 2;   // - neusaglasene duzine vektora.

  private static final String[] por = { // Tekstovi poruka o greskama.
    "Neispravan opseg indeksa!",
    "Indeks je izvan opsega!",
    "Neusaglasene duzine vektora!"
  };

  private int sif;                      // Sifra greske.

  public GVekt (int s) { sif = s; }     // Inicijalizacija.

  public int sifra () { return sif; }   // Dohvatanje sifre.
                                        // Tekstualni oblik.
  public String toString () { return "*** " + por[sif]; }
}