// Vekt.java - Klasa vektora realnih brojeva.

package vektor;

public class Vekt {
  
  int min, max;                                // Granice indeksa.
  double[] niz;                                // Niz komponenata.
                                               // Inicijalizacija:
  public Vekt (int mi, int ma) throws GVekt {  // - zadati opseg,
    if (mi > ma) throw new GVekt (GVekt.OPSEG);
    niz = new double [(max=ma) - (min=mi) +1];
  }
  
  public Vekt (int ma) throws GVekt            // - zadata gornja granica,
    { this (1, ma); }
  
  public Vekt () throws GVekt { this (1,10); } // - podrazumevani opseg.

  public Vekt postavi (int i, double b) throws GVekt {  // Postavljanje
    if (i<min || i>max) throw new GVekt (GVekt.INDEKS); //   komponente.
    niz[i-min] = b;
    return this;
  }
  
  public double dohvati (int i) throws GVekt {          // Dohvatanje
    if (i<min || i>max) throw new GVekt (GVekt.INDEKS); //   komponente.
    return niz[i-min];
  }
  
  public static double skalPro (Vekt v1, Vekt v2)       // Skalarni
    throws GVekt {                                      //   proizvod.
    if (v1.niz.length != v2.niz.length) throw new GVekt (GVekt.DUZINA);
    double s = 0;
    for (int i=0; i<v1.niz.length; s+=v1.niz[i]*v2.niz[i++]);
    return s;
  }
  
  public int minInd () { return min; }         // Dohvatanje najmanjeg     
  public int maxInd () { return max; }         //   i najveceg indeksa.
}