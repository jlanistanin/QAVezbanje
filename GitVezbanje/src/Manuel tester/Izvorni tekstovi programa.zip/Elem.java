// Elem.java - Element liste celih brojeva.

public class Elem {
  public int broj;                  //   Sadrzaj.
  public Elem sled;                 //   Sledeci element.
  public Elem (int b, Elem s)       //   Inicijalizacija.
    { broj = b; sled = s; }
  public Elem (int b) { broj = b; }
}
