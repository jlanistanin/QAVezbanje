// Izraz4.java - Izracunavanje slozenog zbira.

public class Izraz4 {
  public static void main (String[] vpar) {
    System.out.print ("n? "); int n = Citaj.Int ();
    double s = 0, g = 0; long f = 1;
    for (int i=1; i<=n; i++) {
      f *= i;
      g += 1. / (i+1);
      s += f / g;
    }
    System.out.println ("s= " + s);
  }
}
