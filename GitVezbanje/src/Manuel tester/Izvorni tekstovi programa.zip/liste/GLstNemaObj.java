// GLstNemaObj.java - Klasa za greske: Objekat nije u listi.

package liste;
import  usluge.Greska;

public class GLstNemaObj extends Greska {
  
  private Object obj;                           // Problematicni objekat.
  
  public GLstNemaObj (Object obj)               // Inicijalizacija.
    { super ("Objekat [" + obj + "] nije u listi!"); this.obj = obj; }
    
  public Object obj () { return obj; }          // Dohvatanje objekta.
}