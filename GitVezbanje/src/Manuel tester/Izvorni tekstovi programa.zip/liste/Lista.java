// Lista.java - Klasa listi objekata.

package liste;

public class Lista {

  private Elem prvi, posl;           // Pocetak i kraj liste.

  private class Elem {               // Element liste objekata:

    Object obj;                      // - sadrzani objekat,
    Elem pret, sled;                 // - prethodni i sledeci element,

    Elem (Object obj) {              // - inicijalizacija elementa,
      this.obj = obj;
      sled = null; pret = posl;
      if (prvi == null) prvi = this; else posl.sled = this;
      posl = this;
    }

    void izbaci () {                 // - izbacivanje elementa.
      if (pret != null) pret.sled = sled;
        else prvi = sled;
      if (sled != null) sled.pret = pret;
        else posl = pret;
    }
  } // class Elem

  public Lista dodaj (Object obj)    // Dodavanje objekta na kraj liste.
    { new Elem (obj); return this; }
                                     // Izbacivanje objekta iz liste.
  public Lista izbaci (Object obj) throws GLstNemaObj {
    Elem tek = prvi; while (tek!=null && tek.obj!=obj) tek=tek.sled;
    if (tek == null) throw new GLstNemaObj (obj);
    tek.izbaci ();
    return this;
  }

  private Elem tek;                  // Tekuci element liste.

  public Lista naPrvi ()             // Pomeranje na prvi element.
    { tek = prvi; return this;}

  public boolean imaTek () { return tek != null; } // Ima li tekuceg?

  public Lista naSledeci () {        // Pomeranje na sledeci element.
    if (imaTek ()) tek = tek.sled;
    return this;
  }

  public Object dohvatiTek () throws GLstNemaTek { // Dohvatanje tekuceg
    if (! imaTek()) throw new GLstNemaTek ();      //   objekta.
    return tek.obj;
  }

  public Object izvadiTek () throws GLstNemaTek {  // Vadjenje tekuceg
    if (! imaTek()) throw new GLstNemaTek ();      //   objekta.
    Object obj = tek.obj; tek.izbaci (); tek = tek.sled;
    return obj;
  }

  public Lista isprazni ()                         // Praznjenje liste.
    { prvi = posl = tek = null; return this; }

  public String toString () {                      // Tekstualni oblik.
    StringBuffer s = new StringBuffer ("<");
    for (Elem tek=prvi; tek!=null; tek=tek.sled) {
      if (tek != prvi) s.append (" # ");
      s.append (tek.obj);
    }
    return s.append ('>').toString ();
  }
}