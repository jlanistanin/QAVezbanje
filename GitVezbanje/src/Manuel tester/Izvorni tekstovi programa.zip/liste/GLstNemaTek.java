// GLstNemaTek.java - Klasa za greske: Nema tekuceg elementa.

package liste;
import usluge.Greska;

public class GLstNemaTek extends Greska {
  
  public GLstNemaTek ()                       // Inicijalizacija.
    { super ("Nema tekuceg objekta u listi!"); }
}