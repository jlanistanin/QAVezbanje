// PVozilo.java - Klasa putnickih vozila.

package vozila;

public class PVozilo extends Vozilo {

  double srTez;                                  // Srednja tezina putnika.
  int brPut;                                     // Broj putnika.

  public PVozilo (double st, double srt, int bp) // Inicijalizacija.
    { super (st); srTez = srt; brPut = bp; }

  public char vrsta () { return 'P'; }           // Vrsta vozila.

  public double tezina ()                        // Ukupna tezina.
    { return super.tezina () + srTez * brPut; }

  public String toString ()                      // Tekstualni oblik.
    { return super.toString() + srTez + "," + brPut + ")"; }
}