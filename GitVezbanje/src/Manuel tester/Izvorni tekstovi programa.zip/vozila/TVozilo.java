// TVozilo.java - Klasa teretnih vozila.

package vozila;

public class TVozilo extends Vozilo {

  private double teret;                 // Tezina tereta.

  public TVozilo (double st, double t)  // Inicijalizacija.
    { super (st); teret = t; }

  public char vrsta () { return 'T'; }  // Vrsta vozila.

  public double tezina ()               // Ukupna tezina.
    { return super.tezina () + teret; }

  public String toString ()             // Tekstualni oblik.
    { return super.toString() + teret + ")"; }
}