// Vozilo.java - Apstraktna klasa vozila.

package vozila;

public abstract class Vozilo {

  private double sopTez;                     // Sopstvena tezina.

  public Vozilo (double st) { sopTez = st; } // Inicijalizacija.

  public abstract char vrsta ();             // Vrsta vozila.

  public double tezina () { return sopTez; } // Ukupna tezina.

  public String toString ()                  // Tekstualni oblik.
    { return vrsta() + "(" + sopTez + ","; }
}