// Zbir1.java - Izracunavanje zbira dva cela broja.

public class Zbir1 {
  public static void main (String[] vpar) {
    System.out.print ("Unesite dva cela broja: ");
    int a = Citaj.Int (), b = Citaj.Int ();
    int c = a + b;
    System.out.println ("Zbir unetih brojeva: " + c);
  }
}
