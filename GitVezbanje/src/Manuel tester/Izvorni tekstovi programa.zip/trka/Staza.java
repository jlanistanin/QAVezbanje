// Staza.java - Klasa aktivnih staza.

package trka;

public class Staza extends Thread {

  protected class Elem {          // Element liste vozila:
    Vozilo vozilo;                // - vozilo u elementu,
    Elem sled;                    // - sledeci element,
    Elem (Vozilo v) {             // - konstruktor.
      vozilo = v;
      if (prvi == null) prvi = this;
        else            posl.sled = this;
      posl = this;
    }
  }

  protected Elem prvi = null, posl = null; // Prvi i poslednji element.

  protected double duz;                    // Duzina staze.
  protected boolean gotova;                // Da li je trka gotova?

  public Staza (double duz) { this.duz = duz; } // KOnstruktori.

  public Staza () { this (100000); }

  public Staza dodaj (Vozilo v)            // Dodavanje vozila.
     { new Elem (v); return this; }

  private boolean radi = false;            // Da li je nit aktivna?

  public void run () {                     // Telo niti.
    try {
      while (! interrupted ()) {
        if (! radi) synchronized (this) { wait (); }
        sleep (20);
        proveri ();
      }
    } catch (InterruptedException g) {}
  }

  public void pocni () { start (); }       // Pokretanje niti.

  public synchronized void kreni () {      // Pocetak trke.
    for (Elem tek=prvi; tek!=null; tek=tek.sled)
      tek.vozilo.kreni ();
    gotova = false; radi = true; notify ();
  }

  protected void proveri () {              // Provera zavrsetka trke.
    for (Elem tek=prvi; tek!=null; tek=tek.sled)
      if (tek.vozilo.s() >= duz)
        { stani (); gotova = true; break; }
  }

  public Vozilo naCelu () {                // Vozilo na celu trke.
    double maxs = 0; Vozilo vodi = null;
    for (Elem tek=prvi; tek!=null; tek=tek.sled) {
      double s = tek.vozilo.s();
      if (s > maxs) { maxs = s; vodi = tek.vozilo; }
    }
    return vodi;
  }

  private synchronized void stani () {     // Zaustavljanje vozila.
    radi = false;
    for (Elem tek=prvi; tek!=null; tek=tek.sled)
      tek.vozilo.stani ();
  }

  public void zavrsi () {                  // Prekidanje svih niti.
    interrupt ();
    for (Elem tek=prvi; tek!=null; tek=tek.sled)
      tek.vozilo.zavrsi();
  }

}