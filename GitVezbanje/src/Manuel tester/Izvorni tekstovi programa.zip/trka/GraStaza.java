// GraStaza.java - Klasa grafickih staza.

package trka;
import java.awt.*;
import java.awt.event.*;

public class GraStaza extends Staza implements ActionListener {

  private Panel plo;           // Ploca pridruzena stazi.
  private TextField tksDuz =   // Polje za unos duzine staze.
    new TextField (Double.toString (duz), 8);
  private Button dgmKreni =    // Dugme za pokretanje trke.
    new Button ("kreni");
  private Label oznPobednik =  // Natpis za prikaz pobednika.
    new Label ();

  public GraStaza (double duz, Panel plo) // Konstruktori.
    { super (duz); popuniPlocu (plo); }

  public GraStaza (Panel plo)
    { super (); popuniPlocu (plo); }

  private void popuniPlocu (Panel plo) {  // Popunjavanje ploce.
    this.plo = plo;
    plo.add (new Label ("duzina:", Label.RIGHT));
    plo.add (tksDuz);
    plo.add (dgmKreni);
    plo.add (oznPobednik);
    dgmKreni.addActionListener (this);
  }

  public void actionPerformed (ActionEvent d) { // Obrada pritisaka
    dgmKreni.setEnabled (false);                //   dugmeta "kreni".
    oznPobednik.setText ("");
    plo.validate ();
    try {
      duz = Double.parseDouble (tksDuz.getText ());
    } catch (NumberFormatException g) {}
    kreni ();
  }

  protected void proveri () {                   // Provera kraja trke i
    super.proveri ();                           //   prikaz vozila na celu.
    oznPobednik.setText ((gotova ? "Pobednik: " : "Vodi: ") + naCelu().id());
    plo.validate ();
    if (gotova)  dgmKreni.setEnabled (true);
    for (Elem tek=prvi; tek!=null; tek=tek.sled)
      tek.vozilo.toString ();
  }
}