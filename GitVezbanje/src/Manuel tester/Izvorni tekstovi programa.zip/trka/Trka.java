// Trka.java - Program za organizovanje trke na grafickoj povrsi.

package trka;
import java.awt.*;
import java.awt.event.*;

public class Trka extends Frame {

  private static final int BR_VOZILA = 5; // Broj vozila u trci.
  private Staza staza;                    // Staza za trku.

  private void popuniProzor () { // Popunjavanje prozora:
    Panel plo = new Panel ();    // - ploca upravljanje trkom;
    add (plo, "South");
    (staza = new GraStaza (plo)).pocni ();
                                 // - ploca za prikaz vozila.
    add (plo = new Panel (new GridLayout (0,1)), "Center");
    for (int i=0; i<BR_VOZILA; i++) {
      Panel p = new Panel (); plo.add (p);
      Vozilo v = new GraVozilo (p); v.pocni ();
      staza.dodaj (v);
    }
  }

  public Trka () {               // Inicijalizacija.
    super ("Trka");
    setSize (300, 200);
    popuniProzor ();
    setVisible (true);
    addWindowListener (new WindowAdapter () {
      public void windowClosing (WindowEvent d) {
        staza.zavrsi (); dispose ();
      }
    });
  }
                                 // Glavna funkcija.
  public static void main (String[] varg) { new Trka (); }
}