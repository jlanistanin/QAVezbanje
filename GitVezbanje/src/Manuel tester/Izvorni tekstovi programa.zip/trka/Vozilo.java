// Vozilo.java - Klasa aktivnih vozila.

package trka;

public class Vozilo extends Thread {

  private static int ukId = 0;  // Poslednje korisceni identifikator.
  private int id = ++ ukId;     // Identifikator vozila.
  protected double vmax;        // Maksimalna brzina.
  private long t;               // Vreme poslednje promene brzine.
  private double v;             // Trenutna brzina.
  private double suma_vdt;      // Predjeni put do poslednjeg racunanja.
  private boolean radi = false; // Da li treba da vozi?

  public Vozilo (double vmax) { postavi (vmax); }  // Konstruktori.

  public Vozilo () { this (100); }

  public void postavi (double vmax)       // Postavljanje maksimalne brzine.
    { this.vmax = vmax; }

  public void run () {                    // Telo niti.
    try {
      while (! interrupted ()) {
        if (! radi) { v = 0; synchronized (this) { wait (); }}
        long u = System.currentTimeMillis ();
        suma_vdt += v * (u - t);
        t = u;
        v *= (0.95 + 0.2 * Math.random());
        if (v > vmax) v = vmax;
        if (v < 0.05*vmax) v = 0.05 * vmax;
        sleep (100 + (int)(Math.random()*100));
      }
    } catch (InterruptedException g) {}
  }

  public void pocni () { start (); }      // Pokretanje niti.

  public synchronized void kreni () {     // Polazak vozila.
    suma_vdt = 0;
    t = System.currentTimeMillis ();
    radi = true;
    notify ();
  }

  public void stani () { radi = false; }  // Zaustavljanje vozila.

  public void zavrsi () { interrupt (); } // Prekidanje niti.

  public int id () { return id; }         // Identifikacioni broj.

  public double v () { return v; }        // Trenutna brzina.

  public double s ()                      // Predjeni put.
    { return suma_vdt + (System.currentTimeMillis() - t) * v; }

  public String toString () {             // Tekstualni oblik.
    return id + " (s=" + (int)s() + ", v=" + (int)v() + ")";
  }
}