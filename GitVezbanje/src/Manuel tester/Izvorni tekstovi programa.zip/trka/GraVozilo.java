// GraVozilo.java - Klasa grafickih vozila.

package trka;
import java.awt.*;

public class GraVozilo extends Vozilo {

  private Panel plo;             // Ploca pridruzena vozilu.
  private TextField tksVmax =    // Polje za unas maksimalne brzine.
    new TextField (Double.toString(vmax), 3);
  private Label oznVozilo =      // Natpis za prikaz tekstualnog oblika.
    new Label (toString());

  public GraVozilo (double vmax, Panel plo) // Konstruktori.
    { super (vmax); popuniPlocu (plo); }

  public GraVozilo (Panel plo)
    { super (); popuniPlocu (plo); }

  private void popuniPlocu (Panel plo) {    // Popunjavanje ploce.
    this.plo = plo;
    plo.add (new Label ("vmax:", Label.RIGHT));
    plo.add (tksVmax);
    plo.add (oznVozilo);
  }

  public void kreni () {                    // Pokretanje vozila.
    try {
      postavi (Double.parseDouble(tksVmax.getText()));
    } catch (NumberFormatException g) {}
    super.kreni ();
  }

  public String toString () {               // Prikaz tekstualnog oblika.
    String s = super.toString ();
    if (oznVozilo != null) {
      oznVozilo.setText (s);
      plo.validate ();
    }
    return s;
  }
}