// Ciklus.java - Klasa ciklusa.

package naredbe;
import  izrazi.Izraz;

public class Ciklus extends Naredba {

  private Izraz izr;                         // Uslov ciklusa.
  private Naredba nar;                       // Sadrzaj ciklusa.

  public Ciklus (Izraz i, Naredba n)         // Inicijalizacija.
      { izr = i; nar = n; }

  public void radi ()                        // Izvrsavanje.
    { while (izr.vr () != 0) nar.radi (); }

  public String toString () {                // Tekstualni oblik.
    String s = nivo + "while(" + izr + ")\n";
    nivo += "  "; s += nar; nivo = nivo.substring (2);
    return s;
  }
}