// Prosta.java - Klasa prostih naredbi.

package naredbe;
import  izrazi.Izraz;

public class Prosta extends Naredba {

  Izraz izr;                                 // Izraz koji se izracunava.

  public Prosta () {}                        // Prazna naredba.

  public Prosta (Izraz i) { izr = i; }       // Inicijalizacija izrazom.

  public void radi ()                        // Izvrsavanje.
    { if (izr != null) izr.vr (); }

  public String toString ()                  // Tekstualni oblik.
    { return nivo + (izr != null ? izr : "") + ";\n"; }
}