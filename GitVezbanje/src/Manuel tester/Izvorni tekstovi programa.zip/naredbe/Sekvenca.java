// Sekvenca.java - Klasa sekvenci.

package naredbe;

public class Sekvenca extends Naredba {

  private Elem prva, posl;                   // Prva i poslednja naredba.

  private class Elem {                       // Element sekvence:
    Naredba nar;                             // - sadrzana naredba,
    Elem sled;                               // - sledeci element liste,
    Elem (Naredba n) {                       // - inicijalizacija.
      nar = n;
      if (prva == null) prva = this;
        else            posl.sled = this;
      posl = this;
    }
  }

  public Sekvenca dodaj (Naredba n)          // Dodavanje naredbe.
    { new Elem (n); return this; }

  public void radi ()                        // Izvrsavanje.
    { for (Elem tek=prva; tek!=null; tek=tek.sled) tek.nar.radi (); }

  public String toString () {                // Tekstualni oblik.
    String s = nivo +"{\n";
    nivo += "  ";
    for (Elem tek=prva; tek!=null; tek=tek.sled) s += tek.nar;
    nivo = nivo.substring (2);
    return s + nivo + "}\n";
  }
}