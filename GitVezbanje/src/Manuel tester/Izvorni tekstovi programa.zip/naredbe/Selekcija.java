// Selekcija.java - Klasa selekcija.

package naredbe;
import  izrazi.Izraz;

public class Selekcija extends Naredba {

  private Izraz izr;                       // Uslov selekcije.
  private Naredba nar1, nar2;              // Uslovno izvrsavane naredbe.

  public Selekcija (Izraz i, Naredba n1, Naredba n2) // Inicijalizacija.
    { izr = i; nar1 = n1; nar2 = n2; }

  public void radi ()                                // Izvrsavanje.
    { if (izr.vr () != 0) nar1.radi (); else nar2.radi (); }

  public String toString () {                        // Tekstualni oblik.
    String s = nivo + "if(" + izr + ")\n";
    nivo += "  "; s += nar1; nivo = nivo.substring (2);
    s += nivo + "else\n";
    nivo += "  "; s += nar2; nivo = nivo.substring (2);
    return s;
  }
}