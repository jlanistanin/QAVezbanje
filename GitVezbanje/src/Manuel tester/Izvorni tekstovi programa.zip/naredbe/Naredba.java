// Naredba.java - Apstraktna klasa naredbi.

package naredbe;

public abstract class Naredba {

  public abstract void radi ();       // Izvrsavanje.

  protected static String nivo = "";  // Nivo naredbe u tekstualnom obliku.

  public abstract String toString (); // Tekstualni oblik.
}