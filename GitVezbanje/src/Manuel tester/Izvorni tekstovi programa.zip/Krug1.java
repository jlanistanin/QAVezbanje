// Krug1.java - Izracunavanje obima i povrsine kruga.

public class Krug1 {
  public static void main (String[] vpar) {
    System.out.print ("Poluprecnik? ");
    double r = Citaj.Double ();
    System.out.println ("Obim     = " + (2*r*Math.PI));
    System.out.println ("Povrsina = " + (r*r*Math.PI));
  }
}
