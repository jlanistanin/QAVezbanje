// SkupT.java - Ispitivanje klase uredjenih skupova.

public class SkupT {
  public static void main (String[] vpar) {
    char jos;
    do {
      System.out.print ("niz1? "); Skup s1 = Skup.citaj ();
      System.out.print ("niz2? "); Skup s2 = Skup.citaj ();
      System.out.println ("s1   =" + s1);
      System.out.println ("s2   =" + s2);
      Skup s = new Skup ();
      s.unija  (s1, s2); System.out.println ("s1+s2=" + s );
      s.presek (s1, s2); System.out.println ("s1*s2=" + s );
      s.razlika(s1, s2); System.out.println ("s1-s2=" + s );
      System.out.print ("\nJos? "); jos = Citaj.Char ();
    } while (jos=='d' || jos=='D');
  }
}
