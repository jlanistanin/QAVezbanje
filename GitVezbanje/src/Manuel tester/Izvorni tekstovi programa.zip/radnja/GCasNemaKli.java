// GCasNemaKli.java - Klasa za greske: Nema trazenog klijenta casovnika.

package radnja;
import  pokretni.Pokretan;

public class GCasNemaKli extends usluge.Greska {
  
  private Pokretan klijent;                      // Problematicni klijent.
  
  public GCasNemaKli (Pokretan k)                // Inicijalizacija.
    { super ("Ne postoji klijent [" + k + "]"); klijent = k; }
    
  public Pokretan klijent () { return klijent; } // Dohvatanje klijenta.
}