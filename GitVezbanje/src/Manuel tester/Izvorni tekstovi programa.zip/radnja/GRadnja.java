// GRadnja.java - Apstraktna klasa gresaka za radnje.

package radnja;

public abstract class GRadnja extends usluge.Greska {

  public GRadnja (String por) { super (por); }  // Inicijalizacija.
  public GRadnja () {}
}