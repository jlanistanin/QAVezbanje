// PokRadnik.java - Klasa pokretnih radnika.

package radnja;
import  radionica.*;
import  pokretni.Pokretan;
import  polica.*;
import  predmeti1.*;

public class PokRadnik extends Radnik implements Pokretan {
  
  private Polica  pol;         // Odredisna polica.
  private double  maxT;        // Najduze vreme proizvodnje predmeta.
  private double  t;           // Preostalo vreme do narednog dogadjaja.
  private Predmet pred;        // Sledeci proizvedeni predmet.
 
  public PokRadnik (String ime, double tMax, Polica p) // Inicijalizacija.
    { super (ime); pol = p; maxT = tMax; }
  public PokRadnik (String ime, double tMax) { this (ime, tMax, null); }

  public PokRadnik polica (Polica p)            // Pridruzivanje police.
    { pol = p; return this; }
  
  public Pokretan proteklo (double dt) {        // Sledeci korak rada.
    if ((t -= dt) <= 0) {
      try {
        if (pred != null) {
          if (pol == null) throw new GRadNemaPol (this);
          pol.stavi (pred);
          System.out.println ("Radnik " + this + " je stavio " + pred);
        }
        pred = napravi ();
        t = Math.random () * maxT;
      } catch (GPolica g) {
        System.out.println ("Radnik " + this + " je zatekao punu policu");
      } catch (usluge.Greska g) {
        System.out.println (g);
      }
    }
    return this;
  }
}