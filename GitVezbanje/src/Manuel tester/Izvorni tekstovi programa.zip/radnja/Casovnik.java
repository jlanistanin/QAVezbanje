// Casovnik.java - Klasa casovnika.

package radnja;
import  pokretni.Pokretan;
import  liste.*;

public class Casovnik {
  
  private Lista kiljenti = new Lista (); // Lista klijenata.
  
  public Casovnik dodaj (Pokretan k)     // Dodavanje klijenta listi.
    { kiljenti.dodaj (k); return this; }
                                         // Izbacivanje klijenta iz liste. 
  public Casovnik izbaci (Pokretan k) throws GCasNemaKli {
    try { kiljenti.izbaci (k); }
      catch (GLstNemaObj g) { throw new GCasNemaKli (k); }
    return this;
  }
                                     // Parametri casovnika:
  private double dt;                 // - korak casovnika,
  private double t;                  // - trenutno vreme,
  private double tMax;               // - trajanje rada.
  
  public double dt () { return dt; } // Dohvatanje parametara casovnika.
  public double t () { return  t; }
  public double tMax () { return tMax; }
  
  public void radi (double dt, double tMax) { // Rad casovnika.
    this.dt = dt; this.tMax = tMax;
    for (t=0; t<=tMax; t+=dt) {
      System.out.println ("Vreme: " + t);
      for (kiljenti.naPrvi(); kiljenti.imaTek(); kiljenti.naSledeci())
        try { ((Pokretan)kiljenti.dohvatiTek()).proteklo (dt); }
          catch (GLstNemaTek g) {}
    }
  }
}