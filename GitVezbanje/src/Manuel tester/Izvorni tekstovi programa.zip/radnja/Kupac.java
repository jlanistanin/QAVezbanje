// Kupac.java - Klasa kupaca.

package radnja;
import  predmeti1.Predmet;

public class Kupac {

  private static int ukId;     // Poslednje kori�?eni identifikator.
  private int id = ++ukId;     // Identifikator kupca.
  private char vrsta;          // Vrsta predmeta koji se kupuje.

  public Kupac (char v) { vrsta = v; }        // Inicijalizacija.

  public int dohvatiId () { return id; }      // Dohvatanje identifikatora.

  public char dohvatiVrs () { return vrsta; } // Dohvatanje vrste predmeta.

  public void usluzen (Predmet p) {           // Preuzimanje predmeta.
    System.out.println (
      "Kupac  " + this + " " + (p!=null ? "je dobio " + p
                                        : "nije dobio nista")
    );
  }
                                              // Tekstualni oblik.
  public String toString () { return "K" + id + "(" + vrsta + ")"; }
}