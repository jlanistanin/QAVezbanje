// GRadNemaRad.java - Klasa za greske: Radnik ne postoji u radnji.

package radnja;

public class GRadNemaRad extends GRadnja {
  
  private PokRadnik radnik;                     // Problematicni radnik.
  
  public GRadNemaRad (PokRadnik r)              // Inicijalizacija.
    { super ("U radnji ne postoji radnik [" + r + "]"); radnik = r; }
    
  public PokRadnik radnik () { return radnik; } // Dohvatanje radnika.
}