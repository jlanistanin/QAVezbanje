// GRadNemaPol.java - Klasa za greske: Radnik nema policu.

package radnja;

public class GRadNemaPol extends GRadnja {
  
  private PokRadnik radnik;                     // Problematicni radnik.
  
  public GRadNemaPol (PokRadnik r)              // Inicijalizacija.
    { super ("Nije odrednjena polica radniku [" + r + "]"); radnik = r;}
    
  public PokRadnik radnik () { return radnik; } // Dohvatanje radnika.
}