// Radnja.java - Klasa radnji.

package radnja;
import  polica.Polica;
import  pokretni.Pokretan;
import  radionica.Masina;
import  predmeti1.Predmet;
import  liste.Lista;

public class Radnja {
  
  private Masina[] masine = new Masina [10];    // Masine za proizvodnju.
  private int brMas;                            // Broj masina.
  private Polica polica;                        // Polica sa artiklima.
  private Casovnik casovnik = new Casovnik ();  // Generator takta.
  private Lista kupci = new Lista ();           // Kupci u radnji.
 
  public Radnja (                      // Inicijalizacija:
                  double maxQ,         // - nosivost police,
                  int kap,             // - broj mesta na polici,
                  double maxUlaz,      // - najduze vreme do ulazka kupca,
                  double maxKup        // - najduze vreme kupovine.
                 ) {
    polica = new Polica (kap, maxQ);
    casovnik.dodaj (new Ulaz (maxUlaz));
    casovnik.dodaj (new Prodavac (maxKup));
  }

  public Radnja dodajMas (Masina mas)           // Nabavka masine.
    { masine[brMas++] = mas; return this; }
    
  public Radnja zaposli (PokRadnik radnik) {    // Zaposljavanje radnika.
    casovnik.dodaj (radnik);
    radnik.polica (polica);
    radnik.rasporedi (masine[(int)(Math.random()*brMas)]);
    System.out.println ("Zaposlen je radnik " + radnik);
    return this;
  }
                                                // Otpustanje radnika.
  public Radnja otpusti (PokRadnik radnik) throws GRadNemaRad {
    try { casovnik.izbaci (radnik); }
      catch (GCasNemaKli g) { throw new GRadNemaRad (radnik); }
    return this;
  }

  public void radi (double dt, double maxT)     // Radno vreme radnje.
    { casovnik.radi (dt, maxT); }

  private class Ulaz implements Pokretan {      // KLASA ULAZA U RADNJU.

    private double maxT;        // Najduze vreme do ulaska kupca.
    private double t;           // Preostalo vreme do narednog dogadjaja.
    private Kupac  kup;         // Sledeci kupac koji ulazi.
  
    private Ulaz (double tMax) { maxT = tMax; } // Inicijalizacija.
  
    public Pokretan proteklo (double dt) {      // Sledeci korak rada.
      if ((t -= dt) <= 0) {
        try {
          if (kup != null) {
            kupci.dodaj (kup);
            System.out.println ("Kupac  " + kup + " je usao");
          }
          int i = (int)(Math.random()*brMas);
          kup = new Kupac (masine[i].vrsta());
          t = Math.random () * maxT;
        } catch (Exception g) {}
      }
      return this;
    }
  } // class Ulaz
  
  private class Prodavac implements Pokretan {  // KLASA PRODAVCA.

    private double maxT;        // Najduze vreme kupovine.
    private double t;           // Preostalo vreme do narednog dogadjaja.
    private Kupac  kup;         // Kupac koji kupuje.
  
    private Prodavac (double tMax) { maxT = tMax; } // Inicijalizacija.

    public Pokretan proteklo (double dt) {          // Sledeci korak rada.
      if ((t -= dt) <= 0) {
        if (kup != null) {
          int i; Predmet p = null;
          for (i=0; i<polica.kapacitet(); i++)
            try {
              if ((p = polica.dohvati (i)).vr() == kup.dohvatiVrs())
                break;
            } catch (Exception g) {}
          if (p != null) try { polica.uzmi (i); } catch (Exception g) {}
          kup.usluzen (p);
          kup = null;
        }
        try {
          kup = (Kupac)kupci.naPrvi().dohvatiTek ();
          kupci.izbaci(kup);
          t = Math.random () * maxT;
        } catch (usluge.Greska g) {}
      }
      return this;
    }
  } // class Prodavac
} // class Radnja