// Izraz3.java - Izracunavanje zbira faktorijela.

public class Izraz3 {
  public static void main (String[] vpar) {
    System.out.print ("n? "); int n = Citaj.Int ();
    long s = 0;
    for (int f=1, i=1; i<=n; i++) {
      f *= i;
      s += f;
    }
    System.out.println ("s= " + s);
  }
}
