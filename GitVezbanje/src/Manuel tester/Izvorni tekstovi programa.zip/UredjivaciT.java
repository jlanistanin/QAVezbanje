// Uredivaci1T.java - Ispitivanje klasa za uredjivanje nizova.

import uredjivaci1.*;
import usluge.Uporediv;
import java.util.Random;

public class UredjivaciT {

  // Niz za objekte algoritama uredjivanja.
  private static Uredjivac[] metode = {
    new MetodaIzbora (),       new MetodaIzbora2 (),
    new MetodaUmetanja (),     new MetodaUmetanja2 (),
    new MetodaZameneSuseda (), new MetodaPodele ()
  };

  // Ispisivanje niza.
  private static void pisi (String nasl, Uporediv[] niz) {
    System.out.print ("\n" + nasl + "\n\n");
    for (int i=0; i<niz.length; i++) {
      System.out.print (niz[i] + "\t");
      if (i%8==7 || i==niz.length-1) System.out.println ();
    }
  }

  // Glavna funkcija.
  public static void main (String[] vpar) {
    Uredjivac metoda = metode[0];
    Uporediv[] niz = new Ceo [1000];
    Random sluc = new Random ();
    radi: while (true) { // Ispisivanje menija:
      System.out.print (
        "\n1. Zadavanje duzine niza\n"                     +
          "2. Postavljanje generatora slucajnih brojeva\n" +
          "3. Izbor algoritma\n"                           +
          "4. Primena algoritma\n"                         +
          "0. Kraj programa\n"                             +
          "Vas izbor? "
      );
      switch (Citaj.Int ()) {

        case 1: // Zadavanje duzine niza:
          System.out.print ("Duzina niza? ");
          int d = Citaj.Int ();
          if (d > 0) niz = new Ceo [d];
            else System.out.println ("*** Nedozvoljena duzina!");
          break;

        case 2: // Postavljanje generatora slucajnih brojeva:
          System.out.print ("Pocetna vrednost generatora? ");
          sluc = new Random (Citaj.Long ());
          break;

        case 3: // Izbor algoritma:
          System.out.println ();
          for (int i=0; i<metode.length; i++)
            System.out.println (i+1 + ". " + metode[i]);
          System.out.print ("Vas izbor? ");
          int izbor = Citaj.Int ();
          if (izbor>0 && izbor<=metode.length)
            metoda = metode [izbor-1];
            else System.out.println ("*** Nedozvoljen izbor!");
          break;

        case 4: // Primena algoritma:
          for (int i=0; i<niz.length; i++)
            niz[i] = new Ceo ((int)(sluc.nextDouble() * 10000));
          if (niz.length <= 100) pisi ("Pocetni niz:", niz);
          long t1 = System.currentTimeMillis ();
          metoda.uredi (niz);
          long t2 = System.currentTimeMillis ();
          if (niz.length <= 100)
            pisi ("Uredjeni niz:", niz);
          else
            System.out.println (metoda + " (" + niz.length + "): " +
                                (t2-t1)/1000.);
            break;

        case 0: // Kraj programa:
          break radi;

        default: // Pogresan izbor:
          System.out.println ("*** Nedozvoljen izbor!");
          break;
      }
    }
  }
}