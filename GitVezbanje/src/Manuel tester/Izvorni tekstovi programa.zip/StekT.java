// StekT.java - Ispitivanje klase stekova ogranicenih kapaciteta.

public class StekT {
  public static void main (String[] vpar) {
    Stek s = new Stek ();
    radi: while (true) {
      System.out.print (
        "\n1. Stvaranje steka\n"      +
          "2. Stavljanje podatka\n"   +
          "3. Uzimanje podatka\n"     +
          "4. Ispisivanje sadrzaja\n" +
          "5. Praznjenje steka\n"     +
          "0. Zavrsetak rada\n\n"     +
          "Vas izbor? "
      );
      switch (Citaj.Int ()) {
        case 1: System.out.print     ("Kapacitet? ");
                s = new Stek (Citaj.Int ());
                break;
        case 2: if (! s.pun ()) {
                  System.out.print   ("Broj?      ");
                  s.stavi (Citaj.Int ());
                } else System.out.println ("*** Stek je pun ***");
                break;
        case 3: if (! s.prazan ())
                  System.out.println ("Broj=      " + s.uzmi());
                else System.out.println ("*** Stek je prazan ***");
                break;
        case 4: System.out.println   ("Stek=      " + s); break;
        case 5: s.prazni (); break;
        case 0: break radi;
        default: System.out.println ("*** Nedozvoljeni izbor ***");
      }
    }
  }
}
