// Fun.java - Apstraktna klasa funkcija.

package grafik;

abstract class Funkcija {
  double p, q, r, s;                   // Koeficijenti funkcije.

  void postavi (double a, double b, double c, double d)
    { p = a; q = b; r = c; s = d; }    // Postavljanje koeficijenata.

  abstract double f (double x);        // Vrednost funkcije.
  public abstract String toString ();  // Tekstualni oblik funkcije.
}
