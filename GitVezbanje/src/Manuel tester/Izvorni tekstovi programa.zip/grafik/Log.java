// Log.java - Klasa logaritamskih funkcija.

package grafik;

class Log extends Funkcija {

  double f (double x)                  // Vrednost funkcije.
    { return p + q * Math.log (x); }

  public String toString ()            // Tekstualni oblik.
    { return "p + q ln x"; }
}
