// Poli3.java - Klasa polinoma treceg reda.

package grafik;

class Poli3 extends Funkcija {

  double f (double x)                   // Vrednost polinoma.
    { return ((p * x + q) * x + r) * x + s; }

  public String toString ()            // Tekstualni oblik.
    { return "px^3+qx^2+rx+s"; }
}
