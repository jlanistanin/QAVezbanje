// Oscil.java - Klasa prigusenih oscilacija.

package grafik;

class Oscil extends Funkcija {

  double f (double x)                  // Vrednost funkcije.
    { return p * Math.exp (q*x) * Math.sin (r*x+s); }

  public String toString ()            // Tekstualni oblik.
    { return "p e^(qx) sin(rx+s)"; }
}
