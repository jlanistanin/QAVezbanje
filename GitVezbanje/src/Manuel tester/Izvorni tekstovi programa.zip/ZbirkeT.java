// ZbirkeT.java - Ispitivanje klasa zbirki.

import zbirke.*;

public class ZbirkeT {

  public static void main (String[] varg) {
    Zbirka[] nizZb = { new NUNiz (),   new UNiz (),
                       new NULista (), new ULista () };
    String[] nasl  = { "NEUREDJEN NIZ", "UREDJEN NIZ",
                       "NEUREDJENA LISTA", "UREDJENA LISTA" };
    int[] niz = {6, 3, 7, 9, 2, 0, 4, 1, 8, 5, 2, 5, 3, 8, 0};
    for (int i=0; i<nizZb.length; i++)
      radi (nasl[i], nizZb[i], niz);
  }

  private static void radi (String nasl, Zbirka zb, int[] niz) {
    System.out.println ("\n" + nasl);
    try {
      for (int i=0; i<niz.length; zb.dodaj (niz[i++]));
      System.out.println ("Napravljena zbirka: " + zb);

      System.out.print   ("Indeksiranjem:       ");
      for (int i=0; i<zb.vel(); i++)
        System.out.print (zb.dohvati(i) + " ");
      System.out.println ();

      System.out.print   ("Iteratorom:          ");
      Iterator it = zb.iterator();
      for (it=it.naPocetak(); it.imaTek(); it.naSledeci())
        System.out.print (it.dohvatiTek() + " ");
      System.out.println ();

      System.out.println ("zb[4]=7 (indeksom): " + zb.postavi(4,7));

      it.naPocetak ();
      for (int i=0; i<7; i++) it.naSledeci();
      it.postaviTek (3);
      System.out.println ("zb[7]=3  (iterom):  " + zb);
      System.out.println ("  tekuci:            " + it.dohvatiTek());

      it.brisiTek ();
      System.out.println ("Brisi tekuci:       " + zb);
      System.out.println ("  tekuci:            " + it.dohvatiTek());
      System.out.println ("Brisi zb[10]:       " + zb.brisi(10));
    } catch (GZbirka  g) { System.out.println (g); }
  }
}