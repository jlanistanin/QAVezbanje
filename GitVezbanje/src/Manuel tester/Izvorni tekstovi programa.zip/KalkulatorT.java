// KalkulatorT.java - Nezavisan program koji koristi kalkulator.

import java.awt.*;
import java.awt.event.*;

public class KalkulatorT extends Frame {

  Kalkulator kalk = new Kalkulator (420, 50);   // Prozor kalkulatora.
  Label rez = new Label ("", Label.CENTER);     // Ocitana vrednost.

  private void popuniProzor () {                // Popunjavanje prozora:
    add (rez, "North");                                // - polje rezultata,

    Panel  ploca = new Panel (); add (ploca, "South"); // - otvaranje
    Button dugme = new Button ("Otvori");              //   kalkulatora,
    ploca.add (dugme);
    dugme.addActionListener (new ActionListener () {
      public void actionPerformed (ActionEvent d) {
        kalk.setVisible (true);
      }
    });

    ploca.add (dugme = new Button ("Ocitaj"));         // - ocitavanje
    dugme.addActionListener (new ActionListener () {   //   kaklulatora,
      public void actionPerformed (ActionEvent d) {
        rez.setText (Long.toString (kalk.rezultat ()));
      }
    });

    ploca.add (dugme = new Button ("Zatvori"));        // - zatvaranje
    dugme.addActionListener (new ActionListener () {   //   kalkulatora.
      public void actionPerformed (ActionEvent d) {
        kalk.setVisible (false);
      }
    });
  }

  private KalkulatorT () {                      // Inicijalizacija:
    super ("Neki program");
    setBounds (100, 50, 300, 200);
    popuniProzor ();                            // - popunjavanje prozzora,
    addWindowListener (new WindowAdapter () {
      public void windowClosing (WindowEvent d) // - unistavanje oba
        { kalk.dispose (); dispose (); }        //   prozora,
    });
  }

  public static void main (String[] varg) {            // Glavna funkcija.
    new KalkulatorT ().setVisible (true);
  }
}