// Fun.java - Interfejs za funkcije.


package izvodi;

public interface Fun {

  double f (double x);                        // Vrednost funkcije.

  Fun izv ();                                 // Izvod funkcije.

  String toString ();                         // Tekstualni oblik.
}