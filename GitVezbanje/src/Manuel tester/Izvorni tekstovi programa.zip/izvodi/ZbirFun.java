// ZbirFun.java - Klasa zbirova funkcija.

package izvodi;

public class ZbirFun implements Fun {

  private Fun[] niz;                          // Niz funkcija.
  private int duz;                            // Broj popunjenih mesta.

  public ZbirFun (int n) { niz = new Fun [n]; }     // Inicijalizacija.
  public ZbirFun () { this (2); }

  public ZbirFun dodaj (Fun f) throws GZbirFunPun { // Dodavanje funkcije.
    if (duz == niz.length) throw new GZbirFunPun ();
    niz[duz++] = f;
    return this;
  }

  public double f (double x) {                      // Racunanje vrednosti.
    double s = 0;
    for (int i=0; i<duz; s+=niz[i++].f(x));
    return s;
  }

  public Fun izv (){                                // Stvaranje izvoda.
    ZbirFun z = new ZbirFun (niz.length);
    try {
      for (int i=0; i<duz; z.dodaj(niz[i++].izv()));
    } catch (GZbirFunPun g) {}
    return z;
  }

  public String toString () {                       // Tekstualni oblik.
    StringBuffer s = new StringBuffer();
    for (int i=0; i<duz; i++) {
      if (i > 0) s.append ('+');
      s.append ('(').append (niz[i]).append (')');
    }
    return s.toString ();
  }
}