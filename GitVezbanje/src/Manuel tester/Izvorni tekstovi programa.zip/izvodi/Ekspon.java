// Ekspon.java - Klasa eksponencijalnih funkcija.

package izvodi;

public class Ekspon implements Fun {

  private double a, b;                        // Parametri.

  public Ekspon (double aa, double bb)        // Inicijalizacija.
    { a = aa; b = bb; }

  public Ekspon () { a = b = 1; }

  public double f (double x)                  // Racunanje vrednosti.
    { return a * Math.exp (b * x); }

  public Fun izv ()                           // Stvaranje izvoda.
    { return new Ekspon (a*b, b); }


  public String toString ()                   // Tekstualni oblik.
    { return a + "*exp(" + b + "*x)"; }
}