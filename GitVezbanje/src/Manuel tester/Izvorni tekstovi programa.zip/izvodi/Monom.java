// Monom.java - Klasa monoma.

package izvodi;

public class Monom implements Fun {

  private double a, b;                        // Parametri.

  public Monom (double aa, double bb)         // Inicijalizacija.
    { a = aa; b = bb; }

  public Monom () { a = b = 1; }

  public double f (double x)                  // Racunanje vrednosti.
    { return a * Math.pow (x, b); }

  public Fun izv ()                           // Stvaranje izvoda.
    { return new Monom (a*b, b-1); }

  public String toString ()                   // Tekstualni oblik.
    { return a + "*x^" + b; }
}