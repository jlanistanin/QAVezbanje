// GZbirFunPun.java - Klasa za greske: Zbir funkcija je pun.

package izvodi;

public class GZbirFunPun extends Exception {

  public String toString ()                   // Tekstualni oblik.
    { return "*** Zbir funkcija je pun!"; }
}