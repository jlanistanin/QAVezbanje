// VektT.java - Ispitivanje klase realnih vektora.

import vektor.*;

public class VektT {
  public static void main (String[] varg) {
    while (true) {
      try {
        System.out.print ("Opseg indeksa prvog  vektora? ");
        int min = Citaj.Int (), max = Citaj.Int ();
    if (min==0 && max==0) break;
        Vekt v1 = new Vekt (min, max);
        System.out.print ("Komponente  prvog vektora?    "); 
        for (int i=min; i<=max; v1.postavi(i++, Citaj.Double()));
        System.out.print ("Opseg indeksa drugog vektora? ");
        min = Citaj.Int (); max = Citaj.Int ();
    if (min==0 && max==0) break;
        Vekt v2 = new Vekt (min, max);
        System.out.print ("Komponente  prvog vektora?    "); 
        for (int i=min; i<=max; v2.postavi(i++, Citaj.Double()));
        System.out.println ("Skalarni proizvod = " +
                            Vekt.skalPro (v1, v2) + "\n");
      } catch (GVekt g) {
        System.out.println (g + "\n");
      } catch (OutOfMemoryError g) {
        System.out.println ("*** Dodela memorije nije uspela!\n");

      }
    }
  }
}