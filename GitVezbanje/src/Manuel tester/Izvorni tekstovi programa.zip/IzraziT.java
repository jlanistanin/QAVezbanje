// IzraziT.java - Ispitivanje klasa za izraze.

import izrazi.*;

public class IzraziT {
  public static void main (String[] vpar) {
    Prom x    = new Prom ("x"),
         xmin = new Prom ("xmin", Double.parseDouble(vpar[0])),
         xmax = new Prom ("xmax", Double.parseDouble(vpar[1])),
         dx   = new Prom ("dx",   Double.parseDouble(vpar[2]));
    Izraz izr = new Razl (
                  new Step   (x , new Konst(3)) ,
                  new Proizv (new Konst(2) , x)
                );
    Zbir korak = new Zbir (x, dx);
    System.out.println (
      xmin + "=" + xmin.vr() + ", " +
      xmax + "=" + xmax.vr() + ", " +
      dx   + "=" + dx  .vr()
    );
    System.out.println ("\n" + x + "\t" + izr +
                        "\n======================");
    for (x.postavi(xmin); x.vr()<=xmax.vr(); x.postavi(korak))
      System.out.println (x.vr() + "\t" + izr.vr());
  }
}