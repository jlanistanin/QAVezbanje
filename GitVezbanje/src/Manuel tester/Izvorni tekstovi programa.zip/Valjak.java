// Valjak.java - Klasa valjaka.

public class Valjak {

  private double r, h;                          // Poluprecnik i visina.
                                                // Inicijalizacija.
  public Valjak (double rr, double hh) { r = rr; h = hh; }

  public Valjak () { r = h = 1; }

  public double r () { return r; }                   // Poluprecnik.

  public double h () { return h; }                   // Visina.

  public double V () { return r * r * Math.PI * h; } // Zapremina.

  public String toString ()                          // Tekstualni oblik.
    { return "[" + r + "," + h + "]"; }
}