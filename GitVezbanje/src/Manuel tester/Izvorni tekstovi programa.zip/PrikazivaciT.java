// PrikazivaciT.java - Ispitivanje klasa prikazivaca i uredjivaca.

import prikazivaci.*;
import uredjivaci2.*;
import java.awt.*;
import java.awt.event.*;

public class PrikazivaciT extends Frame {
  private Prikazivac[] prik = {        // Raspolozivi prikazivaci.
    new Konzola   (8, "%8.3f"),
    new Prozor    ("Prozor"   , 400,  50, 200, 160, "%8.3f"),
    new Histogram ("Histogram", 650,  50, 200, 160)
  };
  private Uredjivac[]  ured = {        // Raspolozivi uredjivaci.
    new MetodaIzbora (),       new MetodaIzbora2 (),
    new MetodaUmetanja(),      new MetodaUmetanja2 (),
    new MetodaZameneSuseda (), new MetodaPodele()
  };
  private TextField                    // Polja za tekst:
    tksDuz = new TextField ("20"),     // - duzina niza,
    tksDt  = new TextField ("100");    // - trajanje pauze.
  private SkupPrikazivaca prikazivac = // Skup aktivnih prikazivaca.
            new SkupPrikazivaca ();
  private Uredjivac uredjivac = null;  // Odabrani uredjivac.
  private double[] niz;                // Obradjivani niz.

                           // Klasa polja za potvrdu za izbor prikazivaca:
  private class Potvrda extends Checkbox {
    private Prikazivac prik;                   // - pridruzeni prikazivac.

    public Potvrda (Prikazivac p, boolean st) {// - inicijalizacija,
      super (p.toString(), st); prik = p;
      if (st) prikazivac.dodaj (p);
      if (p instanceof Frame) ((Frame)p).setVisible (st);
      addItemListener (new ItemListener () {         // - obrada promene
        public void itemStateChanged (ItemEvent d) { //   stanja polja.
          boolean st = getState ();
          if (prik instanceof Frame) ((Frame)prik).setVisible (st);
          if (st) prikazivac.dodaj  (prik);
            else  prikazivac.ukloni (prik);
        }
      });
    }
  } // class Potvrda

  private CheckboxGroup grupa =              // Grupa radio dugmadi.
            new CheckboxGroup ();

                               // Klasa radio dugmadi za izbor uredjivaca:
  private class Radio extends Checkbox {
    private Uredjivac ured;                  // - pridruzeni uredjivac,

    public Radio (Uredjivac u, boolean st) { // - inicijalizacija.
      super (u.toString(), grupa, st); ured = u;
    }
  } // class Radio

  private void popuniProzor () {                   // Popunjavanje prozora:
    Panel plo = new Panel (new GridLayout (0, 1)); // - ploca za izbor
    add (plo, "West");                             //   prikazivaca,
    for (Prikazivac p: prik)
      plo.add (new Potvrda (p, true));

    add (plo = new Panel (new GridLayout (0, 1)),  // - ploca za izbor
                          "East");                 //   uredjivaca,
    boolean st = true;
    for (Uredjivac  u: ured)
      { plo.add (new Radio (u, st)); st = false; }

    plo = new Panel (); add (plo, "South");        // - ploca za upravljanje
    plo.add (new Label ("duz:", Label.RIGHT));     //   (duzina niza)
    plo.add (tksDuz);
    plo.add (new Label ("dt:" , Label.RIGHT));     //   (trajanje pauze)
    plo.add (tksDt);
    plo.add (new Label());
    tksDt.addTextListener (new TextListener () {   //   (obrada promene
      public void textValueChanged (TextEvent d) { //    trajanja pauze)
        try {
          uredjivac.postaviDt (Long.parseLong (tksDt.getText()));
        } catch (NumberFormatException g) {}
      }
    });

    Button dgm = new Button ("Kreni");             //   (dugme za pocetak
    plo.add (dgm);                                 //    uredjivanja)
    dgm.addActionListener (new DugmeAkcija());

    dgm = new Button ("Prekini"); plo.add (dgm);   //   (dugme za
    dgm.addActionListener (new ActionListener () { //    prekidanje).
      public void actionPerformed (ActionEvent d) {
        if (uredjivac != null) uredjivac.prekini ();
      }
    });
  } // popuniProzor()

  private PrikazivaciT () {                        // Inicijalizacija:
    super ("Uredjivanje");
    setBounds (50, 50, 300, 160);
    setResizable (false);
    popuniProzor ();

    addWindowListener (new WindowAdapter () {      // - obrada zatvaranja
      public void windowClosing (WindowEvent d) {  //   prozora,
        if (uredjivac != null) uredjivac.prekini ();
        for (int i=0; i<prik.length; i++)
          if (prik[i] instanceof Frame)
            ((Frame)prik[i]).dispose ();
        dispose ();
      }
    });
  } // PrikazivaciT()

                // Klasa rukovaoca dogadjajima pri pokretanju uredjivanja.
  private class DugmeAkcija implements ActionListener {
    public void actionPerformed (ActionEvent d) {
      if (uredjivac != null) uredjivac.prekini ();
      uredjivac  = ((Radio)grupa.getSelectedCheckbox()).ured;
      uredjivac.postaviPrikazivaca (prikazivac);
      uredjivac.postaviDt (Long.parseLong (tksDt.getText()));
      niz = new double [Integer.parseInt(tksDuz.getText())];
      for (int i=0; i<niz.length; niz[i++]=(Math.random()*10));
      uredjivac.uredi (niz);
    }
  } // class DugmeAkcija

  public static void main (String[] varg) {        // Glavna funkcija.
    new PrikazivaciT ().setVisible (true);
  }
}