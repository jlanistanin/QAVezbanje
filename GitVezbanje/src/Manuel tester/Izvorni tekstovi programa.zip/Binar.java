// Binar.java - Ispisivanje u binarnom brojevnom sistemu.

public class Binar {
  public static void main (String[] vpar) {
    while (true) {
      System.out.print ("Decimalan broj? "); short dec = Citaj.Short ();
    if (dec == 9999) break;
      System.out.print ("Binaran broj:   ");
      for (int i=1; i<=16; i++) {
        int bit = (dec & 0x8000) >>> 15;
        System.out.print (bit);
        if (i % 4 == 0) System.out.print (' ');
        dec <<= 1;
      }
      System.out.println ();
    }
  }
}
