// MatricaT.java - Ispitivanje klase matrica realnih brojeva.

import matrica.*;
import usluge.Citaj;

class MatricaT {
  public static void main (String[] varg) {
    Matr[] mat =  new Matr [Integer.parseInt (varg[0])];
    for (int i=0; i<mat.length; mat[i++]=new Matr());
    int m1 = 0;
    radi: while (true) {
      System.out.print (
        "\n1. Izbor matrice           5. Zbir matrica\n"     +
          "2. Unos matrice            6. Razlika matrica\n"  +
          "3. Prikaz matrice          7. Proizvod matrica\n" +
          "4. Postavljanje elementa   8. Prikaz elementa\n"  +
          "0. Kraj rada\n\n"                                 +
          "Vas izbor? "
      );
      try {
        int izb = Citaj.Int ();
        switch (izb) {
          case 1:  // Izbor matrice:
            System.out.print ("Indeks?    ");
            m1 = Citaj.Int ();
            break;
          case 2:  // Unos matrice:
            mat[m1].citaj (); break;
          case 3:  // Prikaz matrice:
            System.out.print (mat[m1]); break;
          case 4:  // Postavljanje elementa:
            System.out.print ("Indeksi?   ");
            int i = Citaj.Int (), j = Citaj.Int ();
            System.out.print ("Vrednost?  ");
            mat[m1].postavi (i, j, Citaj.Double());
            break;
          case 5: case 6: case 7: // Zbir, razlika i proizvod matrica:
            System.out.print ("Ind. druge matr.? ");
            int m2 = Citaj.Int (); Matr m = null;
            switch (izb) {
              case 5: m = Matr.zbir(mat[m1],mat[m2]);     break;
              case 6: m = Matr.razlika(mat[m1],mat[m2]);  break;
              case 7: m = Matr.proizvod(mat[m1],mat[m2]); break;
            }
            System.out.print (m);
            break;
          case 8:  // Prikaz elementa:
            System.out.print   ("Indeksi?   ");
            System.out.println ("Vrednost=  " +
                                mat[m1].dohvati(Citaj.Int(),Citaj.Int()));
            break;
          case 0:  // Kraj rada.
            break radi;
          default: // Nedozvoljeni izbor.
            throw new Exception ("Nedozvoljeni izbor \"" + izb +"\"");
        }
      } catch (Exception g) { System.out.println (g); }
    }
  }
}