// IntegraliT.java - Ispitivanje racunanja integrala.

import integrali.*;

public class IntegraliT {
  public static void main (String[] varg) {
    radi: while (true) {
      Fun fun = null;
      try {
        System.out.print ("\nFunkcija (S, O, P, L, .)? ");
        switch (Citaj.Char ()) {
          case 's': case 'S': fun = new Sin (); break;
          case 'o': case 'O': fun = new Oscil (); break;
          case 'p': case 'P': {
            System.out.print ("Red polinoma? "); int n = Citaj.Int ();
            Poli p = new Poli (n);
            while (true) {
              System.out.print ("Indeks i vrednost koeficijenta? ");
              int i = Citaj.Int ();
            if (i<0) break;
              p.postavi(i, Citaj.Double ());
            }
            fun = p;
            break;
          }
          case 'l': case 'L': fun = new Log (); break;
          case '.': break radi;
          default: throw new usluge.Greska ("Nedozvoljen izbor!");
        }
        System.out.print ("Interval? ");
        System.out.println ("Integral= " +
                            fun.I (Citaj.Double(), Citaj.Double()));
      } catch (usluge.Greska g) { System.out.println (g);
      } catch (vektor.GVekt g)  { System.out.println (g);
      }
    }
  }
}