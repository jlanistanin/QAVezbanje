// Ceo.java - Klasa uporedivih celih brojeva.

import usluge.Uporediv;

public class Ceo implements Uporediv {

  private int broj;                    // Vrednost u objektu.

  public Ceo (int b) { broj = b; }     // Inicijalizacija.

  public int vr () { return broj; }    // Dohvatanje vrednosti.

  public boolean ispred (Uporediv b)   // Da li je ispred drugog objekta?
    { return broj < ((Ceo)b).broj; }

  public boolean jednak (Uporediv b)   // Da li je jednak drugom objektu?
    { return broj == ((Ceo)b).broj; }

  public String toString ()            // Tekstualni oblik.
    { return Integer.toString (broj); }
}