// UredjivanjeT.java - Ispitivanje uredjivanja pracenjem protoka vremena.

import uredjivanje.*;

public class UredjivanjeT {
  public static void main (String[] varg) {
    Casovnik cas = new Casovnik (200, '*');
    Uredjivac izbor = new Izbor (cas);
    NizZnakova niz = new NizZnakova (75);
    System.out.print (niz + "\n");
    niz.uredi (izbor);
    System.out.print ("\n\n" + niz);
    cas.zavrsi ();
  }
}
