// Trougao2T.java - Ispitivanje klase trouglova.

public class Trougao2T {
  public static void main (String[] vpar) {
    System.out.print ("Broj trouglova? "); int n = Citaj.Int ();
    Trougao2[] niz = new Trougao2 [n];
    for (int i=0; i<n; ) {
      System.out.print (i+1 + ". trougao? ");
      double a = Citaj.Double(), b = Citaj.Double(), c = Citaj.Double();
      if (Trougao2.moze (a,b,c)) niz[i++] = new Trougao2 (a, b, c);
        else System.out.println ("*** Neprihvatljive stranice!");
    }
    for (int i=0; i<n-1; i++)
      for (int j=i+1; j<n; j++)
        if (niz[j].P() < niz[i].P())
          { Trougao2 pom = niz[i]; niz[i] = niz[j]; niz[j] = pom; }
    System.out.print ("\nUredjeni niz trouglova:\n");
    for (int i=0; i<n; i++) {
      System.out.println (i+1 + ": " + niz[i] + " P=" + niz[i].P());
    }
  }
}
