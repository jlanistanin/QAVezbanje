// Skup.java - Klasa uredjenih skupova.

class Skup {
  private double[] niz;                      // Elementi skupa.
                                             // Stvaranje skupa:
  public Skup () { niz = new double [0]; }   //   praznog,

  public Skup (double b)                     //   od jednog broja.
    { niz = new double [1]; niz[0] = b; }

  private void kopiraj (double[] a, int n) { // Kopiranje niza u skup.
    niz = new double [n];
    for (int i=0; i<n; niz[i]=a[i++]);
  }

  public void unija  (Skup s1, Skup s2) {    // Unija dva skupa.
    double[] a = new double [s1.niz.length+s2.niz.length]; int n = 0;
    for (int i=0, j=0; i<s1.niz.length || j<s2.niz.length; ) {
      a[n++] = i==s1.niz.length    ? s2.niz[j++] :
               j==s2.niz.length    ? s1.niz[i++] :
               s1.niz[i]<s2.niz[j] ? s1.niz[i++] :
               s1.niz[i]>s2.niz[j] ? s2.niz[j++] :
                                     s1.niz[i++] ;
      if (j<s2.niz.length && s2.niz[j]==a[n-1]) j++;
    }
    kopiraj (a, n);
  }

  public void presek (Skup s1, Skup s2) {    // Presek dva skupa.
    double[] a = new double [s1.niz.length<s2.niz.length ?
                             s1.niz.length : s2.niz.length];
    int n = 0;
    for (int i=0, j=0; i<s1.niz.length && j<s2.niz.length; )
      if      (s1.niz[i] < s2.niz[j]) i++;
      else if (s1.niz[i] > s2.niz[j]) j++;
      else                          { a[n++] = s1.niz[i++]; j++; }
    kopiraj (a, n);
  }

  public void razlika (Skup s1, Skup s2) {   // Razlika dva skupa.
    double[] a = new double [s1.niz.length]; int n = 0;
    for (int i=0, j=0; i<s1.niz.length; )
      if      (j == s2.niz.length)    a[n++] = s1.niz[i++];
      else if (s1.niz[i] < s2.niz[j]) a[n++] = s1.niz[i++];
      else if (s1.niz[i] > s2.niz[j]) j++;
      else                          { i++; j++; }
    kopiraj (a, n);
  }

  public String toString () {                // Tekstualni oblik skupa.
    String s = "{";
    for (int i=0; i<niz.length; i++)
      { s += niz[i]; if (i < niz.length-1) s += ","; }
    return s + "}";
  }

  public static Skup citaj () {              // Citanje skupa.
    Skup s = new Skup (); int n = Citaj.Int ();
    for (int i=0; i<n; i++) s.unija (s, new Skup (Citaj.Double()));
    return s;
  }

  public int velicina () { return niz.length; } // Velicina skupa.
}
