// Red.java - Klasa redova neogranicenih kapaciteta.

public class Red {

  private Elem prvi, posl;                          // Pocetak i kraj reda.

  public void stavi (int broj) {                    // Stavljanje na kraj.
    Elem novi = new Elem (broj);
    if (prvi == null) prvi = novi; else posl.sled = novi;
    posl = novi;
  }

  public int uzmi () {                              // Uzimanje s pocetka.
    if (prvi == null) {
      System.out.print ("\n*** Red je prazan ***\n");
      System.exit (1);
    }
    int b = prvi.broj;
    if ((prvi = prvi.sled) == null) posl = null;
    return b;
  }

  public void prazni () { prvi = posl = null; }     // Praznjenje reda.

  public boolean prazan () { return prvi == null; } // Da li je prazan?

  public String toString () {                       // Tekstualni oblik.
    String s = "";
    for (Elem tek=prvi; tek!=null; tek=tek.sled)
      s += tek.broj + " ";
    return s;
  }
}
