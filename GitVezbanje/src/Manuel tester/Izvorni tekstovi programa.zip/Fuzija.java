// Fuzija.java - Fuzija dva uredjena niza celih brojeva.

public class Fuzija {
  public static void main (String[] vpar) {
    while (true) {
      System.out.print ("na? "); int na = Citaj.Int ();
    if (na < 0) break;
      int[] a = new int [na];
      System.out.print ("A ? "); for (int i=0; i<na; a[i++]=Citaj.Int());
      if (na == 0) System.out.println ();
      System.out.print ("nb? "); int nb = Citaj.Int ();
    if (nb < 0) break;
      int[] b = new int [nb];
      System.out.print ("B ? "); for (int i=0; i<nb; b[i++]=Citaj.Int());
      if (nb == 0) System.out.println ();
      int nc = na + nb; int[] c = new int [nc];
      int ia = 0, ib = 0, ic = 0;
      while (ia<na && ib<nb)
        c[ic++] = (a[ia] < b[ib]) ? a[ia++] : b[ib++];
      while (ia < na) c[ic++] = a[ia++];
      while (ib < nb) c[ic++] = b[ib++];
      System.out.print ("C = ");
      for (int i=0; i<nc; System.out.print(c[i++]+" "));
      System.out.print ("\n\n");
    }
  }
}
