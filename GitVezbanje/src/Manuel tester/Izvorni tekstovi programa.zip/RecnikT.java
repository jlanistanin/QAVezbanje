// RecnikT.java - Ispitivanje klase recnika.

import usluge.Citaj;

public class RecnikT {
  public static void main (String[] varg) {
    Recnik r = Recnik.otvori ("RecnikT.dat");
    radi: while (true) {
      System.out.print ("\n1. Trazenje prevoda\n"      +
                          "2. Dodavanje prevoda\n"     +
                          "3. Brisanje prevoda\n"      +
                          "4. Brisanje svih prevoda\n" +
                          "5. Prikazivanje recnika\n"  +
                          "0. Zavrsetak rada\n\n"      +
                          "Vas izbor? "                  );
      String rec = "", prevod = ""; String[] prevodi = null;
      switch (Citaj.Char ()) {
        case '1': // Trazenje prevoda:
          while (true) {
            System.out.print ("Rec?       "); rec = Citaj.String ();
          if (rec.equals ("?")) break;
            System.out.print ("Prevodi:   "); 
            if ((prevodi = r.prevodi (rec)) != null)
              for (int i=0; i<prevodi.length;
                   System.out.print(prevodi[i++]+" "));
            System.out.println ();
          }
          break;
        case  '2': // Dodavanje prevoda:
          while (true) {
            System.out.print ("Rec?       ");   rec    = Citaj.String ();
          if (rec.equals ("?")) break;
            while (true) {
              System.out.print ("Prevod?    "); prevod = Citaj.String ();
            if (prevod.equals ("?")) break;
              r.dodaj (rec, prevod);
            }
          }
          break;
        case '3': // Brisanje prevoda:
          while (true) {
            System.out.print ("Rec?       ");   rec    = Citaj.String ();
          if (rec.equals ("?")) break;
            while (true) {
              System.out.print ("Prevod?    "); prevod = Citaj.String ();
            if (prevod.equals ("?")) break;
              r.brisi (rec, prevod);
            }
          }
          break;
        case '4': // Brisanje svih prevoda:
          while (true) {
            System.out.print ("Rec?       "); rec     = Citaj.String ();
          if (rec.equals ("?")) break;
            System.out.print ("Prevodi:   "); prevodi = r.prevodi (rec);
            if ((prevodi = r.prevodi (rec)) != null)
              for (int i = 0; i<prevodi.length;
                   System.out.print(prevodi[i++]+" "));
            System.out.println ();
            System.out.print ("Brisati?   ");
            if (Citaj.String ().equalsIgnoreCase ("da")) r.brisi (rec);
          }
          break;
        case '5': // Prikazivanje recnika:
          System.out.print ("\n" + r);
          break;
        case '0': // Kraj rada.
          break radi;
      }
      r.snimi ();
    }
  }
}
