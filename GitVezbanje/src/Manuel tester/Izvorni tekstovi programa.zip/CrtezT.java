// CrtezT.java - Ispitivanje klasa za crtanje.

import crtez.*;
import java.awt.*;
import java.awt.event.*;

public class CrtezT extends Frame {

  private Platno platno = new Platno ();           // Platno za crtanje.
  private Label tacka = new Label ("Boja tacke:"); // Prikaz koordinata.
  private Label boja  = new Label ("           "); // Prikaz boje tacke.

  private void popuniProzor () {                    // Popunjavanje prozora:
    add (platno, "Center");
    platno.addMouseMotionListener (new MouseMotionAdapter(){
      public void mouseMoved (MouseEvent d) { // - obrada pomeranja misa,
        Point p = d.getPoint ();
        tacka.setText ("Boja tacke (" + (int)p.getX() + "," +
                                        (int)p.getY() + "): " );
        boja.setBackground (platno.boja(p));
        validate ();
      }
    });
    Panel ploca = new Panel ();               // - ploca za prikaz podataka.
    add (ploca, "North");
    ploca.add (tacka);
    ploca.add (boja);
  }

  private CrtezT () {                         // Inicijalizacija.
    super ("Crtanje figura");
    setBounds (100, 100, 320, 280);
    popuniProzor ();
    addWindowListener (new WindowAdapter () {
      public void windowClosing (WindowEvent d) { dispose ();  }
    });
  }

  public static void main (String[] varg) {    // Glavni program.
    CrtezT crt = new CrtezT ();
    try {
      crt.platno
        .dodaj (new Crtez ( Color.GREEN, new Point (80,30), 200, 150)
          .dodaj (new Pravoug (Color.BLACK, new Point (-10,-10),
                                            new Point (50,70))  )
          .dodaj (new Crtez (Color.GRAY, new Point(100,-20),90,50)
            .dodaj (new Krug (Color.BLUE, new Point(40,30),30)))
          .dodaj (new Krug (Color.CYAN, new Point (110,90), 50)))
        .dodaj (new Krug (Color.MAGENTA, new Point (70, 100), 50))
        .dodaj (new Krug (Color.RED, new Point(0, 0), 50))
        .dodaj (new Mnogougao (new Color (160, 160, 160))
          .dodaj (new Point ( 20,  60))
          .dodaj (new Point (150, 250))
          .dodaj (new Point (200, 100))
          .dodaj (new Point ( 20, 200))
          .dodaj (new Point (100,  50))
          .dodaj (new Point (200, 200))
      );
      crt.setVisible (true);
    } catch (GCrtez g) { System.out.println (g); }
  }
}