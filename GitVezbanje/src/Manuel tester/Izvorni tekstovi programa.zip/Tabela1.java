// Tabela1.java - Tabeliranje vrednosti izraza.

public class Tabela1 {
  public static void main (String[] vpar) {
    System.out.print ("xmin, xmax, dx? ");
    double xmin = Citaj.Double (), xmax = Citaj.Double (), dx = Citaj.Double ();
    System.out.print ("\nx\ty\n================\n");
    for (double x=xmin; x<=xmax; x+=dx) {
      double y = (x*x - 2*x - 2) / (x*x +1);
      System.out.println (x + "\t" + y);
    }
  }
}
