// LinijeT.java - Ispitivanje klasa linija u ravni.

import linije.*;
public class LinijeT {
    
  private static Linija citaj() {           // Citanje jedne linije.
    System.out.print ("Vrsta (D, I, P)? ");
    char vrs = Citaj.Char ();
    switch (vrs) {
      case 'd': case 'D': {
        System.out.print("A? ");
        double xA = Citaj.Double (), yA = Citaj.Double ();
        System.out.print("B? ");
        double xB = Citaj.Double (), yB = Citaj.Double ();
        return new Duz (new Tacka (xA, yA), new Tacka (xB, yB));
      }
      case 'i': case 'I':
      case 'p': case 'P': {
        System.out.print("Broj temena? ");
        Tacka[] niz = new Tacka [Citaj.Int()];
        for (int i=0; i<niz.length; i++) {
          System.out.print(i+1 + ". teme? ");
          double x = Citaj.Double (), y = Citaj.Double ();
          niz[i] = new Tacka (x, y);
        }
        return (vrs=='i' || vrs=='I') ? new Izlomljena (niz)
                                      : new Poligon    (niz);
      }
      default: return null;
    }
  }

  public static void main (String[] vpar) { // Glavna funkcija.
    Linija[] niz = new Linija [Integer.parseInt (vpar[0])];
    for (int i=0; i<niz.length; ) {
      Linija lin = citaj ();
      if (lin != null) niz[i++] = lin;
        else System.out.println("*** Nepoznata vrsta linije!");
    }
    System.out.println ("\nProcitano:");
    double max = niz[0].duz (); int imax = 0;
    for (int i=0; i<niz.length; i++) {
      double d = niz[i].duz ();
      System.out.println (niz[i] + " d=" + d);
      if (d > max) { max = d; imax = i; }
    }
    System.out.println ("\nNajduza: " + niz[imax]);
  }
}