// Vektor.java - Klasa vektora u ravni.

package vatromet;

public class Vektor {

  private double x, y;                              // Komponente vektora.

  Vektor (double xx, double yy) { x = xx; y = yy; } // Konstruktor.

  double x() { return x; }                          // Dohvatanje
  double y() { return y; }                          //   komponenata.
}