// Scena.java - Klasa aktivnih scena.

package vatromet;
import java.awt.*;

public class Scena extends Canvas implements Runnable {

  private class Elem {                           // Element liste figura:
    Figura fig;                                  // - figura u elementu,
    Elem sled;                                   // - sledeci element,
    Elem (Figura f) {                            // - konstrutor.
      fig = f;
      if (prvi == null) prvi = this; else posl.sled = this;
      posl = this;
    }
  }

  private Elem prvi, posl;                       // Pocetak i kraj liste.
  private Thread nit = new Thread (this);        // Nit scene.

  public Scena () { nit.start (); }              // Konstruktor.

  public synchronized void dodaj (Figura fig)    // Dodavanje figure.
    { new Elem (fig); }

  public synchronized void izbaci (Figura fig) { // Izbacivanje figure.
    Elem tek = prvi, pret = null;
    while (tek!=null && tek.fig!=fig) { pret = tek; tek = tek.sled; }
    if (tek != null) {
      if (pret == null) prvi = tek.sled; else pret.sled = tek.sled;
      if (tek.sled == null) posl = pret;
      if (prvi == null) posl = null;
    }
  }

  public synchronized void paint (Graphics g)    // Crtanje figura u sceni.
    { for (Elem tek=prvi; tek!=null; tek=tek.sled) tek.fig.crtaj (); }

  public void run () {                           // Telo niti.
    try {
      while (! nit.interrupted()) {
        repaint ();
        nit.sleep (20);
      }
    } catch (InterruptedException g) {}
  }

  public void zavrsi () { nit.interrupt (); }    // Prekidanje niti.
}