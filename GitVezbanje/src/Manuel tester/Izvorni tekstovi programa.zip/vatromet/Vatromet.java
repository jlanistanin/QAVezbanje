// Vatromet.java - Klasa vatrometa.

package vatromet;
import java.awt.*;
import java.awt.event.*;

public class Vatromet extends Frame {

  private Scena scena = new Scena();              // Scena po kojoj se crta.
  private Top[] topovi = new Top [3];             // Niz topova.

  private void popuniProzor () {                  // Popunjavanje prozora:
    add (scena, "Center");                        // - scena za crtanje,
    scena.addComponentListener (new ComponentAdapter () {
      public void componentResized(ComponentEvent d){   // - rasporedjivanje
        for (int i=0; i<topovi.length; i++)             //   topova pri
          topovi[i].premesti (new Vektor (              //   promeni
            scena.getWidth()*(2*i+1)/(2*topovi.length), //   velicine
            0                                           //   scene,
          ));
      }
    });

    Panel plo = new Panel (); add (plo, "South");       // - ploca za dugmad,
    plo.setBackground (Color.GRAY);
    Button dgm = new Button ("Kreni"); plo.add (dgm);
    dgm.addActionListener (new ActionListener () {      // - pokretanje
      public void actionPerformed (ActionEvent d)       //   topova,
        { for (Top top: topovi) top.kreni(); }
    });
    plo.add (dgm = new Button ("Stani"));
    dgm.addActionListener (new ActionListener () {      // - zaustavljanje
      public void actionPerformed (ActionEvent d)       //   topova.
        { for (Top top: topovi) top.stani(); }
    });
  }

  public Vatromet () {                            // Inicijalizacija:
    super ("Vatromet");
    setSize (300, 200);
    popuniProzor ();                              // - popunjavanje prozora,
    for (int i=0; i<topovi.length; i++)           // - stvaranje topova,
      topovi[i] =  new Top (scena, new Vektor(0, 0));
    setVisible (true);
    addWindowListener (new WindowAdapter () {     // - obrada zatvaranja
      public void windowClosing (WindowEvent d) { //   prozora.
        for (Top top: topovi) top.zavrsi();
        scena.zavrsi (); dispose ();
      }
    });
  }

  public static void main (String[] varg)         // Glavna funkcija.
    { new Vatromet (); }
}