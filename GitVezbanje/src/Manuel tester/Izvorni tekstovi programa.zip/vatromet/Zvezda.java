// Zvezda.java - Klasa zvezdi.

package vatromet;
import java.awt.*;

public class Zvezda extends Petarda {

  private int a;                   // Ivica obuhvatnog kvadrata.
                                   // Konstruktor.
  public Zvezda (Scena s, Vektor r0, Vektor v0, Color boja, int aa)
    { super (s, r0, v0, boja); a = aa; }

  public void crt (Graphics g, int x, int y) { // Crtanje zvezde.
    g.drawLine (x-a/2, y-a/2, x+a/2, y+a/2);
    g.drawLine (x+a/2, y-a/2, x-a/2, y+a/2);
    g.drawLine (x,     y-a/2, x,     y+a/2);
    g.drawLine (x-a/2, y,     x+a/2, y    );
  }
}