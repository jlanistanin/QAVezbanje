// Petarda.java - Klasa apstraktnih petardi.

package vatromet;
import java.awt.*;

public abstract class Petarda extends Figura {

  private Vektor r0, v0;           // Vektori pocetnog polozaja i brzine.
  private long t0;                 // Vreme stvaranja petarde.
  protected Color boja;            // Boja petarde.
                                   // Konstruktor.
  public Petarda (Scena s, Vektor rr0, Vektor vv0, Color bboja) {
    super (s);
    r0 = rr0; v0 = vv0; boja = bboja;
    t0 = System.currentTimeMillis ();
  }

  public Vektor polozaj () {        // Trenutni polozaj petrade.
    double t = (System.currentTimeMillis() - t0) / 1000.;
    return new Vektor (r0.x()+v0.x()*t, r0.y()+v0.y()*t-10*t*t);
  }

  public void crtaj () {            // Zajedniciki deo crtanja petarde.
    int sir = scena.getWidth ();
    int vis = scena.getHeight ();
    Vektor p = polozaj ();
    int x = (int)p.x ();
    int y = vis - (int)p.y();
    if (x>=0 && x<sir && y>=0 && y<vis) {
      Graphics g = scena.getGraphics ();
      g.setColor (boja);
      crt (g, x, y);
    } else scena.izbaci (this);
  }
                                   // Specificni deo crtanja petarde.
  protected abstract void crt (Graphics g, int x, int y);
}