// Figura.java - Klasa apstraktnih figura.

package vatromet;
import java.awt.Canvas;

public abstract class Figura {

  protected Scena scena;           // Koriscena scena.

  protected Figura (Scena s) {     // Konstruktor.
    (scena = s).dodaj (this);
  }

  public abstract void crtaj ();   // Crtanje figure.

  public void unisti ()            // Izbacivanje iz scene.
    { scena.izbaci (this); }
}