// Top.java - Klasa topova.

package vatromet;
import java.awt.*;

public class Top extends Figura implements Runnable {

  private static int ukId = 0;  // Poldenje korisceni identifikator.
  private int id = ++ukId;      // Identifikator topa.
  private int x, y;             // Koordinate topa.
  private int n = 0;            // Broj ispaljenih petardi.
  private Thread nit = new Thread (this); // Nit topa.
  private boolean radi = false; // Da li treba da radi?

  public Top (Scena s, Vektor p) {                   // Konstruktor.
    super (s);
    scena = s;
    premesti (p);
    nit.start();
  }

  public void premesti (Vektor p)                    // Premestanje topa.
    { x = (int)p.x(); y = (int)p.y(); }

  public int id () { return id; }                    // Identifikacioni broj.

  public String toString () { return id + "/" + n; } // Tekstualni oblik.



  public void crtaj () {                             // Crtanje topa.
    int vis = scena.getHeight ();
    int y = vis - this.y;
    Graphics g = scena.getGraphics ();
    g.setColor (Color.LIGHT_GRAY);
    g.fillRect (x-20, y-20, 40, 20);
    g.setColor (Color.BLACK);
    g.drawRect (x-20, y-20, 40, 20);
    g.drawString (toString(), x-18, y-4);
  }

  public void run () {                               // Telo niti.
    try {
      while (! nit.interrupted ()) {
        if (! radi) synchronized (this) { wait (); }
        Vektor p = new Vektor(x, y+20);
        Vektor v = new Vektor (-100+Math.random()*200,
                                 50+Math.random()*100);
        Color b = new Color((float)(Math.random()),
                            (float)(Math.random()),
                            (float)(Math.random()));
        int a = (int)(4+Math.random()*12);
        if (Math.random() < 0.5)
          new Krug (scena, p, v, b, a);
        else
          new Zvezda (scena, p, v, b, a);
        n++;
        nit.sleep ((long)(500+Math.random()*500));
      }
    } catch (InterruptedException g) {}
    scena.izbaci (this);
  }

  public synchronized void stani () { radi = false; } // Zaustavljanje rada.

  public synchronized void kreni ()                   // Nastavak rada.
    { radi = true; notify (); }

  public void zavrsi () { nit.interrupt (); }         // Prekidanje niti.
}