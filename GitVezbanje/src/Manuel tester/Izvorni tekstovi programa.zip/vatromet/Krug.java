// Krug.java - Klasa krugova.

package vatromet;
import java.awt.*;

public class Krug extends Petarda {

  private int a;                   // Precnik kruga.
                                   // Konstruktor.
  public Krug (Scena s, Vektor r0, Vektor v0, Color boja, int aa)
    { super (s, r0, v0, boja); a = aa; }

  public void crt (Graphics g, int x, int y) // Crtanje kruga.
    { g.fillOval (x-a/2, y-a/2, a, a); }
}