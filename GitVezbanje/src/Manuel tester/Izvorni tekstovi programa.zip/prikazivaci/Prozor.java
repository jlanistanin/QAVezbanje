// Prozor.java - Klasa prikazivaca nizova u prozoru.

package prikazivaci;
import java.awt.*;
import java.awt.event.*;

public class Prozor extends Frame implements Prikazivac {
  private TextArea tks = new TextArea (); // Komponenta za prikaz.
  private String frm;                     // Format prikazivanja.
  private double[] niz;                   // Prikazivani niz.

  public Prozor (String naslov, int x, int y,      // Sastavljanje prozora:
                 int sir, int vis, String frm) {
    super (naslov); this.frm = frm;
    setBounds (x, y, sir, vis);
    add (tks);
    tks.addComponentListener (new ComponentAdapter () { // - obrada promene
      public void componentResized (ComponentEvent d)   //   velicine polja
        { prikazi (niz); }                              //   za tekst,
    });
    addWindowListener (new WindowAdapter () {      // - obrada zatvaranja
      public void windowClosing (WindowEvent d)    //   prozora.
        { dispose (); }
    });
  }

  public void prikazi (double[] niz) {            // Prikazivanje niza.
    if (niz != null) {
      this.niz = niz;
      FontMetrics  fm = getGraphics ().getFontMetrics ();
      StringBuffer sb = new StringBuffer ();
      int p = 0;
      for (double br: niz) {
        String s = String.format (frm, br);
        int k = fm.stringWidth(s);
        if (p+k >= getWidth()-30) { sb.append ('\n'); p = 0; }
        sb.append (s); p += k;
      }
      if (p > 0) sb.append ('\n');
      tks.setText (sb.toString ());
    }
  }

  public String toString () { return "prozor"; }  // Naziv prikazivaca.
}