// Histogram.java - Klasa prikazivaca nizova u obliku histograma.

package prikazivaci;
import java.awt.*;
import java.awt.event.*;

public class Histogram extends Frame implements Prikazivac {

  private class Platno extends Canvas {                 // Klasa platna:
    Platno () {                                         // - konstruktor,
      addComponentListener (new ComponentAdapter () {   // - obrada promene
        public void componentResized (ComponentEvent d) //   velicine
          { repaint() ; }                               //   platna,
      });
    }

    public void paint (Graphics g) {                    // - crtanje po
      if (niz != null) {                                //   platnu.
        g.setColor (Color.BLACK);
        int sir = getWidth (), vis = getHeight ();
        int n = niz.length;
        double max = niz[0];
        for (int i=1; i<n; i++) if (niz[i] > max) max = niz[i];
        double ds = (double) sir / n, dv = (double)vis / max;
        for (int i=0; i<n; i++) {
          int x = (int) (i * ds), v = (int) (niz[i] * dv);
          g.fillRect (x, vis-v, (int)ds-1, v);
        }
      }
    }
  } // class Platno

  private Platno platno = new Platno ();         // Platno po kome se crta.
  private double[] niz;                          // Niz za prikazivanje.

  public Histogram (String naslov, int x, int y, // Sastavljanje prozora:
                    int sir, int vis) {
    super (naslov);
    setBounds (x, y, sir,vis);
    add (platno);
    addWindowListener (new WindowAdapter () {    // - obrada zatvaranja
      public void windowClosing (WindowEvent d)  //   prozora.
        { dispose (); }
    });
  }

  public void prikazi (double[] niz)                // Prikzaivanje niza.
    { this.niz = niz; platno.repaint (); }

  public String toString () { return "histogram"; } // Vrsta prikazivaca.
}