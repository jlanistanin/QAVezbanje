// Prikazivac.java - Interfejs prikazivaca nizova.

package prikazivaci;

public interface Prikazivac {
  void prikazi (double[] niz);           // Prikazivanje niza.

  String toString ();                    // Naziv vrste prikazivaca.
}