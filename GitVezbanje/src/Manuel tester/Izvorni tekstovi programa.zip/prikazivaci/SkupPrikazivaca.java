// SkupPrikazivaca - Klasa skupa prikazivaca.

package prikazivaci;

public class SkupPrikazivaca implements Prikazivac {

  private class Elem {                   // Element liste prikazivaca.
    Prikazivac prik; Elem sled;
    Elem (Prikazivac p) {
      prik = p;
      if (prvi == null) prvi      = this;
        else            posl.sled = this;
      posl = this;
    }
  }

  private Elem prvi = null, posl = null; // Pocetak i kraj liste.

  public void dodaj (Prikazivac p)       // Dodavanje prikazivaca.
    { new Elem (p); }

  public void ukloni (Prikazivac p) {    // Uklanjanje prikazivaca.
    Elem tek = prvi, pret = null;
    while (tek!=null && tek.prik!=p) { pret = tek; tek = tek.sled; }
    if (tek != null) {
      if (pret == null) prvi      = tek.sled;
        else            pret.sled = tek.sled;
      if (prvi == null) posl      = null;
      if (posl == tek ) posl      = pret;
    }
  }

  public void prikazi (double[] niz) {            // Prikazivanje niza.
    for (Elem tek=prvi; tek!=null; tek=tek.sled)
      tek.prik.prikazi (niz);
  }

  public String toString () { return "skup"; }    // Naziv prikazivaca.
}