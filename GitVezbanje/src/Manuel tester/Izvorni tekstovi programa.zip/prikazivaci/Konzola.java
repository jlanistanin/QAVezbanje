// Konzola.java - Klasa prikazivaca nizova na konzoli.

package prikazivaci;

public class Konzola implements Prikazivac {
  private int k;                                  // Broj podataka po redu.
  private String frm;                             // Format prikazivanja.

  public Konzola (int k, String frm)              // Inicijalizacija.
    { this.k = k; this.frm = frm; }

  public void prikazi (double[] niz) {            // Prikazivanje niza.
    StringBuffer s = new StringBuffer ("\n");
    int n = niz.length;
    for (int i=0; i<n; i++) {
      s.append (String.format(frm, niz[i]))
       .append ((i%k==k-1 || k==n-1) ? '\n' : ' ');
    }
    System.out.println (s);
  }

  public String toString () { return "konzola"; } // Naziv prikazivaca.
}