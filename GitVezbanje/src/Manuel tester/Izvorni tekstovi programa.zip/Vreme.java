// vreme.java - Pakovanje i raspakivanje vremena.

public class Vreme {
  public static void main (String[] vpar) {
    System.out.print ("Dan, mesec, godina? ");
    byte dan = Citaj.Byte (), mesec = Citaj.Byte ();
    short godina = Citaj.Short ();
    System.out.print ("Sat, minut? ");
    byte sat = Citaj.Byte (), minut = Citaj.Byte ();
    int vreme = godina << 20 | mesec << 16 | dan << 11 | sat << 6 | minut;
    System.out.println ("Pakovano: " + vreme);
    godina = (short) (vreme >>> 20       );
    mesec  = (byte)  (vreme >>> 16 & 0x0f);
    dan    = (byte)  (vreme >>> 11 & 0x1f);
    sat    = (byte)  (vreme >>>  6 & 0x1f);
    minut  = (byte)  (vreme        & 0x3f);
    System.out.println ("Raspakovano: " + dan + "." + mesec + "." + godina +
                                    " " + sat + ":" + minut);
  }
}
