// FigureT.java - Ispitivanje klasa geometrijskih figura.

import figure.*;
import usluge.Citaj;

public class FigureT {
  public static void main (String[] vpar) {
    Figura[] fig = new Figura [100];
    int n = 0;
    radi: while (true) {
      System.out.print ("Figura? ");
      switch (Citaj.Char ()){
        case 'o': case 'O': fig[n] = new Krug ();    break;
        case 'k': case 'K': fig[n] = new Kvadrat (); break;
        case 't': case 'T': fig[n] = new Trougao (); break;
        default : break radi;
      }
      fig[n++].citaj ();
    }
    for (int i=0; i<n; System.out.println (fig[i++]));
  }
}