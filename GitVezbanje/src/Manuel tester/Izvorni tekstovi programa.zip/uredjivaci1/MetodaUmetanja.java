// MetodaUmetanja.java - Klasa za uredjivanje metodom umetanja
//                       (Insertion Sort).

package uredjivaci1;
import  usluge.Uporediv;

public class MetodaUmetanja implements Uredjivac {

  public void uredi (Uporediv[] niz) {   // Uredjivanje niza.
    int n = niz.length;
    for (int i=1; i<n; i++) {
      int j = i - 1;
      while (j>=0 && niz[j+1].ispred (niz[j])) {
        Uporediv p = niz[j+1]; niz[j+1] = niz[j]; niz[j--] = p;
      }
    }
  }

  public String toString ()              // Naziv algoritma.
    { return "Metoda umetanja"; }
}