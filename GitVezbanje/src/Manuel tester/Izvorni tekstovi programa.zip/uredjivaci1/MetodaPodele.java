// MetodaPodele.java - Klasa za uredjivanje metodom podele
//                     (Quick Sort).

package uredjivaci1;
import  usluge.Uporediv;

public class MetodaPodele implements Uredjivac {

  public void uredi (Uporediv[] niz)    // Uredjivanje niza.
    { uredi (niz, 0, niz.length-1); }

  private void uredi (Uporediv[] a, int p, int q) {
    if (q > p) {
      int i = p-1, j = q;
      while (true) {
        do i++; while (a[i].ispred (a[q]));
        do j--; while (j>=0 && a[q].ispred (a[j]));
      if (i >= j) break;
        Uporediv b = a[i]; a[i] = a[j]; a[j] = b;
      }
      Uporediv b = a[i]; a[i] = a[q]; a[q] = b;
      uredi (a, p, i-1); uredi (a, i+1, q);
    }
  }

  public String toString ()              // Naziv algoritma.
    { return "Metoda podele"; }
}