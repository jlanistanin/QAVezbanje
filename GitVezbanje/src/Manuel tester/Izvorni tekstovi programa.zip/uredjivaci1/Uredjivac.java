// Uredjivac.java - Interfejs algoritama uredjivanja.

package uredjivaci1;

public interface Uredjivac {

  void uredi (usluge.Uporediv[] niz);   // Uredjivanje niza.

  String toString ();                   // Tekstualni oblik.
}