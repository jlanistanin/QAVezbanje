// MetodaIzbora.java - Klasa za uredjivanje metodom izbora
//                     (Selection Sort).

package uredjivaci1;
import  usluge.Uporediv;

public class MetodaIzbora implements Uredjivac {

  public void uredi (Uporediv[] niz) {   // Uredjivanje niza.
    int n = niz.length;
    for (int i=0; i<n-1; i++)
      for (int j=i+1; j<n; j++)
        if (niz[j].ispred (niz[i]))
          { Uporediv p = niz[i]; niz[i] = niz[j]; niz[j] = p; }
  }

  public String toString ()              // Naziv algoritma.
    { return "Metoda izbora"; }
}