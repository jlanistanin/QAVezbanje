// MetodaUmetanja2.java - Klasa za uredjivanje poboljsanom metodom umetanja.

package uredjivaci1;
import  usluge.Uporediv;

public class MetodaUmetanja2 implements Uredjivac {

  public void uredi (Uporediv[] niz) {   // Uredjivanje niza.
    int n = niz.length;
    for (int i=1; i<n; i++) {
      Uporediv p = niz[i];
      int j = i - 1;
      while (j>=0 && p.ispred (niz[j])) niz[j+1] = niz[j--];
      niz[j+1] = p;
    }
  }

  public String toString ()              // Naziv algoritma.
    { return "Poboljsana metoda umetanja"; }
}