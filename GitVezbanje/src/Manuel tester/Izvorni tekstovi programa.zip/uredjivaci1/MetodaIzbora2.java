// MetodaIzbora2.java - Klasa za uredjivanje poboljsanom metodom izbora.

package uredjivaci1;
import  usluge.Uporediv;

public class MetodaIzbora2 implements Uredjivac {

  public void uredi (Uporediv[] niz) {   // Uredjivanje niza.
    int n = niz.length;
    for (int i=0; i<n-1; i++) {
      int m = i;
      for (int j=i+1; j<n; j++)
        if (niz[j].ispred (niz[m])) m = j;
      if (m != i)
        { Uporediv p = niz[i]; niz[i] = niz[m]; niz[m] = p; }
    }
  }

  public String toString ()              // Naziv algoritma.
    { return "Poboljsana metoda izbora"; }
}