// KvadJed.java - Resavanje kvadratne jednacine.

public class KvadJed {
  public static void main (String[] vpar) {
    final int REALNI = 0, DVOSTRUKI = 1,  // Sifre vrsta resenja jednacine.
              KOMPLEKSNI = 2, LINEARNA = 3, POGRESNA = 4;

    System.out.print ("Koeficijenti kvadratne jednacine? ");
    double a = Citaj.Double (), b = Citaj.Double (), c = Citaj.Double ();
    double x1 = 0, x2 = 0,                // Realni delovi korena.
           y1 = 0, y2 = 0;                // Imaginarni delovi korena.
    int vrsta;                            // Vrsta resenja jednacine.

    if (a != 0) {
      double d = b * b - 4 * a * c;   // Diskriminanta jednacine.
      if (d > 0) {
        vrsta = REALNI;
        x1 = (- b + Math.sqrt (d)) / (2 * a);
        x2 = (- b - Math.sqrt (d)) / (2 * a);
      } else if (d == 0) {
        vrsta = DVOSTRUKI;
        x1 = - b / (2 * a);
      } else {
        vrsta = KOMPLEKSNI;
        x1 = - b / (2 * a);
        y1 = Math.sqrt(-d) / (2*a);
        x2 = x1;
        y2 = - y1;
      }
    } else
      if (b != 0) {
        vrsta = LINEARNA;
        x1 = - c / b;
      } else
        vrsta = POGRESNA;

    if (vrsta == REALNI)
      System.out.println ("Realni koreni su " + x1 + " i " + x2);
    else if (vrsta == DVOSTRUKI)
      System.out.println ("Dvostruki realni koren je " + x1);
    else if (vrsta == KOMPLEKSNI)
      System.out.println ("Kompleksni koreni su (" + x1 + ',' + y1 + 
                                           ") i (" + x2 + ',' + y2 + ')');
    else if (vrsta == LINEARNA)
      System.out.println ("Resenje linearne jednacine je " + x1);
    else if (vrsta == POGRESNA)
      System.out.println ("Podaci nemaju smisla!");
  }
}
