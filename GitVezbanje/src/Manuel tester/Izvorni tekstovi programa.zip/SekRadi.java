// SekRadi.java - Obrada sekvencijalne binarne datoteke.

import java.io.*;

public class SekRadi {
  public static void main (String[] varg) {
    try {
      DataInputStream ulaz = new DataInputStream (
                               new FileInputStream (varg[0]));
      DataOutputStream poz = new DataOutputStream (
                               new FileOutputStream (varg[1]));
      DataOutputStream neg = new DataOutputStream (
                               new FileOutputStream (varg[2]));
      while (true ) {
        int n = ulaz.readInt ();
        double[] x = new double [n];
        double s = 0;
        for (int i=0; i<n; s+=(x[i++]=ulaz.readDouble()));
        if (s != 0) {
          (s>0 ? poz : neg).writeInt (n);
          for (int i=0; i<n; i++)
            (s>0 ? poz : neg).writeDouble (x[i]);
        }
      }
    } catch (FileNotFoundException g) {
      System.out.println ("*** Greska pri otvaranju datoteke!");
    } catch (EOFException g) {
    } catch (IOException g) {
      System.out.println ("*** Ulazno/izlazna greska!");
    }
  }
}