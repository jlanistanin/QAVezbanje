// Zaposlen.java - Klasa zaposlenih.

public class Zaposlen extends Osoba {

  protected String firma, odeljenje;

  public void citaj () {
    super.citaj ();
    System.out.print ("Naziv firme?       "); firma     = Citaj.Line ();
    System.out.print ("Naziv odeljenja?   "); odeljenje = Citaj.Line ();
  }

  public String toString () {
    return super.toString () +
           "Naziv firme:       " + firma     + "\n" +
           "Naziv odeljenja:   " + odeljenje + "\n"  ;
  }
}
