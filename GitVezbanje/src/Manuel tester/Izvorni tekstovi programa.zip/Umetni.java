// Umetni.java - Umetanje elemenata niza u drugi niz.

public class Umetni {
  public static void main (String[] vpar) {
    while (true) {
      System.out.print ("m? "); int m = Citaj.Int ();
    if (m < 0) break;
      int[] a = new int [m];
      System.out.print ("A? "); for (int i=0; i<m; a[i++]=Citaj.Int());
      if (m == 0) System.out.println ();
      System.out.print ("n? "); int n = Citaj.Int ();
    if (n < 0) break;
      int[] b = new int [n];
      System.out.print ("B? "); for (int j=0; j<n; b[j++]=Citaj.Int());
      if (n == 0) System.out.println ();
      System.out.print ("p? "); int p = Citaj.Int ();
      if (p < 0) p = 0;
      if (p > m) p = m;

      int[] c = new int [m+n];
      int i = 0, j = 0, k = 0;
      while (j < p) c[k++] = a[j++];
      while (i < n) c[k++] = b[i++];
      while (j < m) c[k++] = a[j++];
      a = c; c = null; m += n;

      System.out.print ("A= ");
      for (i=0; i<m; System.out.print(a[i++]+" "));
      System.out.print ("\n\n");
    }
  }
}
