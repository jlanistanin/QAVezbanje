// Uredi1.java - Uredjivanje tri broja.

public class Uredi1 {
  public static void main (String[] vpar) {
    System.out.print ("Tri broja? ");
    double a = Citaj.Double (), b = Citaj.Double (), c = Citaj.Double ();
    if (a > b) { double p = a; a = b; b = p; }
    if (a > c) { double p = a; a = c; c = p; }
    if (b > c) { double p = b; b = c; c = p; }
    System.out.println ("Uredjeno=  " + a + " " + b + " " + c);
  }
}
