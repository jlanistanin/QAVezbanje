// Potrosac.java - Klasa potrosaca.

package skladiste2;
import  usluge.Polje;
import java.awt.List;

public class Potrosac extends Thread {
  
  private static int ukId = 0;    // Poslednje korisceni identifikator.
  private int id = ++ukId;        // Identifikator potrosaca.
  private Skladiste skladiste;    // Pridruzeno skladiste.
  private int minVreme, maxVreme; // Najkrace i najduze vreme potorsnje.
  private Polje polje;            // Polje za prikaz stanja potrosaca.

  public Potrosac                               // Inicijalizacija.
    (Skladiste sklad, int minVr, int maxVr, Polje p) { 
    minVreme = minVr; maxVreme = maxVr; 
    skladiste = sklad; polje = p;
  }
  
  public Potrosac (Skladiste sklad, int minVr, int maxVr) 
    { this (sklad, minVr, maxVr, null); }
  
  public Potrosac (Skladiste sklad) 
    { this (sklad, 1000, 2000); }
  
  public void run () {                          // Telo niti.
    try {
      while (! interrupted ()) {
        if (polje!=null && polje.indeks()!=-1) ((List)polje.komponenta()).select(polje.indeks());
        int vredn = skladiste.uzmi ();
        if (polje!=null && polje.indeks()!=-1) ((List)polje.komponenta()).deselect(polje.indeks());
        if (polje != null) polje.pisi (id*100000 + vredn);
        sleep ((long)(minVreme + Math.random() * (maxVreme-minVreme)));
      }
    } catch (InterruptedException g) {}
  }
}
