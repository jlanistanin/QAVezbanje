// Skladiste.java - Klasa za uskladistavanje podataka.

package skladiste2;
import  usluge.Polje;

public class Skladiste {

  private static int ukId = 0; // Poslednje korisceni identifikator.
  private int id = ++ukId;     // Identifikator skladista.
  private int[] niz;           // Niz za uskladistavanje podataka.
  private int ulaz, izlaz;     // Mesto stavljanja i uzimanja podatka.
  private int pun;             // Broj popunjenih mesta.
  private Polje polje;         // Polje za prikaz stanja skladista.

  public Skladiste (int kap, Polje p)           // Inicijalizacija.
    { niz = new int [kap]; polje = p; }

  public Skladiste (int kap) { this (kap, null); }

  public synchronized void stavi (int vredn) throws InterruptedException {
    while (pun == niz.length) wait ();          // Stavljanje podatka.
    niz[ulaz++] = vredn;
    if (ulaz == niz.length) ulaz = 0;
    pun++;
    notifyAll ();
    if (polje != null) polje.pisi (toString ());
  }

  public synchronized int uzmi () throws InterruptedException {
    while (pun == 0) wait ();                   // Uzimanje podatka.
    int vredn = niz[izlaz++];
    if (izlaz == niz.length) izlaz = 0;
    pun--;
    notifyAll ();
    if (polje != null) polje.pisi (toString ());
    return vredn;
  }

  public synchronized String toString () {      // Tekstualni oblik.
    StringBuffer s = new StringBuffer ();
    for (int i=0; i<pun; i++)
      s.append (niz[(izlaz+i) % niz.length]).append ('\n');
    return s.toString ();
  }
}