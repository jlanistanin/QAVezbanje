// GVerNula.java - Klasa za greske: Deljenje nulom u veriznom razlomku.

package verizan;

public class GVerNula extends Exception {}