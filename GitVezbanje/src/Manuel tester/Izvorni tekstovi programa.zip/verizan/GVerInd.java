// GVerInd.java - Klasa za greske: Nedozvoljen indeks u veriznom razlomku.

package verizan;

public class GVerInd extends Exception {

  private int n, i;            // Red razlomka i nedozvoljeni indeks.

  public GVerInd (int n, int i)               // Inicijalizacija.
    { this.n = n; this.i = i; }

  public int red () { return n; }             // Dohvatanje atributa.
  public int ind () { return i; }

  public String toString () {                 // Tekstualni oblik.
    return "GRESKA: Nedozvoljeni indeks " + i +
           " u veriznom razlomku reda " + n;
  }
}