// Verizan.java - Klasa veriznih razlomaka.

package verizan;

public class Verizan {

  double[] a;                                    // Koeficijenti razlomka.

  public Verizan (int n) { a = new double [n]; } // Inicijalizacija.

  public Verizan postavi (int i, double b) throws GVerInd { // Postavljanje
    if (i<0 || i>=a.length) throw new GVerInd(a.length, i); //   koefici-
    a[i] = b;                                               //   jenta.
    return this;
  }

  public double vr (double x) throws GVerNula {  // Vrednost razlomka.
    double s = 0;
    for (int i=a.length-1; i>=0; i--) {
      if (x + s == 0) throw new GVerNula ();
      s = a[i] / (x + s);
    }
    return s;
  }

  public String toString () {                    // Tekstualni oblik.
    String s = "Veriz[";
    for (int i=0; i<a.length; i++) {
      if (i > 0) s += ",";
      s += a[i];
    }
    return s + "]";
  }
}