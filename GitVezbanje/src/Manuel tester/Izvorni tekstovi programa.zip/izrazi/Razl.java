// Razl.java - Klasa razlika.

package izrazi;

public class Razl extends Izraz {

  private Izraz a, b;                         // Operandi.

  public Razl (Izraz x, Izraz y)              // Inicijalizacija izrazima.
    { a = x; b = y; }

  public double vr()                          // Vrednost.
    { return a.vr() - b.vr(); }

  public String toString ()                   // Tekstualni oblik.
    { return "(" + a + "-" + b + ")"; }
}