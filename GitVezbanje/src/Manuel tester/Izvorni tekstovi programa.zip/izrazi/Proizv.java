// Proizv.java - Klasa proizvoda.

package izrazi;

public class Proizv extends Izraz {

  private Izraz a, b;                         // Operandi.

  public Proizv (Izraz x, Izraz y)            // Inicijalizacija izrazima.
    { a = x; b = y; }

  public double vr()                          // Vrednost proizvoda.
    { return a.vr() * b.vr(); }

  public String toString ()                   // Tekstualni oblik.
    { return "(" + a + "*" + b + ")"; }
}