// Zbir.java - Klasa zbirova.

package izrazi;

public class Zbir extends Izraz {

  private Izraz a, b;                         // Operandi.

  public Zbir (Izraz x, Izraz y)              // Inicijalizacija izrazima.
    { a = x; b = y; }

  public double vr()                          // Vrednost.
    { return a.vr() + b.vr(); }

  public String toString ()                   // Tekstualni oblik.
    { return "(" + a + "+" + b + ")"; }
}