// Konst.java - Klasa konstanti.

package izrazi;

public class Konst extends Izraz {

  private final double vr;                      // Vrednost.

  public Konst (double v) { vr = v; }           // Inicijalizcija brojem.

  public double vr () { return vr; }            // Vrednost kostante.

  public String toString () { return "" + vr; } // Tekstualni oblik.
}