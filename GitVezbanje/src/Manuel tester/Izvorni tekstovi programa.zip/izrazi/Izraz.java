// Izraz.java - Apstraktna klasa izraza.

package izrazi;

public abstract class Izraz {

  public abstract double vr ();               // Vrednost izraza.

  public abstract String toString ();         // Tekstualni oblik izraza.
}