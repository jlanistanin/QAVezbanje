// Prom.java - Klasa promenljivih.

package izrazi;

public class Prom extends Izraz {

  private static Elem prvi = null;    // Pocetak liste svih promenljivih.
  private Elem ovaj;                  // Element pridruzen ovom objektu.

  private static class Elem {         // Element liste svih promenljivih:
    String ime;                       // - ime,
    double vr;                        // - vrednost,
    int brKor;                        // - broj koriscenja,
    Elem pret, sled;                  // - prethodni i sledeci u listi,
    Elem (String i, double v, Elem p, Elem s) {  // - inicijalizacija.
      ime = i; vr = v; pret = p; sled = s; brKor = 1;
      if (sled != null) sled.pret = this;
      if (pret == null) prvi = this; else pret.sled = this;
    }
  }
                                              // Inicijalizacija:
  public Prom (String ime, double vr) {       // - imenom i brojem,
    Elem tek = prvi, pret = null; int p = 0;
    while (tek!=null && (p=tek.ime.compareTo(ime))<0)
      { pret = tek; tek = tek.sled; }
    if (tek!=null && p==0) { ovaj = tek; ovaj.brKor++; }
      else                   ovaj = new Elem (ime, vr, pret, tek);
  }

  public Prom (String ime) { this (ime, 0); } // - imenom,

  public Prom (String ime, Izraz i)           // - imenom i izrazom,
    { this (ime, i.vr()); }

  public Prom (Prom p)                        // - kopijom promenljive.
    { ovaj = p.ovaj; ovaj.brKor++; }

  public void brisi () {                      // Unistavanje.
    if (--ovaj.brKor == 0) {
      if (ovaj.pret != null) ovaj.pret.sled = ovaj.sled;
        else prvi = ovaj.sled;
      if (ovaj.sled != null) ovaj.sled.pret = ovaj.pret;
    }
  }
                                              // Dodela vrednosti:
  public Prom postavi (double v)              // - realnog broja,
    { ovaj.vr = v; return this; }

  public Prom postavi (Izraz i)               // - izraza.
    { ovaj.vr = i.vr (); return this; }

  public double vr () { return ovaj.vr; }     // Vrednost promenljive.

  public String toString ()                   // Tekstualni oblik.
    { return ovaj.ime; }

  public static void pisiSve () {             // Spisak svih promenljivih.
    for (Elem tek=prvi; tek!=null; tek=tek.sled)
      System.out.print (tek.ime + " ");
    System.out.println ();
  }
}