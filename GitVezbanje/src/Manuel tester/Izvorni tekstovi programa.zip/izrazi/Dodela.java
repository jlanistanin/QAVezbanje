// Dodela.java - Klasa dodele vrednosti.

package izrazi;

public class Dodela extends Izraz {

  private Prom a;                             // Operandi.
  private Izraz b;

  public Dodela (Prom x, Izraz y)             // Inicijalizacija promen-
    { a = x; b = y; }                         //   ljivom i izrazom.

  public double vr ()                         // Vrednost.
    { return a.postavi(b).vr(); }

  public String toString ()                   // Tekstualni oblik.
    { return "(" + a + "=" + b + ")"; }
}