// Step.java - Klasa stepena.

package izrazi;

public class Step extends Izraz {

  private Izraz a, b;                         // Operandi.

  public Step (Izraz x, Izraz y)              // Inicijalizacija izrazima.
    { a = x; b = y; }

  public double vr()                          // Vrednost.
    { return Math.pow (a.vr(), b.vr()); }

  public String toString ()                   // Tekstualni oblik.
    { return "(" + a + "^" + b + ")"; }
}