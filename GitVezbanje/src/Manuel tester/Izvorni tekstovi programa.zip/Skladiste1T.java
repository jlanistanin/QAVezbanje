// Skladiste1T.java - Ispitivanje klasa proizvodjaca i potrosaca.

import skladiste1.*;

public class Skladiste1T {
  public static void main (String[] varg) {
    Skladiste s = new Skladiste (3);
    Thread[] niti = new Thread [11];
    for (int i=0; i<5; i++) {
      niti[i]   = new Proizvodjac (s);
      niti[i+5] = new Potrosac (s);
    }
    niti[10] = new Izvestac (s);
    for (Thread nit: niti) nit.start ();
    try { Thread.sleep (15000); }
      catch (InterruptedException g) {}
    for (Thread nit: niti) nit.interrupt ();
    System.out.println ("Glavna - zavrsila");
  }
}