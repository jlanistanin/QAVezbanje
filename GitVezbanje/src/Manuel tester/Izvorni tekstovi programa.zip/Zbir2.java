// Zbir2.java - Zbir dva broja u grafickom okruzenju.

import java.awt.*;
import java.awt.event.*;

public class Zbir2 extends Frame {

  private TextField prvi, drugi; // Prvi i drugi sabirak
  private Label rez;             // Rezultat.
  private Button radi;           // Pokretac racunanja.

  private Zbir2 () {             // Sastavljanje prozora.
    super ("Zbir 2");
    setBounds (100, 100, 200, 120);
    addWindowListener (new ProzorDogadjaji ());
    setLayout (new GridLayout (4, 2));
    add (        new Label ("Prvi sabirak:"));
    add (prvi  = new TextField ("0"));
    add (        new Label ("Drugi sabirak:"));
    add (drugi = new TextField ("0"));
    add (        new Label ("Zbir:"));
    add (rez   = new Label ("0"));
    add (        new Label ());
    add (radi  = new Button ("Racunaj"));
    radi.addActionListener (new RadiAkcija ());
    setVisible (true);
  }

  private class RadiAkcija implements ActionListener {  // Rukovanje
    public void actionPerformed (ActionEvent d) {       //   dogadjajima
      try {                                             //   dugmeta.
        rez.setText ( Integer.toString (
          Integer.parseInt (prvi .getText()) +
          Integer.parseInt (drugi.getText())
        ));
      } catch (NumberFormatException g) { rez.setText ("GRESKA"); }
    } 
  }

  private class ProzorDogadjaji extends WindowAdapter { // Rukovanje
    public void windowClosing (WindowEvent d)           //   dogadjajima
      { dispose (); }                                   //   prozora.
  }

  public static void main (String[] varg)               // Glavna funkcija.
    { new Zbir2 (); }
}
