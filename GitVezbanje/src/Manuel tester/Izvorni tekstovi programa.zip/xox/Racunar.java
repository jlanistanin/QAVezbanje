// Racunar.java - Klasa racunarskih igraca.

package xox;

public class Racunar extends Igrac {                     // Inicijalizacija.
  public Racunar (String ozn, Tabla tbl) { super (ozn, tbl); }

  public int birajPolje () {                             // Biranje polja.
    return (int)(Math.random() * 9);
  }
}