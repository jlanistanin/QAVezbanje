// Igrac.java - Klasa apstraktnih igraca.

package xox;

public abstract class Igrac {
  private String oznaka;   // Oznaka igraca.
  protected Tabla tabla;   // Tabla na kojoj se igra.
  
  public Igrac (String ozn, Tabla tbl) { // Inicijalizacija.
    oznaka = ozn; tabla = tbl;
  }
                                         // Biranje polja.
  public abstract int birajPolje () throws InterruptedException;
                                         // Izvodjenje poteza.
  public void odigrajPotez () throws InterruptedException {
    while (true) {
      try { tabla.postaviOznaku (birajPolje(), oznaka); return; }
        catch (GNeMoze g) {}
    }
  }
}