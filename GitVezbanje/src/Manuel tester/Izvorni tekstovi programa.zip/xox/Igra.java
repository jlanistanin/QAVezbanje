// Igra.java - Klasa igara Xox-a.

package xox;
import java.awt.*;

public class Igra extends Thread {
  private Igrac[] igraci = new Igrac [2]; // Igraci.
  private int tekIgrac;                   // Igrac na potezu.
  private Tabla tabla;                    // Koriscena tabla.
  private Label oznStanje;                // Stanje igre.
                                          // Inicijalizacija.
  public Igra (Tabla tbl, Igrac prvi, Igrac drugi, Label sta) {
    igraci[0] = prvi;        igraci[1] = drugi;
    tabla = tbl;             tabla.prazni ();
    tekIgrac = 0;            oznStanje = sta;
    oznStanje.setText (" "); start ();
  }

  private boolean isto (int a, int b, int c) {  // Da li su tri neprazne
    return !tabla.oznaka(a).equals(" ") &&      //   jednake oznake?
           tabla.oznaka(a).equals(tabla.oznaka(b)) &&
           tabla.oznaka(a).equals(tabla.oznaka(c))    ;
  }

  public String stanje () {                     // Odredjivanje stanja
    if (isto (0, 1, 2)) return tabla.oznaka(0); //   igre.
    if (isto (3, 4, 5)) return tabla.oznaka(3);
    if (isto (6, 7, 8)) return tabla.oznaka(6);
    if (isto (0, 3, 6)) return tabla.oznaka(0);
    if (isto (1, 4, 7)) return tabla.oznaka(1);
    if (isto (2, 5, 8)) return tabla.oznaka(2);
    if (isto (0, 4, 8)) return tabla.oznaka(0);
    if (isto (2, 4, 6)) return tabla.oznaka(2);
    for (int i=0; i<9; i++)
      if (tabla.oznaka(i).equals(" ")) return " ";
    return "?";
  }

  public void run () {                          // Telo niti.
    String stanje = " ";
    try {
      while (!interrupted() && stanje.equals(" ")) {
        igraci[tekIgrac].odigrajPotez ();
        tekIgrac = 1 - tekIgrac;
        stanje = stanje();
      }
      oznStanje.setText ("Pobednik: " + stanje);
    } catch (InterruptedException g) {}
  }

  public void prekini () { interrupt (); }      // Prekidanje igre.
}