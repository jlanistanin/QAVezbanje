// Tabla.java - Klasa tabli za igru XoX.

package xox;
import java.awt.*;
import java.awt.event.*;

public class Tabla {
  private Panel ploca;                        // Komponenta za prikaz table.
  private Dugme[] dugmad = new Dugme [9];     // Polja table.
  private int pritisnuto;                     // Pritisnuto polje.

  private static class Dugme extends Button { // Polje s pridruzenim
    private int indeks;                       //   indeksom u tabli.
    public Dugme (int ind) { super (" "); indeks = ind; }
  }

  public Tabla (Panel plo) {                    // Inicijalizacija:
    (ploca=plo).setLayout(new GridLayout(3,3)); // - ploca za polja,
    ploca.setEnabled (false);
    Font font = new Font (null, Font.BOLD, 24); // - vrsta slova za natpise,
    DugmeAkcija osmatrac = new DugmeAkcija ();  // - dugmad za polja.
    for (int i=0; i<9; i++) {
      ploca.add (dugmad[i] = new Dugme (i));
      dugmad[i].setFont (font);
      dugmad[i].addActionListener (osmatrac);
    }
  }

  public synchronized int uzmiPritisnuto () throws InterruptedException {
    ploca.setEnabled (true);         // Dohvatanje indeksa pritisnutog
    wait ();                         // polja.
    ploca.setEnabled (false);
    return pritisnuto;
  }
                                     // Obrada pritisaka polja.
  private class DugmeAkcija implements ActionListener {
    public void actionPerformed (ActionEvent d) {
      pritisnuto = ((Dugme)d.getSource()).indeks;
      dalje ();
    }
  }

  private synchronized void dalje () // Dojava da je polje pritisnuto.
    { notify (); }
                                     // Postavljanje oznake na polje.
  void postaviOznaku (int ind, String  oznaka) throws GNeMoze {
    if (ind<0 || ind>=9 || !dugmad[ind].getLabel().equals(" "))
      throw new GNeMoze ();
    dugmad[ind].setLabel (oznaka); dugmad[ind].setEnabled (false);
  }

  void prazni () {                   // Praznjenje table.
    for (int i=0; i<9; i++)
      { dugmad[i].setLabel (" "); dugmad[i].setEnabled (true); }
  }

  public String oznaka (int ind) { // Dohvatanje oznake polja.
    return dugmad[ind].getLabel ();
  }
}