// Covek.java - Klasa ljudskih igraca.

package xox;

public class Covek extends Igrac {                       // Inicijalizacija.
  public Covek (String ozn, Tabla tbl) {
    super (ozn, tbl);
  }

  public int birajPolje () throws InterruptedException { // Biranje polja.
    return tabla.uzmiPritisnuto ();
  }
}