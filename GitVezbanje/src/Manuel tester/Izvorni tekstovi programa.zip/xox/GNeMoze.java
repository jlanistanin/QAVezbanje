// GNeMoze.java - Klasa za greske: Nedozvoljen potez.

package xox;

public class GNeMoze extends Exception {
  public String toString () {
    return "Nedozvoljen potez!";
  }
}