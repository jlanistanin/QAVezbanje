//Djak.java - Klasa djaka.

public class Djak extends Osoba {

  private String skola, razred;

  public void citaj () {
    super.citaj ();
    System.out.print ("Naziv skole?       "); skola  = Citaj.Line ();
    System.out.print ("Razred?            "); razred = Citaj.Line ();
  }

 
  public String toString () {
    return super.toString () +
           "Naziv skole:       " + skola     + "\n" +
           "Razred:            " + razred    + "\n"  ;
  }
}
