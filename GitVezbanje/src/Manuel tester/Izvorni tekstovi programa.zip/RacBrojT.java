// RacBrojT - Ispitivanje klase racionalnih brojeva.

public class RacBrojT {
  public static void main (String[] vpar) {
    int n = Integer.parseInt (vpar[0]);
    RacBroj a = new RacBroj ();
    for (int i=1; i<=n;
      System.out.println (i + " " + a.dodaj (new RacBroj (1, i++))));
  }
}
