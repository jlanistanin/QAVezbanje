//Osoba.java - Klasa osoba.

public class Osoba {

  private String ime, rodjen, adresa;

  public void citaj () {
    System.out.print ("Ime i prezime?     "); Citaj.getNL ();
                                              ime    = Citaj.Line ();
    System.out.print ("Datum rodjenja?    "); rodjen = Citaj.Line ();
    System.out.print ("Adresa stanovanja? "); adresa = Citaj.Line ();
  }

  public String toString () {
    return "Ime i prezime:     " + ime       + "\n" +
           "Datum rodjenja:    " + rodjen    + "\n" +
           "Adresa stanovanja: " + adresa    + "\n"   ;
  }
}
