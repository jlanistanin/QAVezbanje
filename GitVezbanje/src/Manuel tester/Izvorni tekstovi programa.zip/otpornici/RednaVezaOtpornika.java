// RednaVezaOtpornika.java - Klasa redno vezanih otpornika.

package otpornici;

public class RednaVezaOtpornika extends SlozenOtpornik {

  public double otpornost () {                 // Otpornost otpronika.
    double r = 0;
    for (Elem tek=prvi; tek!=null; tek=tek.sled)
      r += tek.R.otpornost ();
    return r;
  }

  protected final char otv  () { return '('; } // Simboli za tekstualni
  protected final char oper () { return '+'; } //   oblik.
  protected final char zatv () { return ')'; }
}