// ApstraktanOtpornik.java - Klasa apstraktnih otpornika.

package otpornici;

public abstract class ApstraktanOtpornik {

  public abstract double otpornost ();  // Otpornost otpornika.

  public abstract String toString ();   // Tekstualni oblik.
}