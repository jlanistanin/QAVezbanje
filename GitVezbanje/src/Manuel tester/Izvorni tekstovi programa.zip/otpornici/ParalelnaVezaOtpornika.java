// ParalelnaVezaOtpornika.java - Klasa paralelno vezanih otpornika.

package otpornici;

public class ParalelnaVezaOtpornika extends SlozenOtpornik {

  public double otpornost () {                 // Otpornost otpornika.
    double s = 0;
    for (Elem tek=prvi; tek!=null; tek=tek.sled)
      s += 1 / tek.R.otpornost ();
    return 1 / s;
  }

  protected final char otv  () { return '['; } // Simboli za tekstualni
  protected final char oper () { return '|'; } //   oblik.
  protected final char zatv () { return ']'; }
}