// SlozenOtpornik.java - Apstraktna klasa slozenih otpornika.

package otpornici;

public abstract class SlozenOtpornik extends ApstraktanOtpornik {

  protected static class Elem {               // Element liste otpornika:
    ApstraktanOtpornik R;                     // - sadrzani otpornik,
    Elem sled;                                // - sledeci element liste,
    Elem (ApstraktanOtpornik r)               // - inicijalizacija.
      { R = r; }
  }

  protected Elem prvi, posl; // Pocetak i kraj liste sadrzanih otpornika.

  public SlozenOtpornik dodaj (ApstraktanOtpornik r) { // Dodavanje
    Elem novi = new Elem (r);                          //   otpornika.
    if (prvi == null) prvi = novi;
      else            posl.sled = novi;
    posl = novi;
    return this;
  }
                                          // Simboli za tekstualni oblik:
  protected abstract char otv  ();        // - otvorena zagrada,
  protected abstract char oper ();        // - operator,
  protected abstract char zatv ();        // - zatvorena zagrada.

  public final String toString () {       // Tekstualni oblik.
    StringBuffer s = new StringBuffer ();
    s.append (otv ());
    for (Elem tek=prvi; tek!=null; tek=tek.sled) {
      s.append (tek.R);
      if (tek.sled != null) s.append (oper());
    }
    return s.append (zatv()).toString ();
  }
}