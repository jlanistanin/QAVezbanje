// ProstOtpornik.java - Klasa prostih otpornika.

package otpornici;

public class ProstOtpornik extends ApstraktanOtpornik {

  private double R;                          // Vrednost otpornosti.

  public ProstOtpornik (double r) { R = r; } // Inicijalizacija.

  public double otpornost () { return R; }   // Otpornost otpornika.

  public String toString ()                  // Tekstualni oblik.
    { return Double.toString (R); }
}