// Tacka1.java - Klasa tacaka u ravni.

public class Tacka1 {

  private double x, y;                      // Koordinate.

  public void postavi (double a, double b)  // Postavljanje koordinata.
    { x = a; y = b; }

  public double x () { return x; }          // Apscisa.

  public double y () { return y; }          // Ordinata.

  public double rastojanje (Tacka1 t)       // Rastojanje do tacke.
    { return Math.sqrt (Math.pow(x-t.x,2) + Math.pow(y-t.y,2)); }

  public void citaj ()                      // Citanje tacke.
    { x = Citaj.Double (); y = Citaj.Double (); }

  public void pisi ()                       // Pisanje tacke.
    { System.out.print ("(" + x + "," + y + ")"); }

  public static void main (String[] vpar) { // Ispitivanje klase tacaka.
    System.out.print ("t1? ");
    double x = Citaj.Double (), y = Citaj.Double ();
    Tacka1 t1 = new Tacka1 (); t1.postavi (x, y);
    System.out.print ("t2? ");
    Tacka1 t2 = new Tacka1 (); t2.citaj ();
    System.out.print ("t1=(" + t1.x () + "," + t1.y () + "), t2=");
    t2.pisi (); System.out.println ();
    System.out.println ("Rastojanje=" + t1.rastojanje (t2));
  }
}
