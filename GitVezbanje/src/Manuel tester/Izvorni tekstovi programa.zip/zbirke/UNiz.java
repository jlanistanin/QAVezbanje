// UNiz.java - Klasa uredjenih nizova.

package zbirke;

public class UNiz extends ANiz {
  
  public Zbirka dodaj (int b) {                          // Dodavanje
    if (n == niz.length) povecaj ();                     //   elementa.
    int i = n; while (i>0 && niz[i-1]>b) niz[i] = niz[--i];
    niz[i] = b; n++;
    return this;
  }
  
  public Zbirka postavi (int i, int b) throws GIndeks {  // Postavljanje
    if (i<0 || i>=n) throw new GIndeks (i);              //   elementa.
    if (b > niz[i])      while (i< n && niz[i]<b) niz[i]=niz[++i];
    else if (b < niz[i]) while (i>=0 && niz[i]>b) niz[i]=niz[--i];
    niz[i] = b; novoMesto = i;
    return this;
  }
  
  private int novoMesto;      // Mesto elementa posle promene vrednosti.
                                                 // Stvaranje iteratora.
  public Iterator iterator () { return new IterUN (); }
  
  // UNUTRASNJA KLASA ITERATORA UREDJENE ZA NIZOVE.
  private class IterUN extends AIterAN {

    public Iterator postaviTek (int b) throws GNemaTek { // Postavljanje
      if (! imaTek()) throw new GNemaTek ();             //   tekuceg
      try { postavi (tek, b); } catch (GIndeks g) {}     //   elementa.
      tek = novoMesto;
      return this;
    }
  }
}