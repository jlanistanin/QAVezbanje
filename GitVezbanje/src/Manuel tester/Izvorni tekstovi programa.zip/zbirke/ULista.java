// ULista.java - Klasa uredjenih listi.

package zbirke;

public class ULista extends ALista {

  public Zbirka dodaj (int b) {                  // Dodavanje elementa.
    Elem tek = prvi, pret = null;
    while (tek!=null && tek.broj<= b) { pret = tek; tek = tek.sled; }
    novi = new Elem (b, pret); npret = pret; n++;
    return this;
  }

  private Elem novi, npret;   // Novododati i njemu prethodni element.

  public Zbirka postavi (int i, int b) throws GIndeks {   // Postavljanje
    if (i<0 || i>=n) throw new GIndeks (i);               //   elementa.
    brisi (i); return dodaj (b);
  }

  public Iterator iterator ()                             // Stvaranje
    { return new IterUL (); }                             //   iteratora.

  // UNUTRASNJA KLASA ITERATORA ZA UREDJENE LISTE.
  private class IterUL extends AIterAL {

    public Iterator postaviTek (int b) throws GNemaTek {  // Postavljanje
      if (! imaTek()) throw new GNemaTek ();              //   tekuceg
      int i = 0; for (Elem t=prvi; t!=tek; t=t.sled) i++; //   elementa.
      try { postavi (i, b); } catch (GIndeks g) {}
      tek = novi; pret = npret;
      return this;
    }
  }
}