// ANiz.java - Apstraktna klasa nizova.

package zbirke;

public abstract class ANiz implements Zbirka {

  protected int[] niz;                         // Elementi niza.
  protected int n;                             // Broj elemenata niza.

  public ANiz () { niz = new int [5]; }        // Inicijalizacija.

  public int vel () { return n; }              // Velicina zbirke.

  public int dohvati (int i) throws GIndeks {  // Dohvatanje elementa.
    if (i<0 || i>=n) throw new GIndeks (i);
    return niz[i];
  }

  public abstract Zbirka dodaj (int b);        // Dodavanje elementa.

  protected void povecaj () {                  // Povecavanje kapaciteta
    int k = (n>50 ? n/10 : 5);                 //   (10%, ali bar za 5).
    int[] pom = new int[n+k];
    for (int i=0; i<n; pom[i]=niz[i++]);
    niz = pom;
  }
                                               // Postavljanje elementa.
  public abstract Zbirka postavi (int i, int b) throws GIndeks;

  public Zbirka brisi (int i) throws GIndeks { // Izbacivanje elementa.
    if (i<0 || i>=n) throw new GIndeks (i);
    int b = niz[i], m = niz.length - n;
    if (m > niz.length/5 && m > 5) {           // - ako je bar 20% slobodno,
      m = (niz.length>10 ? niz.length/10 : 5); //   skrati niz za 10%,
      int[] pom = new int [niz.length - m];    //   ali bar za 5.
      for (int j=0, k=0; j<n; j++)
        if (j != i) pom[k++] = niz[j];
      niz = pom;
    } else
      while (i < n-1) niz[i] = niz[++i];
    n--;
    return this;
  }

  public Zbirka isprazni ()                    // Praznjenje zbirke.
    { niz = new int [5]; n = 0; return this; }

  public abstract Iterator iterator ();        // Stvaranje iteratora.

  public String toString () {                  // Tekstualni oblik zbirke.
    StringBuffer s = new StringBuffer ("[");
    for (int i=0; i<n; i++) {
      if (i > 0) s.append (',');
      s.append (niz[i]);
    }
    return s.append (']').toString();
  }

  // UNUTRASNJA KLASA ITERATORA ZA NIZOVE.
  protected abstract class AIterAN implements Iterator {
    protected int tek = 0;                // Indeks tekuceg elementa.

    public Iterator naPocetak ()          // Pomeranje na pocetak zbirke.
      { tek = 0; return this; }

    public Iterator naSledeci ()          // Pomeranje na sledeci element.
      { tek++; return this; }

    public boolean imaTek ()              // Ima li tekuceg elementa?
      { return tek < n; }

    public int dohvatiTek () throws GNemaTek { // Dohvatanje tekuceg
      if (!imaTek ()) throw new GNemaTek ();   //   elementa.
      return niz[tek];
    }
                                          // Postavljanje tekuceg elementa.
    public abstract Iterator postaviTek (int b) throws GNemaTek;

    public Iterator brisiTek () throws GNemaTek { // Brisanje tekuceg
      if (!imaTek ()) throw new GNemaTek ();      //   elementa.
      try { brisi (tek); } catch (GIndeks g) {}
      return this;
    }
  }
}