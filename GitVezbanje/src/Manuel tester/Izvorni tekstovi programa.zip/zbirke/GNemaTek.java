// GNemaTek.java - Klasa za greske: Nema tekuceg elementa.

package zbirke;

public class GNemaTek extends GZbirka {
                                                        // Inicijalizacija.
  public GNemaTek () { super ("Nema tekuceg elementa u zbirci!"); }
}