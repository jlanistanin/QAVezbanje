// GIndeks.java - Klasa za greske: Nedozvoljeni indeks.

package zbirke;

public class GIndeks extends GZbirka {

  private int ind;                         // Nedozvoljeni indeks.

  public GIndeks (int i) { ind = i; }      // Inicijalizacija.

  public int ind () { return ind; }        // Dohvatanje indeksa.

  public String toString ()                // Tekstualni oblik.
    { return super.toString() + "Nedozvoljen indeks " + ind + "!"; }
}