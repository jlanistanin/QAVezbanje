// NULista.java - Klasa neuredjenih listi.

package zbirke;

public class NULista extends ALista {
  
  public Zbirka dodaj (int b)                            // Dodavanje
    { new Elem (b, posl); n++; return this; }            //   elementa.
  
  public Zbirka postavi (int i, int b) throws GIndeks {  // Postavljanje
    nadji (i).broj = b; return this; }                   //   elementa.

  public Iterator iterator ()                            // Stvaranje
    { return new IterNUL (); }
  
  // UNUTRASNJA KLASA ITERATORA ZA NEUREDJENE LISTE.
  private class IterNUL extends AIterAL {

    public Iterator postaviTek (int b) throws GNemaTek { // Postavljanje
      if (!imaTek ()) throw new GNemaTek ();             //   tekuceg
      tek.broj = b;                                      //   elementa.
      return this;
    }
  }
}