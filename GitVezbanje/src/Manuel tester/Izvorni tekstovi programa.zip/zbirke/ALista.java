// ALista.java - Apstraktna klasa listi.

package zbirke;

public abstract class ALista implements Zbirka {

  protected Elem prvi, posl;             // Pocetak i kraj liste.
  protected int n;                       // Duzina liste.

  protected class Elem {                 // Element liste:
    int broj;                            // - sadrzani broj,
    Elem sled;                           // - sledeci element,
    Elem (int b, Elem pret) {            // - inicijalizacija.
      broj = b;
      if (pret == null) { sled = prvi; prvi = this; }
        else            { sled = pret.sled; pret.sled = this; }
      posl = this;
    }
  }

  protected Elem nadji (int i) throws GIndeks {  // Nalazenje elementa.
    if (i<0 || i>=n) throw new GIndeks (i);
    Elem tek = prvi; while (i-- > 0) tek = tek.sled;
    return tek;
  }

  public int vel () { return n; }                // Velicina zbirke.

  public int dohvati (int i) throws GIndeks      // Dohvatanje elementa.
    { return nadji (i).broj; }

  public abstract Zbirka dodaj (int b);          // Dodavanje elementa.
                                                 // Postavljanje elementa.
  public abstract Zbirka postavi (int i, int b) throws GIndeks;

  public Zbirka brisi (int i) throws GIndeks {   // Izbacivanje elementa.
    Elem pret = nadji (i-1);
    if (pret.sled == null) throw new GIndeks (i);
    pret.sled = pret.sled.sled; n--;
    return this;
  }

  public Zbirka isprazni ()                      // Praznjenje zbirke.
    { prvi = posl = null; n = 0; return this; }

  public abstract Iterator iterator ();          // Stvaranje iteratora.

  public String toString () {                // Tekstualni oblik zbirke.
    StringBuffer s = new StringBuffer ("[");
    for (Elem tek=prvi; tek!=null; tek=tek.sled) {
      if (tek != prvi) s.append (',');
      s.append (tek.broj);
    }
    return s.append (']').toString();
  }

  // UNUTRASNJA KLASA ITERATORA ZA LISTE.
  protected abstract class AIterAL implements Iterator {

    protected Elem tek=prvi, pret=null;   // Tekuci i prethodni element.

    public Iterator naPocetak ()          // Pomeranje na pocetak zbirke.
      { tek = prvi; pret = null; return this; }

    public Iterator naSledeci () {        // Pomeranje na sledeci element.
      if (tek != null) {pret = tek; tek = tek.sled;}
      return this;
    }

    public boolean imaTek () { return tek != null; } // Ima li tekuceg.
                                                     //  elementa?
    public int dohvatiTek () throws GNemaTek {       // Dohvatanje tekuceg
      if (!imaTek ()) throw new GNemaTek ();         //   elementa.
      return tek.broj;
    }
                                         // Postavljanje tekuceg elementa.
    public abstract Iterator postaviTek (int b) throws GNemaTek;

    public Iterator brisiTek () throws GNemaTek {    // Brisanje tekuceg
      if (!imaTek ()) throw new GNemaTek ();         //   elementa.
      pret.sled = tek = tek.sled; n--;
      return this;
    }
  }
}