// GZbirka.java - Apstraktna klasa za greske sa zbirkama.

package zbirke;

public abstract class GZbirka extends usluge.Greska {

  protected GZbirka (String por) { super (por); }      // Inicijalizacija.

  protected GZbirka () {}

  public String toString () { return super.toString (); } // Tekstualni
}                                                         //   oblik.