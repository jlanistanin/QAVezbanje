// NUNiz.java - Klasa neuredjenih nizova.

package zbirke;

public class NUNiz extends ANiz {
  
  public Zbirka dodaj (int b) {                         // Dodavanje
    if (n == niz.length) povecaj ();                    //  elementa.
    niz[n++] = b;
    return this;
  }
  
  public Zbirka postavi (int i, int b) throws GIndeks { // Postavljanje
    if (i<0 || i>=n) throw new GIndeks (i);             //   elementa.
    niz[i] = b;
    return this;
  }
                                                 // Stvaranje iteratora.
  public Iterator iterator () { return new IterNUN (); }
  
  // UNUTRASNJA KLASA ITERATORA ZA NEUREDJENE NIZOVE.
  private class IterNUN extends AIterAN {

    public Iterator postaviTek (int b) throws GNemaTek { // Postavljanje
      if (!imaTek ()) throw new GNemaTek ();             //   tekuceg
      niz[tek] = b;                                      //   elementa.
      return this;
    }
  }
}