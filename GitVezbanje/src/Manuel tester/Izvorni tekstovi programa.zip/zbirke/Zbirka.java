// Zbirka.java - Interfejs sekvencijalnih zbirki.

package zbirke;

public interface Zbirka {

  int vel ();                                   // Velicina zbirke.

  Zbirka dodaj (int b);                         // Dodavanje elementa.

  Zbirka postavi (int i, int b) throws GIndeks; // Postavljanje elem.

  int dohvati (int i) throws GIndeks;           // Dohvatanje elementa.

  Zbirka brisi (int i) throws GIndeks;          // Izbacivanje elementa.

  Zbirka isprazni ();                           // Praznjenje zbirke.

  Iterator iterator ();                         // Stvaranje iteratora.

  String toString ();                           // Tekstualni oblik zbirke.
}