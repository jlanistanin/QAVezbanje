// Iterator.java - Interfejs iteratora sekvencijalnih zbirki.

package zbirke;

public interface Iterator {
  
  Iterator naPocetak ();                   // Pomeranje na pocetak zbirke.
  
  Iterator naSledeci ();                   // Pomeranje na sledeci element.
  
  boolean imaTek ();                           // Ima li tekuceg?
  
  int dohvatiTek () throws GNemaTek;           // Dohvatanje tekuceg.
  
  Iterator postaviTek (int b) throws GNemaTek; // Postavljanje tekuceg.
  
  Iterator brisiTek () throws GNemaTek;        // Izbacivanje tekuceg.
}