// Predmeti2T.java - Ispitivanje klasa predmeta.

import predmeti2.*;

public class Predmeti2T {
  public static void main (String[] vpar) {
    Sklop s = new Sklop ();
    s.dodaj (new Sfera  (1, 2))
     .dodaj (new Kvadar (3, 4, 5, 6))
     .dodaj (new Sklop  ().dodaj (new Kvadar (2, 5, 3, 4))
                          .dodaj (new Sfera  (3, 1)))
     .dodaj (new Sfera  (4, 2));
    System.out.println (s + "\nV=" + s.V() + " Q=" + s.Q());
    System.out.println ();
    s = (Sklop)s.clone ();
    System.out.println (s + "\nV=" + s.V() + " Q=" + s.Q());
  }
}