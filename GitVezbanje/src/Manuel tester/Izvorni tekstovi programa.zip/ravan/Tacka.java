// Tacka.java - Klasa tacaka u ravni.

package ravan;

class Tacka {

  double x, y;                     // Koordinate.
                                   // Inicijalizacija:
  Tacka () {}                      // - u koordinatnom pocetku,

  Tacka (double x) { this.x = x; } // - na x-osi,

  Tacka (double x, double y)       // - zadatim koordinatama.
    { this.x = x; this.y = y; }

  double poteg ()                  // Rastojanje od koordinatnog pocetka.
    { return Math.sqrt (x*x + y*y); }

  double rastojanje (Tacka t)      // Rastojanje od zadate tacke.
    { return Math.sqrt (Math.pow(x-t.x,2)+Math.pow(y-t.y,2)); }
}
