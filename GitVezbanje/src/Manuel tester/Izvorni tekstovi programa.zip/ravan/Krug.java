// Krug.java - Klasa krugova u ravni koji ne smeju da se preklapaju.

package ravan;

public class Krug {

  private Tacka c; private double r;  // Centar i poluprecnik.
  private Krug pret, sled;            // Prethodni i sledeci krug.
  private static Krug prvi = null;    // Zajednicka lista svih krugova.

  private Krug () {}                  // Samo za interne potrebe.
                                      // Moze li krug da postoji?
  public static boolean moze (double r, double x, double y) {
    Krug k = new Krug (); k.r = r; k.c = new Tacka (x, y);
    for (Krug tek=prvi; tek!=null; tek=tek.sled)
      if (tek.rastojanje (k) < 0) return false;
    return true;
  }

  public Krug (double r, double x, double y) {  // Stvaranje kruga.
    if (! moze (r, x, y)) System.exit (1);
    this.r = r;
    this.c = new Tacka (x, y);
    sled = prvi; pret = null;
    if (prvi != null) prvi.pret = this;
    prvi = this;
  }

  public void brisi () {                         // Krug vise nije potreban.
    if (pret != null) pret.sled = sled; else prvi = sled;
    if (sled != null) sled.pret = pret;
  }

  public boolean premesti (double x, double y) { // Premestanje kruga.
    if (! moze (r, x, y)) return false;
    c.x = x; c.y = y; return true;
  }

  public boolean pomeri (double dx, double dy) { // Pomeranje kruga.
    if (! moze (r, c.x+dx, c.y+dy)) return false;
    c.x += dx; c.y += dy; return true;
  }

  public double rastojanje (Krug k)              // Rastojanje do drugog kruga.
    { return c.rastojanje (k.c) - r - k.r; }

  public String toString ()                      // Tekstualni oblik.
    { return "K[" + r + ",(" + c.x + "," + c.y + ")]"; }
}
