// NizKomplT.java - Ispitivanje klase niza kompleksnih brojeva.

public class NizKomplT {
  public static void main (String[] vpar) {
    System.out.print ("Red polinoma? "); int n = Citaj.Int ();
    NizKompl poli = new NizKompl (n+1);
    for (int i=n; i>=0; i--) {
      System.out.print ("p[" + i + "] (re,im)? ");
      poli.postavi (Kompl1.citaj(), i);
    }
    System.out.println ("\n" + poli.poli());
    System.out.print ("\nPocetna vrednost (re,im)? ");
    Kompl1 z = Kompl1.citaj ();
    System.out.print ("Vrednost koraka  (re,im)? ");
    Kompl1 d = Kompl1.citaj ();
    System.out.print ("Broj tacaka? "); int k = Citaj.Int ();
    System.out.format ("\n%15s%20s\n%s\n", "z", "p(z)",
                       "========================================");
    for (int i=0; i<k; i++, z = z.zbir(d))
      System.out.format ("%20s%20s\n", z, poli.poli(z));
  }
}
