// Pozdrav1.java - Ispisivanje pozdrava.

public class Pozdrav1 {
  public static void main (String[] vpar) {
    System.out.println ("Pozdrav svima!");
  }
}
