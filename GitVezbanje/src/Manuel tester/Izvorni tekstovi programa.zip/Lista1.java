// Lista1.java - Klasa listi celih brojeva.

public class Lista1 {

  private Elem prvi;               // Pocetak liste.
                                   // Inicijalizacija:
  public Lista1 () {}              // - prazna lista,

  public Lista1 (int b)            // - lista od jednog broja.
    { prvi = new Elem (b); }

  public void prazni ()            // Praznjenje liste.
    { prvi = null; }

  public int duz () {              // Broj elemenata liste.
    int n = 0;
    for (Elem tek=prvi; tek!=null; tek=tek.sled) n++;
    return n;
  }

  public String toString () {      // Tekstualni oblik.
    String s = "";
    for (Elem tek=prvi; tek!=null; tek=tek.sled)
      s += tek.broj + " ";
    return s;
  }

  public void naPocetak (int b)    // Dodavanje na pocetak.
    { prvi = new Elem (b, prvi); }

  public void naKraj (int b) {     // Dodavanje na kraj.
    Elem novi = new Elem (b);
    if (prvi == null) prvi = novi;
    else {
      Elem tek = prvi;
      while (tek.sled != null) tek = tek.sled;
      tek.sled = novi;
    }
  }

  public void citaj1 (int n) {     // Citanje liste stavljajuci
    prvi = null;                   //   brojeve na pocetak.
    for (int i=0; i<n; i++)
      prvi = new Elem (Citaj.Int(), prvi);
  }

  public void citaj2 (int n) {     // Citanje liste stavljajuci
    Elem posl = prvi = null;       //   brojeve na kraj.
    for (int i=0; i<n; i++) {
      Elem novi = new Elem (Citaj.Int ());
      if (prvi == null) prvi = novi;
        else posl.sled = novi;
      posl = novi;
    }
  }

  public void umetni (int b) {     // Umetanje u uredjenu listu.
    Elem tek = prvi, pret = null;
    while (tek != null && tek.broj < b)
      { pret = tek; tek = tek.sled; }
    Elem novi = new Elem (b, tek);
    if (pret == null) prvi = novi;
      else pret.sled = novi;
  }

  public void izostavi (int b) {   // Izostavljanje svakog
    Elem tek = prvi, pret = null;  //   pojavljivanja broja.
    while (tek != null)
      if (tek.broj != b) {
        pret = tek; tek = tek.sled;
      } else {
        tek = tek.sled;
        if (pret == null) prvi = tek;
          else pret.sled = tek;
    }
  }
}
