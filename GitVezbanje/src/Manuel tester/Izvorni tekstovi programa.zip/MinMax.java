// MinMax.java - Medjusobna zamena najmanjeg i najveceg elementa matrice.

public class MinMax {
  public static void main (String[] vpar) {
    while (true) {
      System.out.print ("m, n? ");
      int m = Citaj.Int (), n = Citaj.Int ();
    if (m<=0 || n<=0) break;
      float[][] a = new float [m][n];
      for (int i=0; i<m; i++) {
        System.out.print (i+1 + ". vrsta? ");
        for (int j=0; j<n; a[i][j++]=Citaj.Float());
      }
      float min = a[0][0], max = min;
      int imin = 0, jmin = 0, imax = 0, jmax = 0;
      for (int i=0; i<m; i++)
        for (int j=0; j<n; j++)
          if      (a[i][j] < min) { min = a[i][j]; imin = i; jmin = j; }
          else if (a[i][j] > max) { max = a[i][j]; imax = i; jmax = j; }
      float b = a[imin][jmin];
      a[imin][jmin] = a[imax][jmax];
      a[imax][jmax] = b;
      System.out.println ();
      for (int i=0; i<m; i++) {
        for (int j=0; j<n; System.out.print(a[i][j++]+" "));
        System.out.println ();
      }
      System.out.println ();
    }
  }
}
